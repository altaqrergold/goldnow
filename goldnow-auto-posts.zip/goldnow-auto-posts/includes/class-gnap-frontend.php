<?php
/**
 * مخرجات الواجهة: تنسيق الجداول، بيانات FAQ المنظمة، ووصف الميتا عند عدم وجود إضافة SEO
 */

if (!defined('ABSPATH')) {
    exit;
}

class GNAP_Frontend {

    public static function init() {
        add_action('wp_enqueue_scripts', [__CLASS__, 'styles']);
        add_action('wp_head', [__CLASS__, 'head'], 5);
    }

    private static function current_post_id() {
        if (!is_singular('post')) {
            return 0;
        }
        $id = get_queried_object_id();
        return ($id && get_post_meta($id, '_gnap_country', true)) ? $id : 0;
    }

    public static function styles() {
        if (self::current_post_id()) {
            wp_enqueue_style('gnap-article', GNAP_URL . 'assets/css/article.css', [], GNAP_VERSION);
        }
    }

    public static function head() {
        $id = self::current_post_id();
        if (!$id) {
            return;
        }

        $has_seo_plugin = defined('WPSEO_VERSION') || class_exists('RankMath') || defined('AIOSEO_VERSION') || defined('SEOPRESS_VERSION');
        $description = get_post_meta($id, '_gnap_description', true);
        if (!$has_seo_plugin && $description) {
            echo '<meta name="description" content="' . esc_attr($description) . '">' . "\n";
        }

        $faq = get_post_meta($id, '_gnap_faq', true);
        if (is_array($faq) && $faq) {
            $schema = [
                '@context'   => 'https://schema.org',
                '@type'      => 'FAQPage',
                'mainEntity' => array_map(function ($item) {
                    return [
                        '@type'          => 'Question',
                        'name'           => $item['q'],
                        'acceptedAnswer' => ['@type' => 'Answer', 'text' => $item['a']],
                    ];
                }, $faq),
            ];
            echo '<script type="application/ld+json">' . wp_json_encode($schema, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . '</script>' . "\n";
        }
    }
}
