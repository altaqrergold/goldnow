<?php
/**
 * صفحة الإعدادات والتحكم
 */

if (!defined('ABSPATH')) {
    exit;
}

class GNAP_Admin {

    const SLUG = 'gnap-auto-posts';

    public static function init() {
        add_action('admin_menu', [__CLASS__, 'menu'], 99);
        add_action('admin_init', [__CLASS__, 'register']);
        add_action('admin_post_gnap_run', [__CLASS__, 'handle_run']);
        add_action('wp_ajax_gnap_publish_one', [__CLASS__, 'ajax_publish_one']);
        add_action('admin_post_gnap_clear_log', [__CLASS__, 'handle_clear_log']);
        add_filter('plugin_action_links_' . plugin_basename(GNAP_FILE), [__CLASS__, 'action_links']);
    }

    /**
     * الصفحة تظهر تحت قائمة Gold Manager إن كانت إضافة Goldx مفعلة، وإلا تحت "الإعدادات"
     */
    private static function under_goldx() {
        return function_exists('infi_gold_manager_admin_menu');
    }

    private static function base_file() {
        return self::under_goldx() ? 'admin.php' : 'options-general.php';
    }

    public static function page_url($args = []) {
        return add_query_arg(array_merge(['page' => self::SLUG], $args), admin_url(self::base_file()));
    }

    public static function menu() {
        $parent = self::under_goldx() ? 'infi-gold-manager' : 'options-general.php';
        add_submenu_page($parent, 'النشر التلقائي لأسعار الذهب', 'النشر التلقائي', 'manage_options', self::SLUG, [__CLASS__, 'render']);
    }

    public static function action_links($links) {
        array_unshift($links, '<a href="' . esc_url(self::page_url()) . '">الإعدادات</a>');
        return $links;
    }

    public static function register() {
        register_setting('gnap', GNAP_Settings::OPTION, [
            'sanitize_callback' => ['GNAP_Settings', 'sanitize'],
        ]);
    }

    public static function handle_run() {
        if (!current_user_can('manage_options')) {
            wp_die('غير مصرح');
        }
        check_admin_referer('gnap_run');

        // دولة واحدة فقط لكل طلب؛ نشر كل الدول يتم من المتصفح دولة تلو الأخرى (ajax_publish_one)
        $code = isset($_POST['country']) ? sanitize_key(wp_unslash($_POST['country'])) : '';
        if ($code === 'all') {
            $messages = ['✗ نشر كل الدول يحتاج تفعيل JavaScript في المتصفح.'];
        } else {
            $result = GNAP_Publisher::publish($code, 'manual');
            $messages = [($result['result'] === 'error' ? '✗ ' : '✓ ') . $result['message']];
        }
        set_transient('gnap_notice_' . get_current_user_id(), $messages, 60);

        wp_safe_redirect(self::page_url());
        exit;
    }

    public static function ajax_publish_one() {
        if (!current_user_can('manage_options') || !check_ajax_referer('gnap_run', false, false)) {
            wp_send_json_error(['message' => 'غير مصرح']);
        }
        $code = isset($_POST['country']) ? sanitize_key(wp_unslash($_POST['country'])) : '';
        $result = GNAP_Publisher::publish($code, 'manual');
        wp_send_json_success($result);
    }

    public static function handle_clear_log() {
        if (!current_user_can('manage_options')) {
            wp_die('غير مصرح');
        }
        check_admin_referer('gnap_clear_log');
        GNAP_Log::clear();
        wp_safe_redirect(self::page_url());
        exit;
    }

    public static function render() {
        if (!current_user_can('manage_options')) {
            return;
        }
        $settings = GNAP_Settings::get();
        $countries = GNAP_Countries::all();
        ?>
        <div class="wrap" dir="rtl">
            <h1>النشر التلقائي لأسعار الذهب</h1>
            <?php
            self::notices();
            self::health($settings);
            self::actions($countries);
            self::preview();
            self::settings_form($settings, $countries);
            self::status_table($settings, $countries);
            self::log_table();
            ?>
        </div>
        <style>
            .gnap-card { background:#fff; border:1px solid #c3c4c7; padding:16px 20px; margin:16px 0; max-width:1100px; }
            .gnap-card h2 { margin-top:0; }
            .gnap-countries { display:grid; grid-template-columns:repeat(auto-fill,minmax(170px,1fr)); gap:6px; }
            .gnap-ok { color:#008a20; font-weight:600; }
            .gnap-err { color:#d63638; font-weight:600; }
            .gnap-muted { color:#646970; }
            .gnap-preview-img { max-width:100%; width:600px; border:1px solid #ddd; }
            .gnap-preview-body { border:1px dashed #c3c4c7; padding:12px 16px; max-height:520px; overflow:auto; background:#fcfcfc; }
            .gnap-card textarea { width:100%; }
            .gnap-article-settings { border:1px solid #dcdcde; margin:10px 0; padding:0 14px; background:#fcfcfc; }
            .gnap-article-settings summary { cursor:pointer; font-size:14px; font-weight:600; padding:12px 0; }
        </style>
        <?php
    }

    private static function notices() {
        $key = 'gnap_notice_' . get_current_user_id();
        $messages = get_transient($key);
        if (!$messages) {
            return;
        }
        delete_transient($key);
        echo '<div class="notice notice-info is-dismissible"><p>' . implode('<br>', array_map('esc_html', $messages)) . '</p></div>';
    }

    private static function health($settings) {
        $checks = [];
        $dependency = GNAP_Prices::dependency_error();
        $checks[] = [$dependency === '', $dependency ?: 'إضافة Goldx Manager مفعلة (مصدر الأسعار).'];
        $checks[] = [GNAP_Image::supported(), GNAP_Image::supported() ? 'مكتبة GD مع FreeType متوفرة لتوليد الصور.' : 'مكتبة GD/FreeType غير متوفرة: ستُنشر المقالات بدون صورة بارزة.'];
        $logo = GNAP_Image::logo_file();
        $checks[] = [$logo !== '', $logo !== '' ? 'شعار الموقع سيظهر في الصورة: ' . wp_basename($logo) : 'لم يتم العثور على شعار للموقع: حدد شعاراً للقالب أو أدخل رابط الشعار في الإعدادات (SVG غير مدعوم).'];

        if (!$dependency) {
            $rows = infi_get_latest_gold_prices('24k');
            if ($rows) {
                $age = (int) floor((time() - strtotime($rows[0]['fetch_date'] . ' UTC')) / 60);
                $checks[] = [$age < GNAP_Prices::MAX_GOLD_AGE_HOURS * 60, sprintf('آخر تحديث لسعر الذهب منذ %d دقيقة.', $age)];
            } else {
                $checks[] = [false, 'لا توجد أسعار ذهب في قاعدة البيانات بعد.'];
            }
        }

        $next = wp_next_scheduled(GNAP_Scheduler::HOOK);
        if ($settings['enabled']) {
            $overdue = $next ? (int) floor((time() - $next) / 60) : 0;
            if ($next && $overdue > 10) {
                $checks[] = [false, sprintf('التشغيل كان مجدولاً الساعة %s ومضى عليه %d دقيقة دون أن يعمل: الكرون لا يصل إلى الموقع (تحقق من cron-job.org أو من DISABLE_WP_CRON).', wp_date('H:i', $next), $overdue)];
            } else {
                $checks[] = [(bool) $next, $next ? 'التشغيل القادم: ' . wp_date('Y-m-d H:i', $next) . ' (لا يعمل أي شيء قبل هذا الموعد).' : 'لم تتم جدولة التشغيل القادم.'];
            }
            $last = GNAP_Scheduler::last_run();
            $checks[] = [(bool) $last, $last
                ? 'آخر تشغيل: ' . wp_date('Y-m-d H:i', $last['time']) . ' — ' . $last['message']
                : 'لم يعمل النشر التلقائي بعد منذ تحديث الإضافة.'];
        }
        if (defined('DISABLE_WP_CRON') && DISABLE_WP_CRON) {
            $checks[] = [true, 'WP-Cron الداخلي معطل: تأكد من وجود Cron حقيقي على الخادم يستدعي wp-cron.php.'];
        }
        $checks[] = [(bool) $settings['enabled'], $settings['enabled'] ? 'النشر التلقائي مفعل.' : 'النشر التلقائي معطل — فعّله من الإعدادات بالأسفل.'];

        echo '<div class="gnap-card"><h2>الحالة</h2><ul>';
        foreach ($checks as $check) {
            echo '<li class="' . ($check[0] ? 'gnap-ok' : 'gnap-err') . '">' . ($check[0] ? '✓ ' : '✗ ') . esc_html($check[1]) . '</li>';
        }
        echo '</ul><p class="gnap-muted">WP-Cron الداخلي يعمل فقط عند زيارة الموقع. للحصول على نشر دقيق في موعده يُنصح بتعطيله (<code dir="ltr">define(\'DISABLE_WP_CRON\', true);</code> في wp-config.php) وإضافة Cron حقيقي خفيف على الخادم:<br><code dir="ltr">*/5 * * * * wget -q -O - ' . esc_html(site_url('wp-cron.php?doing_wp_cron')) . ' &gt;/dev/null 2&gt;&amp;1</code></p></div>';
    }

    private static function country_select($countries, $name, $with_all) {
        echo '<select name="' . esc_attr($name) . '">';
        if ($with_all) {
            echo '<option value="all">كل الدول المفعلة</option>';
        }
        foreach ($countries as $code => $c) {
            echo '<option value="' . esc_attr($code) . '">' . esc_html(GNAP_Countries::admin_label($code)) . '</option>';
        }
        echo '</select> ';
    }

    private static function actions($countries) {
        echo '<div class="gnap-card"><h2>نشر يدوي ومعاينة</h2>';

        echo '<form id="gnap-run-form" method="post" action="' . esc_url(admin_url('admin-post.php')) . '" style="margin-bottom:12px">';
        wp_nonce_field('gnap_run');
        echo '<input type="hidden" name="action" value="gnap_run">';
        self::country_select($countries, 'country', true);
        submit_button('انشر الآن', 'primary', 'submit', false);
        echo ' <span class="gnap-muted">إذا كان مقال اليوم موجوداً يتم تحديثه أو تخطيه حسب الإعدادات.</span></form>';
        echo '<ol id="gnap-progress" class="gnap-muted"></ol>';
        self::run_all_script();

        echo '<form method="get" action="' . esc_url(admin_url(self::base_file())) . '">';
        echo '<input type="hidden" name="page" value="' . esc_attr(self::SLUG) . '">';
        wp_nonce_field('gnap_preview', '_gnap_preview', false);
        self::country_select($countries, 'preview', false);
        submit_button('معاينة بدون نشر', 'secondary', '', false);
        echo '</form></div>';
    }

    /**
     * نشر كل الدول من المتصفح: طلب منفصل لكل دولة مع استراحة بينها حتى لا يُضغط الخادم
     */
    private static function run_all_script() {
        $names = [];
        foreach (GNAP_Settings::get('countries') as $code) {
            if (GNAP_Countries::get($code)) {
                $names[$code] = GNAP_Countries::admin_label($code);
            }
        }
        ?>
        <script>
        (function () {
            var form = document.getElementById('gnap-run-form');
            var list = document.getElementById('gnap-progress');
            var countries = <?php echo wp_json_encode($names, JSON_UNESCAPED_UNICODE); ?>;
            var PAUSE = 5000;

            form.addEventListener('submit', function (e) {
                if (form.country.value !== 'all') {
                    return;
                }
                e.preventDefault();
                var codes = Object.keys(countries);
                if (!codes.length || !confirm('سيتم نشر ' + codes.length + ' مقالاً، مقال كل 5 ثوانٍ. متابعة؟')) {
                    return;
                }
                form.submit.disabled = true;
                list.innerHTML = '';

                (function next(i) {
                    if (i >= codes.length) {
                        form.submit.disabled = false;
                        list.insertAdjacentHTML('beforeend', '<li><strong>اكتمل.</strong></li>');
                        return;
                    }
                    var item = document.createElement('li');
                    item.textContent = countries[codes[i]] + '...';
                    list.appendChild(item);

                    var body = new FormData();
                    body.append('action', 'gnap_publish_one');
                    body.append('country', codes[i]);
                    body.append('_wpnonce', form._wpnonce.value);

                    fetch(ajaxurl, {method: 'POST', body: body, credentials: 'same-origin'})
                        .then(function (r) { return r.json(); })
                        .then(function (r) {
                            var ok = r.success && r.data.result !== 'error';
                            item.textContent = (ok ? '✓ ' : '✗ ') + (r.data && r.data.message ? r.data.message : 'خطأ');
                        })
                        .catch(function () { item.textContent = '✗ ' + countries[codes[i]] + ': تعذر الاتصال بالخادم'; })
                        .then(function () { setTimeout(function () { next(i + 1); }, PAUSE); });
                })(0);
            });
        })();
        </script>
        <?php
    }

    private static function preview() {
        if (empty($_GET['preview']) || empty($_GET['_gnap_preview']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_GET['_gnap_preview'])), 'gnap_preview')) {
            return;
        }
        $code = sanitize_key(wp_unslash($_GET['preview']));
        $snapshot = GNAP_Prices::snapshot($code);

        echo '<div class="gnap-card"><h2>معاينة</h2>';
        if (is_wp_error($snapshot)) {
            echo '<p class="gnap-err">' . esc_html($snapshot->get_error_message()) . '</p></div>';
            return;
        }

        $date = GNAP_Countries::local_date($code);
        // المعاينة لا تستهلك أي قالب من رزمة القوالب
        $built = GNAP_Content::build($snapshot, $date, null, '', [], false);

        echo '<p><strong>العنوان:</strong> ' . esc_html($built['title']) . '</p>';
        echo '<p><strong>الوصف:</strong> ' . esc_html($built['description']) . '</p>';
        echo '<p><strong>الوسوم:</strong> ' . esc_html(implode('، ', $built['tags'])) . '</p>';

        $upload = wp_upload_dir();
        $path = trailingslashit($upload['basedir']) . 'gnap-preview/' . $code . '.jpg';
        $image = GNAP_Image::generate($snapshot, $date, $built['change_pct'], wp_parse_url(home_url(), PHP_URL_HOST), $path);
        if (is_wp_error($image)) {
            echo '<p class="gnap-err">' . esc_html($image->get_error_message()) . '</p>';
        } else {
            $url = trailingslashit($upload['baseurl']) . 'gnap-preview/' . $code . '.jpg?v=' . time();
            echo '<p><img class="gnap-preview-img" src="' . esc_url($url) . '" alt=""></p>';
        }
        echo '<div class="gnap-preview-body"' . ($snapshot['country']['lang'] !== 'ar' ? ' dir="ltr"' : '') . '>' . wp_kses_post($built['content']) . '</div></div>';
    }

    private static function settings_form($s, $countries) {
        $categories = get_categories(['hide_empty' => false]);
        $authors = get_users(['capability' => 'edit_posts', 'fields' => ['ID', 'display_name']]);
        $name = GNAP_Settings::OPTION;
        ?>
        <form method="post" action="options.php" class="gnap-card">
            <h2>الإعدادات</h2>
            <?php settings_fields('gnap'); ?>
            <table class="form-table" role="presentation">
                <tr>
                    <th>تفعيل النشر التلقائي</th>
                    <td><label><input type="checkbox" name="<?php echo esc_attr($name); ?>[enabled]" value="1" <?php checked($s['enabled']); ?>> نشر مقال يومي لكل دولة مختارة</label></td>
                </tr>
                <tr>
                    <th>الدول</th>
                    <td>
                        <div class="gnap-countries">
                            <?php foreach (GNAP_Countries::country_codes() as $code) : ?>
                                <label><input type="checkbox" name="<?php echo esc_attr($name); ?>[countries][]" value="<?php echo esc_attr($code); ?>" <?php checked(in_array($code, $s['countries'], true)); ?>> <?php echo esc_html(GNAP_Countries::admin_label($code)); ?></label>
                            <?php endforeach; ?>
                        </div>
                    </td>
                </tr>
                <tr>
                    <th>مقالات عامة</th>
                    <td>
                        <?php foreach (array_diff(array_keys($countries), GNAP_Countries::country_codes()) as $code) : ?>
                            <label style="display:block"><input type="checkbox" name="<?php echo esc_attr($name); ?>[countries][]" value="<?php echo esc_attr($code); ?>" <?php checked(in_array($code, $s['countries'], true)); ?>> <?php echo esc_html(GNAP_Countries::admin_label($code)); ?></label>
                        <?php endforeach; ?>
                        <p class="description">مقال يومي لسعر الذهب عالمياً بالدولار بالعربية وبكل لغة تختارها. تُنشر مع باقي الدول حسب طريقة النشر، ولكل مقال إعداداته المنفصلة بالأسفل.</p>
                    </td>
                </tr>
                <tr>
                    <th>طريقة النشر</th>
                    <td>
                        <label><input type="radio" name="<?php echo esc_attr($name); ?>[schedule_mode]" value="interval" <?php checked($s['schedule_mode'], 'interval'); ?>> مقال كل
                            <input type="number" min="5" max="1440" style="width:80px" name="<?php echo esc_attr($name); ?>[interval]" value="<?php echo (int) $s['interval']; ?>"> دقيقة لدولة مختارة عشوائياً</label>
                        <br><label style="margin-inline-start:24px"><input type="checkbox" name="<?php echo esc_attr($name); ?>[random_gap]" value="1" <?php checked($s['random_gap']); ?>> تنويع الفاصل عشوائياً (±30%) ليبدو النشر طبيعياً</label>
                        <br><label><input type="radio" name="<?php echo esc_attr($name); ?>[schedule_mode]" value="fixed" <?php checked($s['schedule_mode'], 'fixed'); ?>> كل الدول دفعة واحدة في وقت النشر</label>
                        <p class="description">مثال: 22 دولة بفاصل 30 دقيقة تستغرق حوالي 11 ساعة يومياً.</p>
                    </td>
                </tr>
                <tr>
                    <th>وقت النشر / بداية النشر اليومي</th>
                    <td>
                        <input type="time" name="<?php echo esc_attr($name); ?>[publish_time]" value="<?php echo esc_attr($s['publish_time']); ?>">
                        <select name="<?php echo esc_attr($name); ?>[time_mode]">
                            <option value="local" <?php selected($s['time_mode'], 'local'); ?>>حسب التوقيت المحلي لكل دولة</option>
                            <option value="site" <?php selected($s['time_mode'], 'site'); ?>>حسب توقيت الموقع (<?php echo esc_html(wp_timezone_string()); ?>)</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th>حالة المقال</th>
                    <td>
                        <select name="<?php echo esc_attr($name); ?>[post_status]">
                            <option value="publish" <?php selected($s['post_status'], 'publish'); ?>>نشر مباشر</option>
                            <option value="draft" <?php selected($s['post_status'], 'draft'); ?>>مسودة</option>
                            <option value="pending" <?php selected($s['post_status'], 'pending'); ?>>بانتظار المراجعة</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th>التصنيف</th>
                    <td>
                        <select name="<?php echo esc_attr($name); ?>[category]">
                            <option value="0">— بدون تصنيف رئيسي —</option>
                            <?php foreach ($categories as $cat) : ?>
                                <option value="<?php echo (int) $cat->term_id; ?>" <?php selected($s['category'], $cat->term_id); ?>><?php echo esc_html($cat->name); ?></option>
                            <?php endforeach; ?>
                        </select>
                        <br><label><input type="checkbox" name="<?php echo esc_attr($name); ?>[sub_categories]" value="1" <?php checked($s['sub_categories']); ?>> إنشاء تصنيف فرعي لكل دولة تلقائياً (مثل: سعر الذهب في السعودية)</label>
                    </td>
                </tr>
                <tr>
                    <th>الكاتب</th>
                    <td>
                        <select name="<?php echo esc_attr($name); ?>[author]">
                            <option value="0">— أول مدير في الموقع —</option>
                            <?php foreach ($authors as $author) : ?>
                                <option value="<?php echo (int) $author->ID; ?>" <?php selected($s['author'], $author->ID); ?>><?php echo esc_html($author->display_name); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th>عند النشر اليدوي لمقال موجود</th>
                    <td>
                        <select name="<?php echo esc_attr($name); ?>[on_exists]">
                            <option value="update" <?php selected($s['on_exists'], 'update'); ?>>تحديث الأسعار في نفس المقال</option>
                            <option value="skip" <?php selected($s['on_exists'], 'skip'); ?>>تخطي</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th>الصورة البارزة</th>
                    <td>
                        <label><input type="checkbox" name="<?php echo esc_attr($name); ?>[image]" value="1" <?php checked($s['image']); ?>> توليد صورة تلقائية بالأسعار وعلم الدولة</label>
                        <br><select name="<?php echo esc_attr($name); ?>[image_format]">
                            <option value="portrait" <?php selected($s['image_format'], 'portrait'); ?>>بالطول 1080×1350 (مناسبة للموبايل)</option>
                            <option value="landscape" <?php selected($s['image_format'], 'landscape'); ?>>بالعرض 1200×630 (مناسبة للمشاركة على فيسبوك وواتساب)</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th>شعار الصورة</th>
                    <td>
                        <input type="url" dir="ltr" class="regular-text" name="<?php echo esc_attr($name); ?>[logo_url]" value="<?php echo esc_attr($s['logo_url']); ?>" placeholder="https://">
                        <p class="description">رابط صورة الشعار (PNG/JPG/WebP من مكتبة الوسائط). اتركه فارغاً لاستخدام شعار الموقع من إعدادات القالب تلقائياً.</p>
                    </td>
                </tr>
                <tr>
                    <th>بادئة الرابط</th>
                    <td><input type="text" dir="ltr" name="<?php echo esc_attr($name); ?>[slug_prefix]" value="<?php echo esc_attr($s['slug_prefix']); ?>"> <span class="gnap-muted" dir="ltr">/<?php echo esc_html($s['slug_prefix']); ?>-saudi-arabia-<?php echo esc_html(gmdate('Y-m-d')); ?>/</span></td>
                </tr>
                <tr>
                    <th>قوالب العنوان (مقالات الدول)</th>
                    <td>
                        <textarea name="<?php echo esc_attr($name); ?>[title_templates]" rows="6"><?php echo esc_textarea($s['title_templates']); ?></textarea>
                        <p class="description">قالب في كل سطر. يأخذ كل مقال قالباً مختلفاً، ولا يتكرر أي قالب قبل استخدام كل القوالب، وقوالب الأمس لا تُستخدم اليوم.</p>
                    </td>
                </tr>
                <tr>
                    <th>قوالب الوصف (مقالات الدول)</th>
                    <td><textarea name="<?php echo esc_attr($name); ?>[desc_templates]" rows="5"><?php echo esc_textarea($s['desc_templates']); ?></textarea></td>
                </tr>
                <tr>
                    <th>الوسوم (مقالات الدول)</th>
                    <td><input type="text" class="large-text" name="<?php echo esc_attr($name); ?>[tags]" value="<?php echo esc_attr($s['tags']); ?>"><p class="description">مفصولة بفاصلة.</p></td>
                </tr>
                <tr>
                    <th>ملاحظة أسفل المقال (مقالات الدول)</th>
                    <td><textarea name="<?php echo esc_attr($name); ?>[footer_note]" rows="3"><?php echo esc_textarea($s['footer_note']); ?></textarea></td>
                </tr>
            </table>
            <p class="description">
                المتغيرات المتاحة: <code>{country}</code> <code>{term}</code> <code>{weekday}</code> <code>{date}</code> <code>{day}</code> <code>{month}</code> <code>{year}</code>
                <code>{p24}</code> <code>{p22}</code> <code>{p21}</code> <code>{p18}</code> <code>{oz}</code> <code>{oz_usd}</code>
                <code>{currency}</code> <code>{unit}</code> <code>{symbol}</code> <code>{capital}</code> <code>{rate}</code>
            </p>

            <?php
            self::article_settings($s, 'global', 'مقال سعر الذهب عالمياً بالدولار (عربي)', $categories,
                'المتغيرات: <code>{weekday}</code> <code>{date}</code> <code>{day}</code> <code>{month}</code> <code>{year}</code> <code>{oz_usd}</code> <code>{p24}</code> <code>{p22}</code> <code>{p21}</code> <code>{p18}</code> <code>{time}</code> — الأسعار بالدولار.');
            foreach (GNAP_Languages::all() as $lang => $pack) {
                self::article_settings($s, $lang, 'مقال ' . $pack['name'] . ' — ' . $pack['admin_label'], $categories,
                    'المتغيرات: <code>{weekday}</code> <code>{date}</code> <code>{day}</code> <code>{month}</code> <code>{year}</code> <code>{time}</code>'
                    . ' — أرقام فقط: <code>{oz}</code> <code>{p24}</code> <code>{p22}</code> <code>{p21}</code> <code>{p18}</code>'
                    . ' — مع رمز الدولار بتنسيق اللغة: <code>{oz_money}</code> <code>{p24_money}</code> <code>{p22_money}</code> <code>{p21_money}</code> <code>{p18_money}</code>');
            }
            ?>
            <?php submit_button('حفظ الإعدادات'); ?>
        </form>
        <?php
    }

    /**
     * إعدادات مستقلة لمقال عام (عالمي/إنجليزي): لا يأخذ شيئاً من إعدادات مقالات الدول
     */
    private static function article_settings($s, $prefix, $heading, $categories, $vars_help) {
        $name = GNAP_Settings::OPTION;
        $field = function ($key) use ($name, $prefix) {
            return esc_attr($name . '[' . $prefix . '_' . $key . ']');
        };
        $ltr = $prefix === 'global' ? '' : ' dir="ltr"';
        ?>
        <details class="gnap-article-settings">
        <summary><?php echo esc_html($heading); ?></summary>
        <table class="form-table" role="presentation">
            <tr>
                <th>قوالب العنوان</th>
                <td><textarea<?php echo $ltr; ?> name="<?php echo $field('title_templates'); ?>" rows="8"><?php echo esc_textarea($s[$prefix . '_title_templates']); ?></textarea>
                    <p class="description">قالب في كل سطر، دون تكرار حتى تُستخدم كل القوالب.</p></td>
            </tr>
            <tr>
                <th>قوالب الوصف (Meta Description)</th>
                <td><textarea<?php echo $ltr; ?> name="<?php echo $field('desc_templates'); ?>" rows="4"><?php echo esc_textarea($s[$prefix . '_desc_templates']); ?></textarea></td>
            </tr>
            <tr>
                <th>قوالب مقدمة المقال</th>
                <td><textarea<?php echo $ltr; ?> name="<?php echo $field('intro_templates'); ?>" rows="6"><?php echo esc_textarea($s[$prefix . '_intro_templates']); ?></textarea>
                    <p class="description">الفقرة الأولى في المقال، قالب في كل سطر.</p></td>
            </tr>
            <tr>
                <th>الوسوم</th>
                <td><input type="text"<?php echo $ltr; ?> class="large-text" name="<?php echo $field('tags'); ?>" value="<?php echo esc_attr($s[$prefix . '_tags']); ?>"><p class="description">مفصولة بفاصلة.</p></td>
            </tr>
            <tr>
                <th>ملاحظة أسفل المقال</th>
                <td><textarea<?php echo $ltr; ?> name="<?php echo $field('footer_note'); ?>" rows="3"><?php echo esc_textarea($s[$prefix . '_footer_note']); ?></textarea></td>
            </tr>
            <tr>
                <th>التصنيف</th>
                <td>
                    <select name="<?php echo $field('category'); ?>">
                        <option value="0">— تصنيف خاص يُنشأ تلقائياً —</option>
                        <?php foreach ($categories as $cat) : ?>
                            <option value="<?php echo (int) $cat->term_id; ?>" <?php selected($s[$prefix . '_category'], $cat->term_id); ?>><?php echo esc_html($cat->name); ?></option>
                        <?php endforeach; ?>
                    </select>
                </td>
            </tr>
            <tr>
                <th>بادئة الرابط</th>
                <td><input type="text" dir="ltr" name="<?php echo $field('slug'); ?>" value="<?php echo esc_attr($s[$prefix . '_slug']); ?>"> <span class="gnap-muted" dir="ltr">/<?php echo esc_html($s[$prefix . '_slug']); ?>-<?php echo esc_html(gmdate('Y-m-d')); ?>/</span></td>
            </tr>
        </table>
        <p class="description"><?php echo wp_kses($vars_help, ['code' => []]); ?></p>
        </details>
        <?php
    }

    private static function status_table($settings, $countries) {
        $labels = ['created' => 'تم النشر', 'updated' => 'تم التحديث', 'skipped' => 'موجود مسبقاً', 'error' => 'خطأ'];
        echo '<div class="gnap-card"><h2>حالة الدول</h2><table class="widefat striped"><thead><tr><th>الدولة</th><th>العملة</th><th>التاريخ المحلي</th><th>آخر نتيجة</th><th>المقال</th><th>الموعد القادم</th></tr></thead><tbody>';
        foreach ($settings['countries'] as $code) {
            if (!isset($countries[$code])) {
                continue;
            }
            $status = GNAP_Log::status($code);
            $today = GNAP_Countries::local_date($code)['ymd'];
            $cell = '<span class="gnap-muted">—</span>';
            $link = '';
            if ($status) {
                $class = $status['result'] === 'error' ? 'gnap-err' : 'gnap-ok';
                $cell = '<span class="' . $class . '">' . esc_html($labels[$status['result']] ?? $status['result']) . '</span> <span class="gnap-muted">(' . esc_html($status['date']) . ')</span>';
                if ($status['result'] === 'error') {
                    $cell .= '<br><small>' . esc_html($status['message']) . '</small>';
                }
                if ($status['post_id'] && get_post($status['post_id'])) {
                    $link = '<a href="' . esc_url(get_permalink($status['post_id'])) . '" target="_blank">عرض</a> | <a href="' . esc_url(get_edit_post_link($status['post_id'])) . '">تحرير</a>';
                }
            }
            echo '<tr><td>' . esc_html(GNAP_Countries::admin_label($code)) . '</td><td>' . esc_html($countries[$code]['currency']) . '</td><td>' . esc_html($today) . '</td><td>' . $cell . '</td><td>' . $link . '</td><td dir="ltr" style="text-align:right">' . esc_html(GNAP_Scheduler::next_run_label($code, $settings)) . '</td></tr>';
        }
        echo '</tbody></table></div>';
    }

    private static function log_table() {
        $entries = GNAP_Log::entries();
        echo '<div class="gnap-card"><h2>السجل</h2>';
        if (!$entries) {
            echo '<p class="gnap-muted">لا توجد عمليات بعد.</p></div>';
            return;
        }
        echo '<table class="widefat striped"><thead><tr><th style="width:150px">الوقت</th><th style="width:70px">الدولة</th><th>الرسالة</th></tr></thead><tbody>';
        foreach (array_slice($entries, 0, 50) as $entry) {
            $class = $entry['level'] === 'error' ? 'gnap-err' : '';
            echo '<tr><td>' . esc_html(wp_date('Y-m-d H:i', $entry['time'])) . '</td><td>' . esc_html($entry['code']) . '</td><td class="' . $class . '">' . esc_html($entry['message']) . '</td></tr>';
        }
        echo '</tbody></table>';
        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" style="margin-top:10px">';
        wp_nonce_field('gnap_clear_log');
        echo '<input type="hidden" name="action" value="gnap_clear_log">';
        submit_button('مسح السجل', 'delete', 'submit', false);
        echo '</form></div>';
    }
}
