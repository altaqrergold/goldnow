<?php
/**
 * توليد عنوان ووصف ومحتوى المقال اليومي
 *
 * ثلاثة أنواع من المقالات، لكل منها إعداداته المنفصلة:
 * - مقال الدولة (عربي، بالعملة المحلية)
 * - مقال سعر الذهب عالمياً (عربي، بالدولار)
 * - مقالات اللغات الأجنبية بالدولار (الإنجليزية، الفرنسية، الألمانية، الإيطالية، البرتغالية، الروسية، الهندية)
 *
 * العناوين والأوصاف والمقدمات والعناوين الفرعية تُختار عبر GNAP_Rotator حتى لا تتكرر بين الأيام.
 */

if (!defined('ABSPATH')) {
    exit;
}

class GNAP_Content {

    const PURITY = ['24k' => '99.9%', '22k' => '91.6%', '21k' => '87.5%', '18k' => '75%', '14k' => '58.5%', '12k' => '50%'];

    private static $commit = true;
    private static $fixed = [];
    private static $used = [];

    /**
     * @param array      $snapshot    ناتج GNAP_Prices::snapshot
     * @param array      $date        ناتج GNAP_Countries::local_date
     * @param array|null $previous    أسعار آخر مقال سابق لنفس الدولة ['date' => ..., 'local' => [...]]
     * @param string     $country_url رابط صفحة الدولة في الموقع (اختياري)
     * @param array      $variants    القوالب المستخدمة سابقاً (عند تحديث مقال موجود يُحافظ على نفس العنوان)
     * @param bool       $commit      false للمعاينة: لا يُستهلك أي قالب من الرزمة
     */
    public static function build($snapshot, $date, $previous = null, $country_url = '', $variants = [], $commit = true) {
        self::$commit = $commit;
        self::$fixed = is_array($variants) ? $variants : [];
        self::$used = [];

        $country = $snapshot['country'];
        if ($country['lang'] !== 'ar') {
            $built = self::build_foreign($snapshot, $date, $previous, $country['lang']);
        } elseif ($country['global']) {
            $built = self::build_global($snapshot, $date, $previous);
        } else {
            $built = self::build_country($snapshot, $date, $previous, $country_url);
        }
        $built['variants'] = self::$used;
        return $built;
    }

    /* =====================================================================
     * مقال الدولة
     * ===================================================================== */

    private static function build_country($snapshot, $date, $previous, $country_url) {
        $settings = GNAP_Settings::get();
        $vars = self::vars($snapshot, $date);

        $title = self::fill(self::choose('title', GNAP_Settings::lines($settings['title_templates'])), $vars);
        $description = self::fill(self::choose('desc', GNAP_Settings::lines($settings['desc_templates'])), $vars);

        $change = self::change($snapshot, $previous, '21k');
        $faq = self::faq($snapshot, $vars);

        $html  = self::intro($snapshot, $date, $vars, $change);
        $html .= self::carat_table($snapshot, $vars);
        $html .= self::ounce_section($snapshot, $vars);
        $html .= self::buy_sell_section($snapshot, $vars);
        $html .= self::comparison_section($snapshot, $vars, $previous);
        $html .= self::faq_section($faq, $vars);
        $html .= self::footer($snapshot, $vars, $settings, $country_url);

        return [
            'title'         => $title,
            'description'   => $description,
            'content'       => $html,
            'faq'           => $faq,
            'tags'          => self::tags($settings['tags'], $vars),
            'focus_keyword' => self::fill('{term} الذهب في {country} اليوم', $vars),
            'change_pct'    => $change ? $change['pct'] : null,
        ];
    }

    private static function vars($snapshot, $date) {
        $c = $snapshot['country'];
        $l = $snapshot['local'];
        return [
            '{country}'  => $c['name'],
            '{term}'     => $c['term'],
            '{capital}'  => $c['capital'],
            '{currency}' => $c['currency_name'],
            '{unit}'     => $c['unit'],
            '{symbol}'   => $c['symbol'],
            '{weekday}'  => $date['weekday'],
            '{date}'     => $date['date'],
            '{day}'      => $date['day'],
            '{month}'    => $date['month'],
            '{year}'     => $date['year'],
            '{time}'     => self::updated_time($snapshot),
            '{p24}'      => GNAP_Prices::format($l['24k']),
            '{p22}'      => GNAP_Prices::format($l['22k']),
            '{p21}'      => GNAP_Prices::format($l['21k']),
            '{p18}'      => GNAP_Prices::format($l['18k']),
            '{oz}'       => GNAP_Prices::format($l['24k_oz']),
            '{oz_usd}'   => GNAP_Prices::format($snapshot['usd']['24k_oz'], 2),
            '{rate}'     => GNAP_Prices::format($snapshot['rate'], $snapshot['rate'] < 1 ? 4 : ($snapshot['rate'] < 10 ? 3 : 2)),
        ];
    }

    private static function intro($s, $date, $v, $change) {
        $variants = [
            'سجل {term} جرام الذهب عيار 21 في {country} اليوم {weekday} {date} نحو {p21} {unit}، فيما بلغ {term} جرام الذهب عيار 24 نحو {p24} {unit}، وسجل عيار 18 نحو {p18} {unit}، وذلك وفقاً لآخر تحديث للسعر العالمي للذهب وسعر صرف الدولار في {country}.',
            'نستعرض في هذا التقرير {term} الذهب اليوم في {country} {weekday} {date}، حيث بلغ {term} الجرام عيار 21 الأكثر تداولاً نحو {p21} {unit}، بينما سجل عيار 24 نحو {p24} {unit}، وعيار 22 نحو {p22} {unit}.',
            'يتابع المواطنون في {country} {term} الذهب يومياً قبل الشراء أو البيع، واليوم {weekday} {date} سجل جرام الذهب عيار 21 نحو {p21} {unit}، وعيار 24 نحو {p24} {unit}، في حين سجلت أونصة الذهب {oz} {unit}.',
            'تشهد أسعار الذهب في {country} اليوم {weekday} {date} متابعة واسعة، إذ بلغ {term} الجرام عيار 21 نحو {p21} {unit}، وعيار 24 نحو {p24} {unit}، وعيار 18 نحو {p18} {unit}.',
            'بلغ {term} جرام الذهب عيار 24 في {country} اليوم {weekday} {date} نحو {p24} {unit}، في حين سجل عيار 21 نحو {p21} {unit}، وعيار 22 نحو {p22} {unit}، بحسب آخر تحديث لأسعار الذهب عالمياً.',
            'إليك أحدث {term} للذهب في {country} اليوم {weekday} {date}، حيث سجل الجرام عيار 21 نحو {p21} {unit}، بينما بلغ عيار 18 نحو {p18} {unit}، وسجلت أونصة الذهب {oz} {unit}.',
            'في تحديث جديد لأسعار الذهب اليوم {weekday} {date}، سجل {term} جرام الذهب عيار 21 في {country} نحو {p21} {unit}، وعيار 24 نحو {p24} {unit}، وذلك على أساس سعر الأونصة عالمياً البالغ {oz_usd} دولار.',
            'هل تبحث عن {term} الذهب في {country} اليوم؟ سجل جرام الذهب عيار 21 اليوم {weekday} {date} نحو {p21} {unit}، وعيار 24 نحو {p24} {unit}، وعيار 18 نحو {p18} {unit}.',
        ];
        $html = '<p class="gnap-lead">' . self::e(self::fill(self::choose('intro', $variants), $v)) . '</p>';

        $sentences = [];
        if ($change) {
            $pct = abs($change['pct']);
            if ($change['source'] === 'local') {
                if ($pct < 0.05) {
                    $sentences[] = self::fill('واستقر {term} الذهب عيار 21 في {country} دون تغيير يُذكر مقارنة بسعر أمس.', $v);
                } else {
                    $sentences[] = self::fill(sprintf(
                        '%s {term} الذهب عيار 21 بمقدار %s {unit} بنسبة %s%% مقارنة بسعر أمس البالغ %s {unit}.',
                        $change['diff'] > 0 ? 'وارتفع' : 'وانخفض',
                        GNAP_Prices::format(abs($change['diff'])),
                        number_format($pct, 2),
                        GNAP_Prices::format($change['old'])
                    ), $v);
                }
            } elseif ($pct >= 0.05) {
                $sentences[] = sprintf(
                    'وعلى المستوى العالمي، %s سعر أونصة الذهب بنسبة %s%% مقارنة بأمس لتسجل %s دولار.',
                    $change['diff'] > 0 ? 'ارتفع' : 'انخفض',
                    number_format($pct, 2),
                    $v['{oz_usd}']
                );
            }
        }
        $sentences[] = self::fill('ويُحسب السعر على أساس سعر صرف الدولار الأمريكي البالغ {rate} {unit}.', $v);
        if ($date['is_weekend_market']) {
            $sentences[] = 'ويأتي ذلك مع إغلاق البورصات العالمية خلال عطلة نهاية الأسبوع، لذا تبقى الأسعار قريبة من مستويات إغلاق يوم الجمعة.';
        }

        return $html . '<p>' . self::e(implode(' ', $sentences)) . '</p>';
    }

    private static function carat_table($s, $v) {
        $c = $s['country'];
        $html  = self::heading('h_table', [
            '{term} الذهب اليوم في {country} حسب العيار',
            'أسعار جرام الذهب في {country} لجميع العيارات',
            'جدول {term} الذهب في {country} اليوم {date}',
        ], $v);
        $html .= '<figure class="wp-block-table gnap-table"><table><thead><tr>';
        $html .= '<th>العيار</th><th>' . self::e('سعر الجرام (' . $c['currency_name'] . ')') . '</th><th>سعر الجرام (دولار)</th>';
        $html .= '</tr></thead><tbody>';

        foreach (GNAP_Prices::CARATS as $carat) {
            $html .= '<tr><td>' . self::e(GNAP_Prices::carat_label($carat)) . '</td>'
                . '<td><strong>' . self::e(GNAP_Prices::format($s['local'][$carat])) . '</strong></td>'
                . '<td>' . self::e(GNAP_Prices::format($s['usd'][$carat], 2)) . '</td></tr>';
        }
        if ($c['pound']) {
            $html .= '<tr><td>' . self::e($c['pound'] . ' (8 جرام عيار 21)') . '</td>'
                . '<td><strong>' . self::e(GNAP_Prices::format($s['local']['pound'])) . '</strong></td>'
                . '<td>' . self::e(GNAP_Prices::format($s['usd']['pound'], 2)) . '</td></tr>';
        }
        $html .= '<tr><td>أونصة الذهب (31.1 جرام)</td>'
            . '<td><strong>' . self::e(GNAP_Prices::format($s['local']['24k_oz'])) . '</strong></td>'
            . '<td>' . self::e(GNAP_Prices::format($s['usd']['24k_oz'], 2)) . '</td></tr>';

        return $html . '</tbody></table></figure>';
    }

    private static function ounce_section($s, $v) {
        $html  = self::heading('h_ounce', [
            '{term} أونصة الذهب اليوم في {country}',
            'كم {term} أونصة الذهب في {country} اليوم؟',
            'أونصة الذهب في {country} مقابل السعر العالمي',
        ], $v);
        $text  = self::fill('سجلت أونصة الذهب اليوم {oz} {unit} في {country}، ما يعادل {oz_usd} دولار أمريكي وفق السعر العالمي.', $v);
        $text .= self::range_text($s, 'ar');
        return $html . '<p>' . self::e($text) . '</p>';
    }

    private static function buy_sell_section($s, $v) {
        // إذا لم تُضبط نسب البيع والشراء في Goldx فلا فائدة من الجدول
        $first = reset($s['buy_sell']);
        if (abs($first['buy'] - $first['sell']) < 0.0001) {
            return '';
        }
        $html  = self::heading('h_buy_sell', [
            'أسعار بيع وشراء الذهب في {country} اليوم',
            '{term} بيع وشراء جرام الذهب في {country}',
            'الفرق بين سعر البيع والشراء للذهب في {country}',
        ], $v);
        $html .= '<figure class="wp-block-table gnap-table"><table><thead><tr><th>العيار</th><th>الشراء</th><th>البيع</th></tr></thead><tbody>';
        foreach ($s['buy_sell'] as $carat => $row) {
            $html .= '<tr><td>' . self::e(GNAP_Prices::carat_label($carat)) . '</td>'
                . '<td>' . self::e(GNAP_Prices::format($row['buy']) . ' ' . $v['{unit}']) . '</td>'
                . '<td>' . self::e(GNAP_Prices::format($row['sell']) . ' ' . $v['{unit}']) . '</td></tr>';
        }
        return $html . '</tbody></table></figure>';
    }

    private static function comparison_section($s, $v, $previous) {
        if (!$previous || empty($previous['local'])) {
            return '';
        }
        return self::heading('h_compare', [
            '{term} الذهب في {country} اليوم مقارنة بأمس',
            'كيف تغير {term} الذهب في {country} عن أمس؟',
            'مقارنة أسعار الذهب في {country} بآخر تحديث سابق',
        ], $v) . self::comparison_table($s, $previous, ['24k', '21k', '18k', '24k_oz'], null, 'ar');
    }

    private static function faq($s, $v) {
        $c = $s['country'];
        $faq = [
            [
                'q' => self::fill('كم {term} جرام الذهب عيار 21 في {country} اليوم؟', $v),
                'a' => self::fill('يبلغ {term} جرام الذهب عيار 21 في {country} اليوم {weekday} {date} نحو {p21} {currency}.', $v),
            ],
            [
                'q' => self::fill('كم {term} جرام الذهب عيار 24 في {country} اليوم؟', $v),
                'a' => self::fill('سجل جرام الذهب عيار 24 في {country} اليوم نحو {p24} {currency}، وهو أعلى العيارات نقاءً.', $v),
            ],
            [
                'q' => self::fill('كم {term} جرام الذهب عيار 18 في {country}؟', $v),
                'a' => self::fill('يبلغ {term} جرام الذهب عيار 18 في {country} اليوم نحو {p18} {currency}.', $v),
            ],
            [
                'q' => self::fill('كم {term} أونصة الذهب في {country} اليوم؟', $v),
                'a' => self::fill('سجلت أونصة الذهب اليوم {oz} {currency}، ما يعادل {oz_usd} دولار أمريكي.', $v),
            ],
        ];
        if ($c['pound']) {
            $faq[] = [
                'q' => self::fill('كم سعر ' . $c['pound'] . ' في {country} اليوم؟', $v),
                'a' => self::fill('يبلغ سعر ' . $c['pound'] . ' (8 جرامات من عيار 21) اليوم نحو ' . GNAP_Prices::format($s['local']['pound']) . ' {currency}.', $v),
            ];
        }
        $faq[] = [
            'q' => 'هل تشمل هذه الأسعار المصنعية؟',
            'a' => 'لا، الأسعار المذكورة هي أسعار الذهب الخام فقط، ولا تشمل تكلفة المصنعية أو الضرائب التي تختلف من محل لآخر وحسب نوع المشغولات.',
        ];
        return $faq;
    }

    private static function faq_section($faq, $v) {
        $html = self::heading('h_faq', [
            'أسئلة شائعة حول {term} الذهب في {country}',
            'أسئلة يطرحها المشترون عن الذهب في {country}',
            'إجابات سريعة عن {term} الذهب في {country} اليوم',
        ], $v) . '<div class="gnap-faq">';
        foreach ($faq as $item) {
            $html .= '<h3>' . self::e($item['q']) . '</h3><p>' . self::e($item['a']) . '</p>';
        }
        return $html . '</div>';
    }

    private static function footer($s, $v, $settings, $country_url) {
        $html = '';
        if ($country_url) {
            $follow = self::choose('follow', [
                'لمتابعة {term} الذهب في {country} لحظة بلحظة:',
                'تابع تحديثات {term} الذهب في {country} أولاً بأول:',
                'للاطلاع على آخر {term} للذهب في {country}:',
            ]);
            $html .= '<p class="gnap-follow">' . self::e(self::fill($follow, $v))
                . ' <a href="' . esc_url($country_url) . '">' . self::e(self::fill('{term} الذهب في {country} الآن', $v)) . '</a></p>';
        }

        $note = trim($settings['footer_note']);
        if ($s['country']['parallel']) {
            $note .= ($note ? ' ' : '') . self::fill('وننوه إلى أن سعر صرف {currency} في السوق الموازية قد يختلف عن السعر الرسمي، ما ينعكس على أسعار الذهب لدى الصاغة.', $v);
        }
        $html .= '<p class="gnap-note">' . self::e(self::fill('آخر تحديث للأسعار: الساعة {time} بتوقيت {capital}.', $v));
        if ($note) {
            $html .= ' ' . self::e(self::fill($note, $v));
        }
        return $html . '</p>';
    }

    /* =====================================================================
     * مقال سعر الذهب عالمياً بالدولار (عربي)
     * ===================================================================== */

    private static function build_global($snapshot, $date, $previous) {
        $settings = GNAP_Settings::get();
        $v = self::vars($snapshot, $date);
        // الأسعار بالدولار: كسور عشرية دائماً
        foreach (['24k' => '{p24}', '22k' => '{p22}', '21k' => '{p21}', '18k' => '{p18}', '24k_oz' => '{oz}'] as $carat => $key) {
            $v[$key] = GNAP_Prices::format($snapshot['usd'][$carat], 2);
        }

        $title = self::fill(self::choose('g_title', GNAP_Settings::lines($settings['global_title_templates'])), $v);
        $description = self::fill(self::choose('g_desc', GNAP_Settings::lines($settings['global_desc_templates'])), $v);
        $change = self::change($snapshot, $previous, '24k_oz');
        $usd = $snapshot['usd'];

        // المقدمة
        $sentences = [];
        if ($change) {
            if (abs($change['pct']) < 0.05) {
                $sentences[] = 'واستقر سعر أونصة الذهب دون تغيير يُذكر مقارنة بسعر أمس.';
            } else {
                $sentences[] = sprintf(
                    '%s سعر أونصة الذهب بمقدار %s دولار بنسبة %s%% مقارنة بسعر أمس البالغ %s دولار.',
                    $change['diff'] > 0 ? 'وارتفع' : 'وانخفض',
                    GNAP_Prices::format(abs($change['diff']), 2),
                    number_format(abs($change['pct']), 2),
                    GNAP_Prices::format($change['old'], 2)
                );
            }
        }
        if ($date['is_weekend_market']) {
            $sentences[] = 'ويأتي ذلك مع إغلاق البورصات العالمية خلال عطلة نهاية الأسبوع، لذا تبقى الأسعار قريبة من مستويات إغلاق يوم الجمعة.';
        }
        $html = '<p class="gnap-lead">' . self::e(self::fill(self::choose('g_intro', GNAP_Settings::lines($settings['global_intro_templates'])), $v)) . '</p>';
        if ($sentences) {
            $html .= '<p>' . self::e(implode(' ', $sentences)) . '</p>';
        }

        // جدول العيارات بالدولار
        $html .= self::heading('g_h_table', [
            'سعر جرام الذهب بالدولار اليوم حسب العيار',
            'أسعار الذهب عالمياً اليوم لجميع العيارات',
            'جدول أسعار الذهب بالدولار اليوم {date}',
        ], $v);
        $html .= '<figure class="wp-block-table gnap-table"><table><thead><tr><th>العيار</th><th>سعر الجرام (دولار)</th><th>نسبة النقاء</th></tr></thead><tbody>';
        foreach (GNAP_Prices::CARATS as $carat) {
            $html .= '<tr><td>' . self::e(GNAP_Prices::carat_label($carat)) . '</td>'
                . '<td><strong>' . self::e(GNAP_Prices::format($usd[$carat], 2)) . '</strong></td>'
                . '<td>' . self::e(self::PURITY[$carat]) . '</td></tr>';
        }
        $html .= '<tr><td>أونصة الذهب (31.1 جرام)</td><td><strong>' . self::e(GNAP_Prices::format($usd['24k_oz'], 2)) . '</strong></td><td>99.9%</td></tr>';
        $html .= '<tr><td>كيلو الذهب عيار 24</td><td><strong>' . self::e(GNAP_Prices::format($usd['24k'] * 1000, 0)) . '</strong></td><td>99.9%</td></tr>';
        $html .= '</tbody></table></figure>';

        // الأونصة
        $html .= self::heading('g_h_ounce', [
            'سعر أونصة الذهب عالمياً اليوم',
            'أداء أونصة الذهب خلال آخر 30 يوماً',
            'كم سعر أونصة الذهب في البورصة العالمية؟',
        ], $v);
        $html .= '<p>' . self::e(self::fill('تُعد الأونصة (31.1 جرام) وحدة التسعير الرئيسية للذهب في البورصات العالمية، وقد سجلت اليوم {oz_usd} دولار أمريكي.', $v) . self::range_text($snapshot, 'ar')) . '</p>';

        // الدول العربية
        $rows = GNAP_Prices::countries_table(self::table_codes($settings));
        if ($rows) {
            $html .= self::heading('g_h_arab', [
                'سعر الذهب في الدول العربية اليوم',
                'سعر جرام الذهب عيار 21 في الدول العربية اليوم {date}',
                'أسعار الذهب بالعملات العربية اليوم',
            ], $v);
            $html .= '<p>' . self::e('وبناءً على السعر العالمي وأسعار الصرف الرسمية، جاءت أسعار جرام الذهب في الدول العربية اليوم على النحو التالي:') . '</p>';
            $html .= '<figure class="wp-block-table gnap-table"><table><thead><tr><th>الدولة</th><th>عيار 21</th><th>عيار 24</th></tr></thead><tbody>';
            foreach ($rows as $code => $row) {
                $c = $row['country'];
                $name = self::e($c['name']);
                $url = self::today_post_url($code);
                if ($url) {
                    $name = '<a href="' . esc_url($url) . '">' . $name . '</a>';
                }
                $html .= '<tr><td>' . $name . '</td>'
                    . '<td><strong>' . self::e(GNAP_Prices::format($row['21k']) . ' ' . $c['unit']) . '</strong></td>'
                    . '<td>' . self::e(GNAP_Prices::format($row['24k']) . ' ' . $c['unit']) . '</td></tr>';
            }
            $html .= '</tbody></table></figure>';
        }

        // المقارنة
        if ($previous && !empty($previous['local'])) {
            $html .= self::heading('g_h_compare', [
                'سعر الذهب عالمياً اليوم مقارنة بأمس',
                'كيف تغير سعر الذهب العالمي عن أمس؟',
                'مقارنة أسعار الذهب بالدولار بآخر تحديث سابق',
            ], $v);
            $html .= self::comparison_table($snapshot, $previous, ['24k', '22k', '21k', '18k', '24k_oz'], 2, 'ar');
        }

        // الأسئلة الشائعة
        $faq = [
            ['q' => 'كم سعر أونصة الذهب عالمياً اليوم؟', 'a' => self::fill('سجلت أونصة الذهب اليوم {weekday} {date} نحو {oz_usd} دولار أمريكي.', $v)],
            ['q' => 'كم سعر جرام الذهب عيار 24 بالدولار اليوم؟', 'a' => self::fill('يبلغ سعر جرام الذهب عيار 24 اليوم نحو {p24} دولار أمريكي.', $v)],
            ['q' => 'كم سعر جرام الذهب عيار 21 بالدولار اليوم؟', 'a' => self::fill('يبلغ سعر جرام الذهب عيار 21 اليوم نحو {p21} دولار، وعيار 18 نحو {p18} دولار.', $v)],
            ['q' => 'كم جراماً في أونصة الذهب؟', 'a' => 'تعادل أونصة الذهب (الأونصة التروي) نحو 31.1 جرام من الذهب الخالص.'],
            ['q' => 'كيف يُحسب سعر الذهب في الدول العربية؟', 'a' => 'يُقسم سعر الأونصة العالمي على 31.1 لمعرفة سعر جرام عيار 24 بالدولار، ثم يُضرب في سعر صرف الدولار بالعملة المحلية، ويُحسب عيار 21 بضرب سعر عيار 24 في 21 ثم القسمة على 24.'],
        ];
        $html .= self::heading('g_h_faq', [
            'أسئلة شائعة حول سعر الذهب عالمياً',
            'إجابات سريعة عن سعر الذهب بالدولار اليوم',
            'أسئلة يطرحها المهتمون بسعر الذهب العالمي',
        ], $v) . '<div class="gnap-faq">';
        foreach ($faq as $item) {
            $html .= '<h3>' . self::e($item['q']) . '</h3><p>' . self::e($item['a']) . '</p>';
        }
        $html .= '</div>';

        $html .= '<p class="gnap-note">' . self::e(self::fill('آخر تحديث للأسعار: الساعة {time} بتوقيت غرينتش.', $v));
        $note = trim($settings['global_footer_note']);
        if ($note) {
            $html .= ' ' . self::e(self::fill($note, $v));
        }
        $html .= '</p>';

        return [
            'title'         => $title,
            'description'   => $description,
            'content'       => $html,
            'faq'           => $faq,
            'tags'          => self::tags($settings['global_tags'], $v),
            'focus_keyword' => 'سعر الذهب عالمياً اليوم',
            'change_pct'    => $change ? $change['pct'] : null,
        ];
    }

    /* =====================================================================
     * المقالات باللغات الأجنبية (الإنجليزية، الفرنسية، الألمانية...) من حزم GNAP_Languages
     * ===================================================================== */

    private static function build_foreign($snapshot, $date, $previous, $lang) {
        $settings = GNAP_Settings::get();
        $p = GNAP_Languages::get($lang);
        $t = $p['s'];
        $usd = $snapshot['usd'];
        $num = function ($value, $decimals = 2) use ($lang) {
            return GNAP_Languages::num($value, $decimals, $lang);
        };
        $money = function ($value, $decimals = 2) use ($lang) {
            return GNAP_Languages::money($value, $decimals, $lang);
        };

        $v = GNAP_Languages::date($lang, $date['ymd']) + ['{time}' => self::updated_time($snapshot)];
        foreach (['24k' => 'p24', '22k' => 'p22', '21k' => 'p21', '18k' => 'p18', '24k_oz' => 'oz'] as $carat => $key) {
            $v['{' . $key . '}'] = $num($usd[$carat]);
            $v['{' . $key . '_money}'] = $money($usd[$carat]);
        }
        $v['{oz_usd}'] = $v['{oz}'];

        $title = self::fill(self::choose($lang . '_title', GNAP_Settings::lines($settings[$lang . '_title_templates'])), $v);
        $description = self::fill(self::choose($lang . '_desc', GNAP_Settings::lines($settings[$lang . '_desc_templates'])), $v);
        $change = self::change($snapshot, $previous, '24k_oz');

        // المقدمة
        $sentences = [];
        if ($change) {
            if (abs($change['pct']) < 0.05) {
                $sentences[] = $t['change_flat'];
            } else {
                $sentences[] = sprintf(
                    $change['diff'] > 0 ? $t['change_up'] : $t['change_down'],
                    $money(abs($change['diff'])),
                    $num(abs($change['pct'])),
                    $money($change['old'])
                );
            }
        }
        if ($date['is_weekend_market']) {
            $sentences[] = $t['weekend'];
        }
        $html = '<p class="gnap-lead">' . self::e(self::fill(self::choose($lang . '_intro', GNAP_Settings::lines($settings[$lang . '_intro_templates'])), $v)) . '</p>';
        if ($sentences) {
            $html .= '<p>' . self::e(implode(' ', $sentences)) . '</p>';
        }

        // العيارات
        $html .= self::heading($lang . '_h_table', $t['h_table'], $v);
        $html .= '<figure class="wp-block-table gnap-table"><table><thead><tr><th>' . self::e($t['th_karat']) . '</th><th>' . self::e($t['th_gram']) . '</th><th>' . self::e($t['th_purity']) . '</th></tr></thead><tbody>';
        foreach (GNAP_Prices::CARATS as $carat) {
            $html .= '<tr><td>' . self::e(self::karat_label($carat, $lang)) . '</td>'
                . '<td><strong>' . self::e($money($usd[$carat])) . '</strong></td>'
                . '<td>' . self::e(str_replace('.', $p['dec'], self::PURITY[$carat])) . '</td></tr>';
        }
        $html .= '</tbody></table></figure>';

        // الأوزان: جرام، 10 جرام، تولة، أونصة، كيلو
        $html .= self::heading($lang . '_h_units', $t['h_units'], $v);
        $weights = [1, 10, 11.6638, 'oz', 1000];
        $html .= '<figure class="wp-block-table gnap-table"><table><thead><tr><th>' . self::e($t['th_weight']) . '</th><th>' . self::e($t['th_price']) . '</th></tr></thead><tbody>';
        foreach ($weights as $i => $grams) {
            $price = $grams === 'oz' ? $usd['24k_oz'] : $usd['24k'] * $grams;
            $html .= '<tr><td>' . self::e($t['weights'][$i]) . '</td><td><strong>' . self::e($money($price, $grams === 1000 ? 0 : 2)) . '</strong></td></tr>';
        }
        $html .= '</tbody></table></figure>';

        // الأونصة
        $html .= self::heading($lang . '_h_ounce', $t['h_ounce'], $v);
        $html .= '<p>' . self::e(self::fill($t['ounce_text'], $v) . self::range_text($snapshot, $lang)) . '</p>';

        // الدول العربية
        $rows = GNAP_Prices::countries_table(self::table_codes($settings));
        if ($rows) {
            $html .= self::heading($lang . '_h_arab', $t['h_arab'], $v);
            $html .= '<p>' . self::e($t['arab_text']) . '</p>';
            $html .= '<figure class="wp-block-table gnap-table"><table><thead><tr><th>' . self::e($t['th_country']) . '</th><th>' . self::e($t['th_21']) . '</th><th>' . self::e($t['th_24']) . '</th></tr></thead><tbody>';
            foreach ($rows as $code => $row) {
                $c = $row['country'];
                $name = isset($p['countries'][$code]) ? $p['countries'][$code] : $c['name_en'];
                $html .= '<tr><td>' . self::e($name) . '</td>'
                    . '<td><strong>' . self::e($num($row['21k'], null) . ' ' . $c['currency']) . '</strong></td>'
                    . '<td>' . self::e($num($row['24k'], null) . ' ' . $c['currency']) . '</td></tr>';
            }
            $html .= '</tbody></table></figure>';
        }

        // المقارنة
        if ($previous && !empty($previous['local'])) {
            $html .= self::heading($lang . '_h_compare', $t['h_compare'], $v);
            $html .= self::comparison_table($snapshot, $previous, ['24k', '22k', '21k', '18k', '24k_oz'], 2, $lang);
        }

        // الأسئلة الشائعة
        $faq = [];
        foreach ($t['faq'] as $item) {
            $faq[] = ['q' => self::fill($item[0], $v), 'a' => self::fill($item[1], $v)];
        }
        $html .= self::heading($lang . '_h_faq', $t['h_faq'], $v) . '<div class="gnap-faq">';
        foreach ($faq as $item) {
            $html .= '<h3>' . self::e($item['q']) . '</h3><p>' . self::e($item['a']) . '</p>';
        }
        $html .= '</div>';

        $html .= '<p class="gnap-note">' . self::e(self::fill($t['updated'], $v));
        $note = trim($settings[$lang . '_footer_note']);
        if ($note) {
            $html .= ' ' . self::e(self::fill($note, $v));
        }
        $html .= '</p>';

        return [
            'title'         => $title,
            'description'   => $description,
            'content'       => '<div class="gnap-ltr gnap-lang-' . esc_attr($lang) . '" dir="ltr" lang="' . esc_attr($lang) . '">' . $html . '</div>',
            'faq'           => $faq,
            'tags'          => self::tags($settings[$lang . '_tags'], $v),
            'focus_keyword' => $t['focus'],
            'change_pct'    => $change ? $change['pct'] : null,
        ];
    }

    /* =====================================================================
     * أدوات مشتركة
     * ===================================================================== */

    public static function fill($template, $vars) {
        return trim(preg_replace('/\s+/u', ' ', strtr($template, $vars)));
    }

    /**
     * اختيار قالب من مجموعة دون تكرار (أو نفس القالب السابق عند تحديث مقال موجود)
     */
    private static function choose($pool, array $items) {
        if (!$items) {
            return '';
        }
        if (isset(self::$fixed[$pool]) && (int) self::$fixed[$pool] >= 0 && (int) self::$fixed[$pool] < count($items)) {
            $index = (int) self::$fixed[$pool];
        } else {
            $index = GNAP_Rotator::pick($pool, $items, self::$commit);
        }
        self::$used[$pool] = $index;
        return $items[$index];
    }

    private static function heading($pool, array $variants, $v) {
        return '<h2>' . self::e(self::fill(self::choose($pool, $variants), $v)) . '</h2>';
    }

    private static function e($text) {
        return esc_html($text);
    }

    private static function tags($setting, $vars) {
        $tags = [];
        foreach (explode(',', (string) $setting) as $tag) {
            $tag = trim(self::fill($tag, $vars));
            if ($tag !== '') {
                $tags[] = $tag;
            }
        }
        return $tags;
    }

    private static function updated_time($snapshot) {
        $updated = new DateTime('@' . (int) $snapshot['updated_at']);
        $updated->setTimezone(GNAP_Countries::timezone($snapshot['country']['code']));
        return $updated->format('H:i');
    }

    private static function karat_label($carat, $lang) {
        $t = GNAP_Languages::get($lang)['s'];
        return $carat === '24k_oz' ? $t['ounce'] : sprintf($t['karat'], (int) $carat);
    }

    /**
     * الدول المعروضة في جدول الدول العربية: الدول المفعلة في الإعدادات، أو كل الدول
     */
    private static function table_codes($settings) {
        $codes = array_values(array_intersect($settings['countries'], GNAP_Countries::country_codes()));
        return $codes ?: GNAP_Countries::country_codes();
    }

    private static function today_post_url($code) {
        $id = GNAP_Publisher::find_post($code . '_' . GNAP_Countries::local_date($code)['ymd']);
        return ($id && get_post_status($id) === 'publish') ? get_permalink($id) : '';
    }

    /**
     * التغير في سعر العيار مقارنة بآخر مقال سابق، أو بالتغير العالمي للأونصة كبديل
     */
    private static function change($snapshot, $previous, $carat) {
        if ($previous && !empty($previous['local'][$carat])) {
            $old = (float) $previous['local'][$carat];
            $diff = $snapshot['local'][$carat] - $old;
            return ['source' => 'local', 'diff' => $diff, 'pct' => $old > 0 ? $diff / $old * 100 : 0, 'old' => $old];
        }
        if (function_exists('infi_get_gold_price_change')) {
            $global = GNAP_Prices::cached('gnap_global_change', function () {
                return infi_get_gold_price_change('24k_oz', 'daily');
            });
            if (!empty($global) && $global['change_percentage'] !== null) {
                return ['source' => 'global', 'diff' => (float) $global['change_value'], 'pct' => (float) $global['change_percentage'], 'old' => (float) $global['previous_price']];
            }
        }
        return null;
    }

    /**
     * أعلى/أدنى سعر للأونصة خلال 30 يوماً وموقع السعر الحالي منهما
     */
    private static function range_text($s, $lang) {
        $x = $s['extremes'];
        if (empty($x['highest_price']) || empty($x['lowest_price'])) {
            return '';
        }
        $high = (float) $x['highest_price'];
        $low = (float) $x['lowest_price'];
        $now = (float) $s['usd']['24k_oz'];
        $pos = $high > $low ? ($now - $low) / ($high - $low) : null;

        if ($lang !== 'ar') {
            $t = GNAP_Languages::get($lang)['s'];
            $text = ' ' . sprintf($t['range'], GNAP_Languages::money($high, 2, $lang), GNAP_Languages::money($low, 2, $lang));
            if ($pos !== null) {
                $text .= ' ' . ($pos >= 0.85 ? $t['range_top'] : ($pos <= 0.15 ? $t['range_bottom'] : $t['range_mid']));
            }
            return $text;
        }

        $text = sprintf(' وخلال آخر 30 يوماً، بلغ أعلى سعر للأونصة %s دولار، بينما بلغ أدنى سعر %s دولار.', GNAP_Prices::format($high, 2), GNAP_Prices::format($low, 2));
        if ($pos !== null) {
            $text .= $pos >= 0.85 ? ' ويتداول السعر الحالي بالقرب من أعلى مستوياته خلال هذه الفترة.'
                : ($pos <= 0.15 ? ' ويتداول السعر الحالي بالقرب من أدنى مستوياته خلال هذه الفترة.' : ' ويقع السعر الحالي في منطقة وسطى بين أعلى وأدنى مستوى خلال هذه الفترة.');
        }
        return $text;
    }

    private static function comparison_table($s, $previous, array $carats, $decimals, $lang) {
        $ar = $lang === 'ar';
        $t = $ar ? null : GNAP_Languages::get($lang)['s'];
        $fmt = function ($value) use ($ar, $decimals, $lang) {
            return $ar ? GNAP_Prices::format($value, $decimals) : GNAP_Languages::num($value, $decimals, $lang);
        };
        $html = '<figure class="wp-block-table gnap-table"><table><thead><tr>'
            . ($ar ? '<th>العيار</th><th>السعر السابق</th><th>سعر اليوم</th><th>التغير</th>'
                : '<th>' . self::e($t['th_karat']) . '</th><th>' . self::e($t['th_prev']) . '</th><th>' . self::e($t['th_today']) . '</th><th>' . self::e($t['th_change']) . '</th>')
            . '</tr></thead><tbody>';

        foreach ($carats as $carat) {
            if (empty($previous['local'][$carat])) {
                continue;
            }
            $old = (float) $previous['local'][$carat];
            $new = $s['local'][$carat];
            $diff = $new - $old;
            $pct = $old > 0 ? $diff / $old * 100 : 0;
            $class = $pct >= 0.05 ? 'gnap-up' : ($pct <= -0.05 ? 'gnap-down' : 'gnap-flat');
            $sign = $diff > 0 ? '+' : ($diff < 0 ? '-' : '');

            $html .= '<tr><td>' . self::e($ar ? GNAP_Prices::carat_label($carat) : self::karat_label($carat, $lang)) . '</td>'
                . '<td>' . self::e($fmt($old)) . '</td>'
                . '<td><strong>' . self::e($fmt($new)) . '</strong></td>'
                . '<td class="' . $class . '"><span dir="ltr">' . self::e($sign . $fmt(abs($diff)) . ' (' . $sign . ($ar ? number_format(abs($pct), 2) : GNAP_Languages::num(abs($pct), 2, $lang)) . '%)') . '</span></td></tr>';
        }
        return $html . '</tbody></table></figure>';
    }
}
