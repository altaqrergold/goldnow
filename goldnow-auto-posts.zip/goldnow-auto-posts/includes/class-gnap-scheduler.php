<?php
/**
 * الجدولة بوضعين:
 * - interval: مقال واحد لدولة عشوائية كل فترة (مثلاً كل 30 دقيقة) حتى تُغطى كل الدول يومياً
 * - fixed: نشر مقالات كل الدول بعد وصول وقت النشر المحدد (على دفعات صغيرة)
 *
 * لتوفير موارد الخادم لا يوجد فحص دوري: يُجدول حدث واحد فقط في موعد العمل التالي بالضبط،
 * وبعد اكتمال دول اليوم يُجدول الحدث لموعد الغد، فلا يعمل WP-Cron إلا عند وجود مقال لنشره.
 */

if (!defined('ABSPATH')) {
    exit;
}

class GNAP_Scheduler {

    const HOOK         = 'gnap_tick';
    const LOCK         = 'gnap_tick_lock';
    const NEXT_OPTION  = 'gnap_next_at'; // موعد المقال التالي في وضع الفاصل الزمني
    const LAST_OPTION  = 'gnap_last_tick'; // آخر تشغيل ونتيجته (للتشخيص في لوحة التحكم)
    const BATCH        = 2;   // أقصى عدد دول في كل تشغيل (الوضع الثابت)
    const FIXED_GAP    = 2 * MINUTE_IN_SECONDS;  // استراحة بين دفعات الوضع الثابت
    const BUSY_DELAY   = 10 * MINUTE_IN_SECONDS; // تأجيل النشر عندما يكون الخادم مشغولاً
    const MAX_SECONDS  = 40;  // أقصى مدة للتشغيل الواحد
    const MAX_ATTEMPTS = 12;  // أقصى عدد محاولات فاشلة يومياً لكل دولة
    const RETRY_DELAY  = 10 * MINUTE_IN_SECONDS; // انتظار قبل إعادة محاولة دولة فشلت

    public static function init() {
        add_action(self::HOOK, [__CLASS__, 'tick']);
        add_action('update_option_' . GNAP_Settings::OPTION, [__CLASS__, 'reschedule']);
        add_action('add_option_' . GNAP_Settings::OPTION, [__CLASS__, 'reschedule']);
        // إعادة الجدولة إذا حُذف الحدث لأي سبب (فقط في لوحة التحكم وطلبات الـ cron)
        add_action('init', [__CLASS__, 'ensure_scheduled']);
    }

    public static function activate() {
        if (!get_option(GNAP_Settings::OPTION)) {
            add_option(GNAP_Settings::OPTION, GNAP_Settings::defaults());
        }
        self::reschedule();
    }

    public static function deactivate() {
        wp_clear_scheduled_hook(self::HOOK);
        delete_transient(self::LOCK);
    }

    public static function ensure_scheduled() {
        if (!is_admin() && !wp_doing_cron()) {
            return;
        }
        $settings = GNAP_Settings::get();
        if ($settings['enabled'] && $settings['countries'] && !wp_next_scheduled(self::HOOK)) {
            self::reschedule();
        }
    }

    /**
     * جدولة حدث واحد في موعد العمل التالي (أو إلغاؤه إذا كان النشر معطلاً)
     */
    public static function reschedule() {
        wp_clear_scheduled_hook(self::HOOK);
        $settings = GNAP_Settings::get();
        if (!$settings['enabled'] || empty($settings['countries'])) {
            return;
        }
        wp_schedule_single_event(self::next_wake($settings), self::HOOK);
    }

    public static function tick() {
        $settings = GNAP_Settings::get();
        if (!$settings['enabled'] || empty($settings['countries'])) {
            self::record('النشر التلقائي معطل.');
            return;
        }
        if (self::server_busy()) {
            wp_schedule_single_event(time() + self::BUSY_DELAY, self::HOOK);
            self::record('الخادم مشغول، تم التأجيل 10 دقائق.');
            return;
        }
        if (get_transient(self::LOCK)) {
            // تشغيل آخر قيد التنفيذ: نعيد المحاولة لاحقاً دون فقدان الجدولة
            wp_schedule_single_event(time() + 5 * MINUTE_IN_SECONDS, self::HOOK);
            self::record('تشغيل سابق ما زال قيد التنفيذ، إعادة المحاولة بعد 5 دقائق.');
            return;
        }
        set_transient(self::LOCK, 1, 5 * MINUTE_IN_SECONDS);
        self::record('بدأ التشغيل...');

        try {
            $message = $settings['schedule_mode'] === 'interval'
                ? self::run_interval($settings)
                : self::run_fixed($settings);
            self::record($message);
        } finally {
            delete_transient(self::LOCK);
            self::reschedule();
        }
    }

    private static function record($message) {
        update_option(self::LAST_OPTION, ['time' => time(), 'message' => $message], false);
    }

    public static function last_run() {
        $last = get_option(self::LAST_OPTION);
        return is_array($last) ? $last : null;
    }

    /**
     * الوضع الثابت: نشر الدول المستحقة على دفعات
     */
    private static function run_fixed($settings) {
        $started = time();
        $messages = [];
        foreach ($settings['countries'] as $code) {
            if (count($messages) >= self::BATCH || (time() - $started) > self::MAX_SECONDS) {
                break;
            }
            if (!self::is_due($code, $settings)) {
                continue;
            }
            $messages[] = GNAP_Publisher::publish($code, 'cron')['message'];
        }
        return $messages ? implode(' | ', $messages) : 'لا توجد دول مستحقة للنشر الآن.';
    }

    /**
     * وضع الفاصل الزمني: مقال واحد لدولة عشوائية
     */
    private static function run_interval($settings) {
        $next_at = (int) get_option(self::NEXT_OPTION, 0);
        if (time() < $next_at) {
            return 'لم يحن موعد المقال التالي (' . wp_date('H:i', $next_at) . ').';
        }

        $due = array_values(array_filter($settings['countries'], function ($code) use ($settings) {
            return self::is_due($code, $settings);
        }));
        shuffle($due);

        if (!$due) {
            return 'لا توجد دول مستحقة للنشر الآن.';
        }

        // إذا كان مقال الدولة موجوداً أو فشل النشر نجرب دولة أخرى دون انتظار الفاصل
        $messages = [];
        foreach (array_slice($due, 0, 3) as $code) {
            $result = GNAP_Publisher::publish($code, 'cron');
            $messages[] = $result['message'];
            if (in_array($result['result'], ['created', 'updated'], true)) {
                update_option(self::NEXT_OPTION, time() + self::gap_seconds($settings), true);
                break;
            }
        }
        return implode(' | ', $messages);
    }

    /**
     * حماية اختيارية: تأجيل النشر إذا تجاوز متوسط حمل الخادم حداً معيناً.
     * معطلة افتراضياً، لأن الحمل في الاستضافات المشتركة (cPanel/CloudLinux) يخص الخادم الفعلي كله
     * لا حساب الموقع، فيبدو مرتفعاً دائماً ويؤجل النشر للأبد. للتفعيل:
     * add_filter('gnap_max_load', function () { return 8; });
     */
    public static function server_busy() {
        $limit = (float) apply_filters('gnap_max_load', 0);
        if ($limit <= 0 || !function_exists('sys_getloadavg')) {
            return false;
        }
        $load = @sys_getloadavg();
        if (empty($load) || $load[0] <= $limit) {
            return false;
        }
        if (!get_transient('gnap_busy_logged')) {
            set_transient('gnap_busy_logged', 1, HOUR_IN_SECONDS);
            GNAP_Log::add(sprintf('الخادم مشغول (الحمل %.2f، الحد %.2f)، تم تأجيل النشر 10 دقائق.', $load[0], $limit), 'error');
        }
        return true;
    }

    private static function gap_seconds($settings) {
        $minutes = (int) $settings['interval'];
        if ($settings['random_gap']) {
            $minutes = wp_rand((int) round($minutes * 0.7), (int) round($minutes * 1.3));
        }
        return max(5, $minutes) * MINUTE_IN_SECONDS;
    }

    /**
     * هل حان وقت نشر مقال اليوم لهذه الدولة ولم يُنشر بعد؟
     */
    public static function is_due($code, $settings = null) {
        $settings = $settings ?: GNAP_Settings::get();
        if (self::done_today($code)) {
            return false;
        }
        $now = new DateTime('now', self::tz($code, $settings));
        return $now->format('H:i') >= $settings['publish_time'];
    }

    /**
     * نُشر مقال اليوم، أو استُنفدت محاولات اليوم
     */
    private static function done_today($code) {
        $status = GNAP_Log::status($code);
        if (!$status || $status['date'] !== GNAP_Countries::local_date($code)['ymd']) {
            return false;
        }
        return $status['result'] !== 'error' || (int) $status['attempts'] >= self::MAX_ATTEMPTS;
    }

    private static function tz($code, $settings) {
        return $settings['time_mode'] === 'site' ? wp_timezone() : GNAP_Countries::timezone($code);
    }

    /**
     * أقرب موعد يوجد فيه عمل فعلي
     */
    public static function next_wake($settings) {
        $now = time();
        $next = PHP_INT_MAX;

        foreach ($settings['countries'] as $code) {
            $tz = self::tz($code, $settings);
            $today = new DateTime('now', $tz);
            $start = new DateTime($today->format('Y-m-d') . ' ' . $settings['publish_time'], $tz);

            if (self::done_today($code)) {
                // موعد الغد
                $start->modify('+1 day');
                $candidate = $start->getTimestamp();
            } elseif ($start->getTimestamp() > $now) {
                // لم يحن وقت اليوم بعد
                $candidate = $start->getTimestamp();
            } else {
                // مستحقة الآن، مع تأخير إعادة المحاولة إذا فشلت مؤخراً
                $status = GNAP_Log::status($code);
                $candidate = ($status && $status['result'] === 'error') ? (int) $status['time'] + self::RETRY_DELAY : $now;
                if ($settings['schedule_mode'] === 'interval') {
                    $candidate = max($candidate, (int) get_option(self::NEXT_OPTION, 0));
                } else {
                    $candidate = max($candidate, $now + self::FIXED_GAP);
                }
            }
            $next = min($next, $candidate);
        }

        // حد أدنى دقيقة واحدة بين التشغيلات
        return max($now + MINUTE_IN_SECONDS, $next === PHP_INT_MAX ? $now + DAY_IN_SECONDS : $next);
    }

    /**
     * موعد النشر القادم لدولة (للعرض في لوحة التحكم)
     */
    public static function next_run_label($code, $settings) {
        if (self::is_due($code, $settings)) {
            return $settings['schedule_mode'] === 'interval' ? 'في الدور (ترتيب عشوائي)' : 'في التشغيل القادم';
        }
        $tz = self::tz($code, $settings);
        $now = new DateTime('now', $tz);
        $target = new DateTime($now->format('Y-m-d') . ' ' . $settings['publish_time'], $tz);
        if ($target <= $now) {
            $target->modify('+1 day');
        }
        $label = $target->format('Y-m-d H:i') . ' (' . $tz->getName() . ')';
        return $settings['schedule_mode'] === 'interval' ? 'يبدأ دوره بعد ' . $label : $label;
    }
}
