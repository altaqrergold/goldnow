<?php
/**
 * إعدادات الإضافة
 */

if (!defined('ABSPATH')) {
    exit;
}

class GNAP_Settings {

    const OPTION = 'gnap_settings';

    public static function defaults() {
        $defaults = [
            'enabled'         => 0,
            'countries'       => array_keys(GNAP_Countries::all()),
            'schedule_mode'   => 'interval', // interval = مقال كل فترة بترتيب عشوائي، fixed = كل الدول في وقت واحد
            'interval'        => 30,         // الفاصل بين المقالات بالدقائق (وضع interval)
            'random_gap'      => 1,          // تنويع الفاصل عشوائياً (±30%) ليبدو النشر طبيعياً
            'publish_time'    => '08:00',    // وقت النشر (fixed) أو وقت بدء النشر اليومي (interval)
            'time_mode'       => 'local',    // local = حسب توقيت كل دولة، site = حسب توقيت الموقع
            'post_status'     => 'publish',
            'category'        => 0,
            'sub_categories'  => 1,         // تصنيف فرعي لكل دولة تحت التصنيف الرئيسي
            'author'          => 0,
            'on_exists'       => 'update',  // عند النشر اليدوي لمقال موجود لنفس اليوم: update أو skip
            'image'           => 1,
            'image_format'    => 'portrait', // portrait = 1080x1350 للموبايل، landscape = 1200x630 للمشاركة
            'logo_url'        => '',        // فارغ = شعار الموقع من إعدادات القالب
            'slug_prefix'     => 'gold-price',
            'tags'            => 'أسعار الذهب اليوم, {term} الذهب في {country}, الذهب عيار 21',
            'title_templates' => implode("\n", [
                '{term} الذهب اليوم في {country} {weekday} {date}',
                'أسعار الذهب في {country} اليوم {weekday} {date} بجميع العيارات',
                '{term} الذهب في {country} اليوم {date}.. عيار 21 يسجل {p21} {unit}',
                'كم {term} جرام الذهب في {country} اليوم {weekday} {date}؟',
                'عيار 21 بكم؟ {term} الذهب في {country} اليوم {date}',
            ]),
            'desc_templates'  => implode("\n", [
                'تعرف على {term} الذهب اليوم في {country} {weekday} {date}، حيث سجل جرام عيار 21 نحو {p21} {unit} وعيار 24 نحو {p24} {unit}، مع سعر الأونصة وأسعار البيع والشراء.',
                '{term} جرام الذهب عيار 21 في {country} اليوم {date} يسجل {p21} {unit}. تابع أسعار جميع العيارات والأونصة وأسعار البيع والشراء بالتفصيل.',
                'أسعار الذهب في {country} اليوم {weekday} {date}: عيار 24 بـ {p24} {unit} وعيار 21 بـ {p21} {unit} وعيار 18 بـ {p18} {unit}.',
            ]),
            'footer_note'     => 'الأسعار الواردة استرشادية ومحسوبة على أساس السعر العالمي لأونصة الذهب وسعر الصرف الرسمي للعملة، ولا تشمل المصنعية أو الضرائب، وقد تختلف قليلاً من محل صاغة لآخر.',

            // مقال سعر الذهب عالمياً بالدولار (عربي)
            'global_title_templates' => implode("\n", [
                'سعر الذهب عالمياً اليوم {weekday} {date}.. الأونصة عند {oz_usd} دولار',
                'أسعار الذهب العالمية اليوم {date} بالدولار لجميع العيارات',
                'كم سعر أونصة الذهب اليوم {weekday} {date} في البورصة العالمية؟',
                'الذهب عالمياً اليوم {date}: الأونصة تسجل {oz_usd} دولار',
                'سعر جرام الذهب بالدولار اليوم {weekday} {date}',
                'سعر الذهب في البورصة العالمية اليوم {weekday} {date}',
                'سعر أونصة الذهب اليوم {date} وجرام عيار 24 بـ {p24} دولار',
                'الذهب بالدولار اليوم {weekday} {date}.. أسعار الأونصة والجرام',
                'كم سعر جرام الذهب عيار 21 بالدولار اليوم {date}؟',
                'أسعار الذهب عالمياً {weekday} {date} وعيار 21 يسجل {p21} دولار',
                'تحديث سعر الذهب العالمي اليوم {date} بالدولار الأمريكي',
                'سعر الذهب اليوم {weekday} {date} عالمياً بالأونصة والجرام',
            ]),
            'global_desc_templates' => implode("\n", [
                'سعر الذهب عالمياً اليوم {weekday} {date}: الأونصة عند {oz_usd} دولار، وجرام عيار 24 بـ {p24} دولار، مع أسعار عيار 21 في الدول العربية.',
                'تعرف على سعر أونصة الذهب وسعر الجرام بالدولار اليوم {date} لجميع العيارات، ومقارنة بسعر أمس وأسعار الذهب في الدول العربية.',
                'أسعار الذهب في البورصة العالمية اليوم {weekday} {date}: الأونصة {oz_usd} دولار، وعيار 21 بـ {p21} دولار للجرام.',
            ]),
            'global_intro_templates' => implode("\n", [
                'سجل سعر أونصة الذهب في البورصة العالمية اليوم {weekday} {date} نحو {oz_usd} دولار أمريكي، فيما بلغ سعر جرام الذهب عيار 24 نحو {p24} دولار، وعيار 21 نحو {p21} دولار.',
                'نستعرض في هذا التقرير سعر الذهب عالمياً اليوم {weekday} {date} بالدولار الأمريكي، حيث بلغ سعر الأونصة {oz_usd} دولار، وسجل الجرام عيار 24 نحو {p24} دولار، وعيار 18 نحو {p18} دولار.',
                'يتابع المستثمرون والمهتمون بالمعدن الأصفر سعر الذهب في الأسواق العالمية يومياً، واليوم {weekday} {date} بلغ سعر أونصة الذهب {oz_usd} دولار، وسعر جرام عيار 21 نحو {p21} دولار.',
                'في تحديث جديد لأسعار الذهب العالمية اليوم {weekday} {date}، سجلت الأونصة نحو {oz_usd} دولار، بينما بلغ سعر جرام الذهب عيار 24 نحو {p24} دولار، وعيار 22 نحو {p22} دولار.',
                'كم سعر الذهب عالمياً اليوم؟ سجلت أونصة الذهب اليوم {weekday} {date} نحو {oz_usd} دولار أمريكي، وبلغ سعر الجرام عيار 24 نحو {p24} دولار، وعيار 21 نحو {p21} دولار، وعيار 18 نحو {p18} دولار.',
            ]),
            'global_tags'     => 'سعر الذهب عالمياً, سعر أونصة الذهب, سعر الذهب بالدولار, أسعار الذهب اليوم',
            'global_footer_note' => 'الأسعار الواردة استرشادية ومحسوبة على أساس السعر العالمي الفوري لأونصة الذهب بالدولار الأمريكي، ولا تشمل المصنعية أو الضرائب أو هامش ربح التجار.',
            'global_category' => 0,          // 0 = تصنيف "سعر الذهب عالمياً" يُنشأ تلقائياً
            'global_slug'     => 'gold-price-world',

        ];

        // مقالات اللغات الأجنبية: لكل لغة إعداداتها المنفصلة (البادئة = رمز اللغة: en_، fr_ ...)
        foreach (GNAP_Languages::all() as $lang => $p) {
            foreach (['title_templates', 'desc_templates', 'intro_templates'] as $key) {
                $defaults[$lang . '_' . $key] = implode("
", $p['defaults'][$key]);
            }
            $defaults[$lang . '_tags'] = $p['defaults']['tags'];
            $defaults[$lang . '_footer_note'] = $p['defaults']['footer_note'];
            $defaults[$lang . '_category'] = 0; // 0 = تصنيف خاص باللغة يُنشأ تلقائياً
            $defaults[$lang . '_slug'] = $p['slug'];
        }
        return $defaults;
    }

    /**
     * بادئات إعدادات المقالات العامة: global (العالمي العربي) + رموز اللغات
     */
    public static function article_prefixes() {
        return array_merge(['global'], array_keys(GNAP_Languages::all()));
    }

    public static function get($key = null) {
        $settings = wp_parse_args(get_option(self::OPTION, []), self::defaults());
        if ($key === null) {
            return $settings;
        }
        return isset($settings[$key]) ? $settings[$key] : null;
    }

    public static function sanitize($input) {
        $defaults = self::defaults();
        $out = [];

        $out['enabled'] = empty($input['enabled']) ? 0 : 1;

        $valid_codes = array_keys(GNAP_Countries::all());
        $countries = isset($input['countries']) && is_array($input['countries']) ? $input['countries'] : [];
        $out['countries'] = array_values(array_intersect($valid_codes, array_map('sanitize_key', $countries)));

        $time = isset($input['publish_time']) ? trim($input['publish_time']) : '';
        $out['publish_time'] = preg_match('/^([01]\d|2[0-3]):[0-5]\d$/', $time) ? $time : $defaults['publish_time'];

        $out['schedule_mode'] = (isset($input['schedule_mode']) && $input['schedule_mode'] === 'fixed') ? 'fixed' : 'interval';
        $out['interval'] = isset($input['interval']) ? min(1440, max(5, absint($input['interval']))) : $defaults['interval'];
        $out['random_gap'] = empty($input['random_gap']) ? 0 : 1;

        $out['time_mode'] = (isset($input['time_mode']) && $input['time_mode'] === 'site') ? 'site' : 'local';
        $out['post_status'] = (isset($input['post_status']) && in_array($input['post_status'], ['publish', 'draft', 'pending'], true)) ? $input['post_status'] : 'publish';
        $out['category'] = isset($input['category']) ? absint($input['category']) : 0;
        $out['sub_categories'] = empty($input['sub_categories']) ? 0 : 1;
        $out['author'] = isset($input['author']) ? absint($input['author']) : 0;
        $out['on_exists'] = (isset($input['on_exists']) && $input['on_exists'] === 'skip') ? 'skip' : 'update';
        $out['image'] = empty($input['image']) ? 0 : 1;
        $out['image_format'] = (isset($input['image_format']) && $input['image_format'] === 'landscape') ? 'landscape' : 'portrait';
        $out['logo_url'] = isset($input['logo_url']) ? esc_url_raw(trim($input['logo_url'])) : '';

        $slug = isset($input['slug_prefix']) ? sanitize_title($input['slug_prefix']) : '';
        $out['slug_prefix'] = $slug !== '' ? $slug : $defaults['slug_prefix'];

        $prefixes = self::article_prefixes();
        $with = function ($keys) use ($prefixes) {
            foreach ($prefixes as $prefix) {
                $keys[] = $prefix . '_' . $keys[0];
            }
            return $keys;
        };

        foreach ($with(['tags']) as $key) {
            $out[$key] = isset($input[$key]) ? sanitize_text_field($input[$key]) : '';
        }

        foreach (array_merge($with(['title_templates']), $with(['desc_templates']), array_slice($with(['intro_templates']), 1)) as $key) {
            $lines = isset($input[$key]) ? self::lines($input[$key]) : [];
            $out[$key] = $lines ? implode("\n", $lines) : $defaults[$key];
        }

        foreach ($with(['footer_note']) as $key) {
            $out[$key] = isset($input[$key]) ? sanitize_textarea_field($input[$key]) : '';
        }

        foreach ($prefixes as $prefix) {
            $out[$prefix . '_category'] = isset($input[$prefix . '_category']) ? absint($input[$prefix . '_category']) : 0;
            $slug = isset($input[$prefix . '_slug']) ? sanitize_title($input[$prefix . '_slug']) : '';
            $out[$prefix . '_slug'] = $slug !== '' ? $slug : $defaults[$prefix . '_slug'];
        }

        return $out;
    }

    /**
     * تحويل نص متعدد الأسطر إلى مصفوفة أسطر غير فارغة
     */
    public static function lines($text) {
        $lines = array_map('trim', preg_split('/\r\n|\r|\n/', (string) $text));
        return array_values(array_filter(array_map('sanitize_text_field', $lines), 'strlen'));
    }
}
