<?php
/**
 * سجل عمليات النشر وحالة كل دولة
 */

if (!defined('ABSPATH')) {
    exit;
}

class GNAP_Log {

    const LOG_OPTION    = 'gnap_log';
    const STATUS_OPTION = 'gnap_status';
    const MAX_ENTRIES   = 150;

    public static function add($message, $level = 'info', $code = '') {
        $log = get_option(self::LOG_OPTION, []);
        if (!is_array($log)) {
            $log = [];
        }
        array_unshift($log, [
            'time'    => time(),
            'level'   => $level,
            'code'    => $code,
            'message' => $message,
        ]);
        update_option(self::LOG_OPTION, array_slice($log, 0, self::MAX_ENTRIES), false);
    }

    public static function entries() {
        $log = get_option(self::LOG_OPTION, []);
        return is_array($log) ? $log : [];
    }

    public static function clear() {
        delete_option(self::LOG_OPTION);
    }

    /**
     * حالة آخر محاولة لكل دولة: [code => [date, result, message, post_id, attempts, time]]
     */
    public static function status($code = null) {
        $status = get_option(self::STATUS_OPTION, []);
        if (!is_array($status)) {
            $status = [];
        }
        if ($code === null) {
            return $status;
        }
        return isset($status[$code]) ? $status[$code] : null;
    }

    public static function set_status($code, $date, $result, $message = '', $post_id = 0) {
        $status = self::status();
        $previous = isset($status[$code]) ? $status[$code] : [];
        $attempts = (isset($previous['date']) && $previous['date'] === $date && $result === 'error')
            ? (int) $previous['attempts'] + 1
            : ($result === 'error' ? 1 : 0);

        $status[$code] = [
            'date'     => $date,
            'result'   => $result,
            'message'  => $message,
            'post_id'  => (int) $post_id,
            'attempts' => $attempts,
            'time'     => time(),
        ];
        update_option(self::STATUS_OPTION, $status, false);

        // تسجيل الخطأ مرة واحدة فقط إذا تكرر نفس السبب في نفس اليوم
        $repeated = isset($previous['date'], $previous['message'])
            && $previous['date'] === $date
            && $previous['message'] === $message;
        if ($result !== 'error' || !$repeated) {
            self::add($message, $result === 'error' ? 'error' : 'info', $code);
        }
    }
}
