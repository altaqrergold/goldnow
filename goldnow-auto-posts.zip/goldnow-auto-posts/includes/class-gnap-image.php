<?php
/**
 * توليد الصورة البارزة للمقال بمكتبة GD: بالطول 1080x1350 (للموبايل) أو بالعرض 1200x630
 */

if (!defined('ABSPATH')) {
    exit;
}

class GNAP_Image {

    const SIZES = [
        'portrait'  => [1080, 1350],
        'landscape' => [1200, 630],
    ];

    private $w;
    private $h;
    private $img;
    private $bold;
    private $regular;
    private $c = [];
    private $rtl = true; // false للغات الأجنبية: يُعكس التصميم كله أفقياً ويُرسم النص كما هو
    private $lang = 'ar';

    public static function supported() {
        return function_exists('imagecreatetruecolor') && function_exists('imagettftext') && function_exists('imagejpeg');
    }

    /**
     * @param array  $snapshot  ناتج GNAP_Prices::snapshot
     * @param array  $date      ناتج GNAP_Countries::local_date
     * @param float|null $change_pct نسبة تغير عيار 21
     * @param string $site      اسم/نطاق الموقع
     * @param string $path      مسار حفظ ملف JPEG
     * @param string|null $format portrait أو landscape (الافتراضي من الإعدادات)
     * @return true|WP_Error
     */
    public static function generate($snapshot, $date, $change_pct, $site, $path, $format = null) {
        if (!self::supported()) {
            return new WP_Error('gnap_gd', 'مكتبة GD مع دعم FreeType غير متوفرة على الخادم.');
        }
        $format = $format ?: GNAP_Settings::get('image_format');
        $self = new self();
        return $self->render($snapshot, $date, $change_pct, $site, $path, isset(self::SIZES[$format]) ? $format : 'portrait');
    }

    private function render($s, $date, $change_pct, $site, $path, $format) {
        list($this->w, $this->h) = self::SIZES[$format];
        $lang = self::image_lang($s['country']['lang']);
        $this->lang = $lang;
        $this->rtl = $lang === 'ar';
        // خط Cairo للعربية واللاتينية، وخط بديل للغات التي لا يدعمها (مثل الروسية)
        $pack = $lang === 'ar' ? null : GNAP_Languages::get($lang);
        $font = $pack && !empty($pack['font']) ? $pack['font'] : 'Cairo';
        $this->bold = GNAP_PATH . 'assets/fonts/' . $font . '-Bold.ttf';
        $this->regular = GNAP_PATH . 'assets/fonts/' . $font . '-Regular.ttf';

        $this->img = imagecreatetruecolor($this->w, $this->h);
        imagealphablending($this->img, true);
        imageantialias($this->img, true);

        $this->c = [
            'gold'      => $this->color('#f2c14e'),
            'gold_dim'  => $this->color('#b8913a'),
            'white'     => $this->color('#ffffff'),
            'text'      => $this->color('#e6dfd0'),
            'muted'     => $this->color('#a89f8c'),
            'card'      => $this->color('#211b12'),
            'card_line' => $this->color('#6b5528'),
            'pill'      => $this->color('#19150f'),
            'up'        => $this->color('#2fbf71'),
            'down'      => $this->color('#e5534b'),
            'flat'      => $this->color('#8a8f98'),
        ];

        $this->background();
        $data = $this->data($s, $date);
        if ($format === 'portrait') {
            $this->layout_portrait($s, $data, $change_pct, $site);
        } else {
            $this->layout_landscape($s, $data, $change_pct, $site);
        }

        $dir = dirname($path);
        if (!is_dir($dir)) {
            wp_mkdir_p($dir);
        }
        $ok = imagejpeg($this->img, $path, 82);
        imagedestroy($this->img);

        return $ok ? true : new WP_Error('gnap_image_write', 'تعذر حفظ الصورة في: ' . $path);
    }

    /**
     * نصوص وأرقام الصورة حسب نوع المقال:
     * main = البطاقة الرئيسية، side = يسار البطاقة (العرضي)، grid = 4 خانات (الطولي يعرضها كلها والعرضي أول 3)
     */
    /**
     * لغة نصوص الصورة: الهندية تُكتب بالإنجليزية لأن GD لا يدعم تشكيل حروف الديفاناغاري
     */
    private static function image_lang($lang) {
        if ($lang === 'ar') {
            return 'ar';
        }
        $pack = GNAP_Languages::get($lang);
        return $pack && !empty($pack['image_lang']) ? $pack['image_lang'] : $lang;
    }

    private function data($s, $date) {
        $c = $s['country'];
        $l = $s['local'];
        $u = $s['usd'];
        $updated = new DateTime('@' . (int) $s['updated_at']);
        $updated->setTimezone(GNAP_Countries::timezone($c['code']));
        $time = $updated->format('H:i');

        $lang = self::image_lang($c['lang']);
        if ($lang !== 'ar') {
            // المقالات الأجنبية: النصوص والأرقام والتاريخ بلغة الصورة
            $p = GNAP_Languages::get($lang);
            $img = $p['img'];
            $num = function ($value, $decimals = 2) use ($lang) {
                return GNAP_Languages::num($value, $decimals, $lang);
            };
            $money = function ($value, $decimals = 2) use ($lang) {
                return GNAP_Languages::money($value, $decimals, $lang);
            };
            $grid = [];
            foreach (['24k', '21k', '18k', '22k'] as $carat) {
                $grid[] = [sprintf($img['gram'], (int) $carat), $money($u[$carat])];
            }
            return [
                'title'      => $p['headline'],
                'date'       => GNAP_Languages::upper_first(strtr($p['full_date'], GNAP_Languages::date($lang, $date['ymd']))),
                'unit'       => 'USD',
                'updated'    => sprintf($img['updated'], $time),
                'main_label' => $img['main'],
                'main_price' => $num($u['24k_oz']),
                'side'       => [$img['kilo'], $money($u['24k'] * 1000, 0)],
                'grid'       => $grid,
            ];
        }

        $data = [
            'title'   => $c['headline'] ?: $c['term'] . ' الذهب في ' . $c['name'] . ' اليوم',
            'date'    => $date['weekday'] . ' ' . $date['date'],
            'unit'    => $c['unit'],
            'updated' => 'آخر تحديث ' . $time . ' بتوقيت ' . $c['capital'],
        ];

        if (!$c['global']) {
            return $data + [
                'main_label' => 'سعر جرام الذهب عيار 21',
                'main_price' => GNAP_Prices::format($l['21k']),
                'side'       => ['الأونصة عالمياً', '$' . GNAP_Prices::format($u['24k_oz'], 2)],
                'grid'       => [
                    ['عيار 24', GNAP_Prices::format($l['24k']) . ' ' . $c['unit']],
                    ['عيار 18', GNAP_Prices::format($l['18k']) . ' ' . $c['unit']],
                    ['الأونصة', GNAP_Prices::format($l['24k_oz']) . ' ' . $c['unit']],
                    ['الأونصة عالمياً', '$' . GNAP_Prices::format($u['24k_oz'], 2)],
                ],
            ];
        }

        // مقال سعر الذهب عالمياً (عربي): الأونصة هي السعر الرئيسي، والعيارات بالدولار
        $grid = [];
        foreach (['24k', '21k', '18k', '22k'] as $carat) {
            $grid[] = ['جرام عيار ' . (int) $carat, GNAP_Prices::format($u[$carat], 2) . ' ' . $c['unit']];
        }
        return $data + [
            'main_label' => 'سعر أونصة الذهب',
            'main_price' => GNAP_Prices::format($u['24k_oz'], 2),
            'side'       => ['كيلو الذهب عيار 24', '$' . GNAP_Prices::format($u['24k'] * 1000, 0)],
            'grid'       => $grid,
        ];
    }

    /**
     * التصميم الطولي 1080x1350: ترويسة في المنتصف، البطاقة الرئيسية، ثم شبكة 2×2
     */
    private function layout_portrait($s, $d, $change_pct, $site) {
        $country = $s['country'];
        $unit = $d['unit'];
        $x1 = 60; $x2 = $this->w - 60; $mid = (int) ($this->w / 2);

        // الترويسة فوق البطاقة الرئيسية (المساحة من 40 إلى 540)
        $logo = $this->load_logo();
        $title = $d['title'];
        $date_text = $d['date'];

        if ($logo) {
            // الشعار بأكبر حجم ممكن في الأعلى، والعلم بجانب العنوان في سطر واحد لتوفير المساحة له
            $this->logo($logo, $mid, 40 + 142, $x2 - $x1 - 200, 284, 'center');

            $flag_size = 104;
            $title_size = 54;
            $title_max = $x2 - $x1 - $flag_size - 24;
            while ($title_size > 30 && $this->measure($title, $this->bold, $title_size) > $title_max) {
                $title_size -= 2;
            }
            $group = $flag_size + 24 + $this->measure($title, $this->bold, $title_size);
            $group_right = $mid + (int) ($group / 2);
            $this->flag($country['code'], $group_right - $flag_size, 350, $flag_size);
            $this->text($title, $this->bold, $title_size, $group_right - $flag_size - 24, 350 + $flag_size / 2 + 20, $this->c['gold']);
            $this->text($date_text, $this->regular, 32, $mid, 506, $this->c['text'], 'center');
        } else {
            // بدون شعار: العلم كبير في المنتصف فوق العنوان
            $flag_size = 140;
            $y = 40 + (int) ((500 - $flag_size - 150) / 2);
            $this->flag($country['code'], $mid - $flag_size / 2, $y, $flag_size);
            $y += $flag_size + 20;
            $this->text($title, $this->bold, 58, $mid, $y + 62, $this->c['gold'], 'center', $x2 - $x1);
            $this->text($date_text, $this->regular, 32, $mid, $y + 118, $this->c['text'], 'center');
        }

        // البطاقة الرئيسية: عيار 21 (أو الأونصة في المقالات العامة)
        $cy1 = 548; $cy2 = 868;
        $this->rounded_box($x1, $cy1, $x2, $cy2, 26, $this->c['card'], $this->c['card_line']);
        $this->text($d['main_label'], $this->regular, 34, $mid, $cy1 + 66, $this->c['text'], 'center');

        // السعر والعملة كمجموعة واحدة في المنتصف (العملة يسار الرقم)
        $price = $d['main_price'];
        $unit_w = $this->measure($unit, $this->bold, 48);
        $price_size = 118;
        while ($price_size > 40 && $this->measure($price, $this->bold, $price_size) + 22 + $unit_w > ($x2 - $x1 - 80)) {
            $price_size -= 4;
        }
        $price_w = $this->measure($price, $this->bold, $price_size);
        $group_right = $mid + (int) (($price_w + 22 + $unit_w) / 2);
        $this->text($price, $this->bold, $price_size, $group_right, $cy1 + 200, $this->c['white']);
        $this->text($unit, $this->bold, 48, $group_right - $price_w - 22, $cy1 + 190, $this->c['gold']);

        if ($change_pct !== null) {
            $this->change_badge($mid - 95, $cy1 + 236, $change_pct);
        }

        // شبكة 2×2
        $items = $d['grid'];
        $gap = 24;
        $pw = (int) (($x2 - $x1 - $gap) / 2);
        $ph = 150;
        foreach ($items as $i => $item) {
            $col = $i % 2;               // 0 = يمين، 1 = يسار
            $row = (int) floor($i / 2);
            $bx2 = $x2 - $col * ($pw + $gap);
            $bx1 = $bx2 - $pw;
            $by1 = 896 + $row * ($ph + $gap);
            $by2 = $by1 + $ph;
            $this->rounded_box($bx1, $by1, $bx2, $by2, 20, $this->c['pill'], $this->c['card_line']);
            $bmid = (int) (($bx1 + $bx2) / 2);
            $this->text($item[0], $this->regular, 30, $bmid, $by1 + 52, $this->c['muted'], 'center');
            $this->text($item[1], $this->bold, 44, $bmid, $by2 - 32, $this->c['white'], 'center', $pw - 40);
        }

        // التذييل
        $this->text($d['updated'], $this->regular, 26, $mid, $this->h - 82, $this->c['muted'], 'center');
        $this->text($site, $this->bold, 30, $mid, $this->h - 40, $this->c['gold_dim'], 'center');
    }

    /**
     * التصميم العرضي 1200x630
     */
    private function layout_landscape($s, $d, $change_pct, $site) {
        $country = $s['country'];
        $unit = $d['unit'];

        // الترويسة: العلم + العنوان + التاريخ يميناً، وشعار الموقع يساراً
        $flag_size = 112;
        $right = $this->w - 64;
        $this->flag($country['code'], $right - $flag_size, 48, $flag_size);
        $text_right = $right - $flag_size - 26;
        $title = $d['title'];
        $title_max = 0;
        $logo = $this->load_logo();
        if ($logo) {
            // عرض الشعار = المساحة المتبقية بجانب العنوان، بحد أدنى 440 وأقصى 500 بكسل (يُصغَّر العنوان عند الحاجة)
            $free = $text_right - 64 - 36 - $this->measure($title, $this->bold, 46);
            $logo_w = $this->logo($logo, 64, 104, max(440, min(500, $free)), 150);
            $title_max = $text_right - (64 + $logo_w + 36);
        }
        $this->text($title, $this->bold, 46, $text_right, 104, $this->c['gold'], 'right', $title_max);
        $this->text($d['date'], $this->regular, 26, $text_right, 150, $this->c['text']);

        // البطاقة الرئيسية: عيار 21 (أو الأونصة في المقالات العامة)
        $cx1 = 64; $cx2 = $this->w - 64; $cy1 = 192; $cy2 = 398;
        $this->rounded_box($cx1, $cy1, $cx2, $cy2, 22, $this->c['card'], $this->c['card_line']);

        $inner_right = $cx2 - 40;
        $this->text($d['main_label'], $this->regular, 28, $inner_right, $cy1 + 58, $this->c['text']);
        $price = $d['main_price'];
        $unit_w = $this->measure($unit, $this->bold, 38);
        $price_w = $this->text($price, $this->bold, 84, $inner_right, $cy2 - 40, $this->c['white'], 'right', 720 - $unit_w - 18);
        $this->text($unit, $this->bold, 38, $inner_right - $price_w - 18, $cy2 - 48, $this->c['gold']);

        // يسار البطاقة: الأونصة عالمياً (أو كيلو الذهب) + التغير
        $left = $cx1 + 40;
        $this->text($d['side'][0], $this->regular, 24, $left, $cy1 + 52, $this->c['muted'], 'left');
        $this->text($d['side'][1], $this->bold, 40, $left, $cy1 + 108, $this->c['text'], 'left');
        if ($change_pct !== null) {
            $this->change_badge($left, $cy1 + 132, $change_pct);
        }

        // الصف السفلي: أول 3 خانات من الشبكة
        $items = array_slice($d['grid'], 0, 3);
        $gap = 20;
        $pw = (int) ((($cx2 - $cx1) - 2 * $gap) / 3);
        $py1 = 418; $py2 = 544;
        foreach ($items as $i => $item) {
            // من اليمين لليسار
            $x2 = $cx2 - $i * ($pw + $gap);
            $x1 = $x2 - $pw;
            $this->rounded_box($x1, $py1, $x2, $py2, 18, $this->c['pill'], $this->c['card_line']);
            $mid = (int) (($x1 + $x2) / 2);
            $this->text($item[0], $this->regular, 24, $mid, $py1 + 44, $this->c['muted'], 'center');
            $this->text($item[1], $this->bold, 34, $mid, $py2 - 26, $this->c['white'], 'center', $pw - 36);
        }

        // التذييل
        $this->text($site, $this->bold, 22, $cx1, $this->h - 38, $this->c['gold_dim'], 'left');
        $this->text($d['updated'], $this->regular, 20, $cx2, $this->h - 38, $this->c['muted']);
    }

    private function color($hex, $alpha = 0) {
        $hex = ltrim($hex, '#');
        return imagecolorallocatealpha($this->img, hexdec(substr($hex, 0, 2)), hexdec(substr($hex, 2, 2)), hexdec(substr($hex, 4, 2)), $alpha);
    }

    private function background() {
        // تدرج عمودي داكن
        $top = [30, 25, 18];
        $bottom = [12, 10, 8];
        for ($y = 0; $y < $this->h; $y++) {
            $t = $y / ($this->h - 1);
            $col = imagecolorallocate(
                $this->img,
                (int) ($top[0] + ($bottom[0] - $top[0]) * $t),
                (int) ($top[1] + ($bottom[1] - $top[1]) * $t),
                (int) ($top[2] + ($bottom[2] - $top[2]) * $t)
            );
            imageline($this->img, 0, $y, $this->w, $y, $col);
        }

        // توهج ذهبي خفيف في الزاوية
        for ($i = 0; $i < 36; $i++) {
            $r = 900 - $i * 22;
            $glow = imagecolorallocatealpha($this->img, 201, 150, 50, 125);
            imagefilledellipse($this->img, 120, 40, $r, (int) ($r * 0.8), $glow);
        }

        // إطار رفيع
        $frame = imagecolorallocatealpha($this->img, 201, 162, 74, 90);
        imagesetthickness($this->img, 2);
        imagerectangle($this->img, 22, 22, $this->w - 23, $this->h - 23, $frame);
        imagesetthickness($this->img, 1);
    }

    /**
     * رسم نص، ويعيد عرضه بالبكسل. $x هو الحافة اليمنى افتراضياً (RTL)
     * في التصميم الإنجليزي تُعكس الإحداثيات والمحاذاة أفقياً
     */
    private function text($text, $font, $size, $x, $baseline, $color, $align = 'right', $max_width = 0) {
        if (!$this->rtl) {
            $x = $this->w - $x;
            $align = $align === 'right' ? 'left' : ($align === 'left' ? 'right' : 'center');
        }
        return $this->draw_text($text, $font, $size, $x, $baseline, $color, $align, $max_width);
    }

    /**
     * رسم نص بإحداثيات فعلية دون عكس
     */
    private function draw_text($text, $font, $size, $x, $baseline, $color, $align = 'right', $max_width = 0) {
        $visual = $this->shape($text);
        $box = imagettfbbox($size, 0, $font, $visual);
        $width = abs($box[2] - $box[0]);

        // تصغير الخط تلقائياً للأرقام الطويلة (مثل الليرة اللبنانية)
        while ($max_width > 0 && $width > $max_width && $size > 12) {
            $size -= 2;
            $box = imagettfbbox($size, 0, $font, $visual);
            $width = abs($box[2] - $box[0]);
        }

        if ($align === 'right') {
            $start = $x - $width;
        } elseif ($align === 'center') {
            $start = $x - $width / 2;
        } else {
            $start = $x;
        }
        imagettftext($this->img, $size, 0, (int) round($start - $box[0]), (int) $baseline, $color, $font, $visual);
        return $width;
    }

    private function shape($text) {
        return $this->rtl ? GNAP_Arabic::visual($text) : (string) $text;
    }

    private function measure($text, $font, $size) {
        $box = imagettfbbox($size, 0, $font, $this->shape($text));
        return abs($box[2] - $box[0]);
    }

    private function rounded_box($x1, $y1, $x2, $y2, $r, $fill, $border) {
        if (!$this->rtl) {
            list($x1, $x2) = [$this->w - $x2, $this->w - $x1];
        }
        $this->rounded_fill($x1, $y1, $x2, $y2, $r, $border);
        $this->rounded_fill($x1 + 2, $y1 + 2, $x2 - 2, $y2 - 2, $r - 2, $fill);
    }

    private function rounded_fill($x1, $y1, $x2, $y2, $r, $color) {
        imagefilledrectangle($this->img, $x1 + $r, $y1, $x2 - $r, $y2, $color);
        imagefilledrectangle($this->img, $x1, $y1 + $r, $x2, $y2 - $r, $color);
        $d = $r * 2;
        imagefilledellipse($this->img, $x1 + $r, $y1 + $r, $d, $d, $color);
        imagefilledellipse($this->img, $x2 - $r, $y1 + $r, $d, $d, $color);
        imagefilledellipse($this->img, $x1 + $r, $y2 - $r, $d, $d, $color);
        imagefilledellipse($this->img, $x2 - $r, $y2 - $r, $d, $d, $color);
    }

    private function change_badge($x, $y, $pct) {
        if (abs($pct) < 0.05) {
            $color = $this->c['flat'];
            $label = '0.00%';
        } else {
            $color = $pct > 0 ? $this->c['up'] : $this->c['down'];
            $label = ($pct > 0 ? '+' : '-') . ($this->lang === 'ar' ? number_format(abs($pct), 2) : GNAP_Languages::num(abs($pct), 2, $this->lang)) . '%';
        }

        $w = 190; $h = 50;
        if (!$this->rtl) {
            $x = $this->w - $x - $w;
        }
        $this->rounded_fill($x, $y, $x + $w, $y + $h, 25, $color);

        // سهم
        $ax = $x + 30; $ay = $y + $h / 2;
        if (abs($pct) < 0.05) {
            imagefilledrectangle($this->img, $ax - 10, (int) $ay - 3, $ax + 10, (int) $ay + 3, $this->c['white']);
        } elseif ($pct > 0) {
            imagefilledpolygon($this->img, [$ax - 11, (int) $ay + 7, $ax + 11, (int) $ay + 7, $ax, (int) $ay - 10], $this->c['white']);
        } else {
            imagefilledpolygon($this->img, [$ax - 11, (int) $ay - 7, $ax + 11, (int) $ay - 7, $ax, (int) $ay + 10], $this->c['white']);
        }
        $this->draw_text($label, $this->bold, 24, $x + 56, $y + 36, $this->c['white'], 'left');
    }

    /**
     * مسار ملف الشعار: الرابط المحدد في الإعدادات، ثم شعار القالب، ثم أيقونة الموقع. فارغ إن لم يوجد شعار صالح
     */
    public static function logo_file() {
        $candidates = [];
        $url = (string) GNAP_Settings::get('logo_url');
        if ($url !== '') {
            $id = attachment_url_to_postid($url);
            $candidates[] = $id ? get_attached_file($id) : self::url_to_path($url);
        }
        foreach ([(int) get_theme_mod('custom_logo'), (int) get_option('site_icon')] as $id) {
            if ($id) {
                $candidates[] = get_attached_file($id);
            }
        }

        $file = '';
        foreach ($candidates as $candidate) {
            // GD لا يقرأ SVG، لذلك نتجاوزه إلى البديل التالي
            if ($candidate && is_readable($candidate) && preg_match('/\.(png|jpe?g|gif|webp)$/i', $candidate)) {
                $file = $candidate;
                break;
            }
        }
        return (string) apply_filters('gnap_image_logo', $file);
    }

    /**
     * تحويل رابط ملف على نفس الموقع إلى مساره على الخادم
     */
    private static function url_to_path($url) {
        $url = preg_replace('#^https?:#i', '', strtok($url, '?#'));
        $uploads = wp_upload_dir();
        $maps = [
            [$uploads['baseurl'], $uploads['basedir']],
            [content_url(), WP_CONTENT_DIR],
            [site_url(), ABSPATH],
        ];
        foreach ($maps as $map) {
            $base = untrailingslashit(preg_replace('#^https?:#i', '', $map[0]));
            if (stripos($url, $base . '/') === 0) {
                $path = realpath(trailingslashit($map[1]) . rawurldecode(substr($url, strlen($base) + 1)));
                if ($path && strpos(wp_normalize_path($path), wp_normalize_path(ABSPATH)) === 0) {
                    return $path;
                }
            }
        }
        return '';
    }

    /**
     * تحميل الشعار كصورة GD بألوان كاملة وقص الحواف الشفافة الزائدة
     */
    private function load_logo() {
        $file = self::logo_file();
        if ($file === '') {
            return null;
        }
        $data = @file_get_contents($file);
        $src = $data ? @imagecreatefromstring($data) : false;
        if (!$src) {
            return null;
        }
        if (!imageistruecolor($src)) {
            imagepalettetotruecolor($src);
        }
        imagesavealpha($src, true);

        $cropped = @imagecropauto($src, IMG_CROP_TRANSPARENT);
        if ($cropped) {
            imagedestroy($src);
            $src = $cropped;
        }
        return $src;
    }

    /**
     * رسم الشعار داخل مساحة أقصاها $max_w × $max_h، محاذى لليسار عند $x ومتوسط عمودياً حول $cy.
     * الشعار الداكن الشفاف يوضع على لوحة فاتحة ليظهر فوق الخلفية الداكنة. يعيد العرض المرسوم
     */
    private function logo($src, $x, $cy, $max_w, $max_h, $align = 'left') {
        if (!$this->rtl) {
            $x = $this->w - $x;
            $align = $align === 'left' ? 'right' : ($align === 'right' ? 'left' : 'center');
        }
        $sw = imagesx($src);
        $sh = imagesy($src);

        // متوسط إضاءة البكسلات المرئية، ووجود شفافية من عدمه
        $lum = 0; $count = 0; $transparent = false;
        $step = max(1, (int) floor(min($sw, $sh) / 60));
        for ($py = 0; $py < $sh; $py += $step) {
            for ($px = 0; $px < $sw; $px += $step) {
                $rgba = imagecolorat($src, $px, $py);
                $alpha = ($rgba >> 24) & 0x7F;
                if ($alpha > 64) {
                    $transparent = true;
                    continue;
                }
                $lum += 0.299 * (($rgba >> 16) & 0xFF) + 0.587 * (($rgba >> 8) & 0xFF) + 0.114 * ($rgba & 0xFF);
                $count++;
            }
        }
        $plate = $transparent && $count && ($lum / $count) < 110;
        $pad = $plate ? 12 : 0;

        // التكبير محدود بـ 3 أضعاف حتى لا يصبح الشعار الصغير ضبابياً
        $scale = min(($max_w - 2 * $pad) / $sw, ($max_h - 2 * $pad) / $sh, 3);
        $w = max(1, (int) round($sw * $scale));
        $h = max(1, (int) round($sh * $scale));
        $y = (int) round($cy - $h / 2);
        if ($align === 'center') {
            $x = (int) round($x - ($w + 2 * $pad) / 2);
        } elseif ($align === 'right') {
            $x = (int) round($x - $w - 2 * $pad);
        }

        if ($plate) {
            $this->rounded_box($x, $y - $pad, $x + $w + 2 * $pad, $y + $h + $pad, 18, $this->color('#f7f0e1'), $this->c['gold']);
        }
        imagecopyresampled($this->img, $src, $x + $pad, $y, 0, 0, $w, $h, $sw, $sh);
        imagedestroy($src);

        return $w + 2 * $pad;
    }

    private function flag($code, $x, $y, $size) {
        if (!$this->rtl) {
            $x = $this->w - $x - $size;
        }
        $country = GNAP_Countries::get($code);
        $file = GNAP_PATH . 'assets/flags/' . $code . '.png';
        // حلقة ذهبية حول العلم
        imagefilledellipse($this->img, $x + $size / 2, $y + $size / 2, $size + 8, $size + 8, $this->c['gold']);

        if (file_exists($file) && ($flag = @imagecreatefrompng($file))) {
            imagecopyresampled($this->img, $flag, $x, $y, 0, 0, $size, $size, imagesx($flag), imagesy($flag));
            imagedestroy($flag);
            return;
        }
        imagefilledellipse($this->img, $x + $size / 2, $y + $size / 2, $size, $size, $this->c['card']);
        // المقالات العامة: رمز الذهب الكيميائي Au بدل العلم
        if ($country && $country['global']) {
            $this->draw_text('Au', $this->bold, (int) ($size * 0.36), $x + $size / 2, $y + $size / 2 + (int) ($size * 0.15), $this->c['gold'], 'center');
            return;
        }
        $this->draw_text(strtoupper($code), $this->bold, 34, $x + $size / 2, $y + $size / 2 + 14, $this->c['gold'], 'center');
    }
}
