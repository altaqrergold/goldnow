<?php
/**
 * بيانات الدول العربية المدعومة
 */

if (!defined('ABSPATH')) {
    exit;
}

class GNAP_Countries {

    /**
     * term       : "سعر" أو "ثمن" حسب اللهجة المحلية
     * unit       : اسم العملة المختصر داخل الجمل (450 ريال)
     * levant     : استخدام أسماء الأشهر السريانية (أيلول، تشرين...)
     * parallel   : يوجد فرق كبير بين سعر الصرف الرسمي والموازي (يُضاف تنبيه)
     * pound      : اسم "الجنيه/الليرة الذهب" (8 غرامات عيار 21) إن كان متداولاً
     */
    public static function all() {
        static $all = null;
        if ($all === null) {
            $all = self::base();
            // مقال لكل لغة أجنبية (الإنجليزية، الفرنسية...) من حزم GNAP_Languages
            foreach (GNAP_Languages::all() as $lang => $p) {
                $all[$p['code']] = [
                    'name' => $p['name'], 'name_en' => 'World', 'en' => $p['slug'], 'currency' => 'USD', 'currency_name' => 'US Dollar',
                    'unit' => 'USD', 'symbol' => '$', 'capital' => 'GMT', 'tz' => 'UTC',
                    'global' => true, 'prefix' => $lang, 'lang' => $lang, 'headline' => $p['headline'],
                    'category_name' => $p['category'], 'admin_label' => $p['admin_label'],
                ];
            }
        }
        return $all;
    }

    private static function base() {
        return [
            'sa' => ['name' => 'السعودية',  'name_en' => 'Saudi Arabia', 'en' => 'saudi-arabia', 'currency' => 'SAR', 'currency_name' => 'ريال سعودي',   'unit' => 'ريال',  'symbol' => 'ر.س', 'capital' => 'الرياض',   'tz' => 'Asia/Riyadh'],
            'ae' => ['name' => 'الإمارات',  'name_en' => 'UAE', 'en' => 'uae',          'currency' => 'AED', 'currency_name' => 'درهم إماراتي', 'unit' => 'درهم',  'symbol' => 'د.إ', 'capital' => 'دبي',      'tz' => 'Asia/Dubai'],
            'kw' => ['name' => 'الكويت',    'name_en' => 'Kuwait', 'en' => 'kuwait',       'currency' => 'KWD', 'currency_name' => 'دينار كويتي',  'unit' => 'دينار', 'symbol' => 'د.ك', 'capital' => 'الكويت',   'tz' => 'Asia/Kuwait'],
            'qa' => ['name' => 'قطر',       'name_en' => 'Qatar', 'en' => 'qatar',        'currency' => 'QAR', 'currency_name' => 'ريال قطري',    'unit' => 'ريال',  'symbol' => 'ر.ق', 'capital' => 'الدوحة',   'tz' => 'Asia/Qatar'],
            'bh' => ['name' => 'البحرين',   'name_en' => 'Bahrain', 'en' => 'bahrain',      'currency' => 'BHD', 'currency_name' => 'دينار بحريني', 'unit' => 'دينار', 'symbol' => 'د.ب', 'capital' => 'المنامة',  'tz' => 'Asia/Bahrain'],
            'om' => ['name' => 'عمان',      'name_en' => 'Oman', 'en' => 'oman',         'currency' => 'OMR', 'currency_name' => 'ريال عماني',   'unit' => 'ريال',  'symbol' => 'ر.ع', 'capital' => 'مسقط',     'tz' => 'Asia/Muscat'],
            'eg' => ['name' => 'مصر',       'name_en' => 'Egypt', 'en' => 'egypt',        'currency' => 'EGP', 'currency_name' => 'جنيه مصري',    'unit' => 'جنيه',  'symbol' => 'ج.م', 'capital' => 'القاهرة',  'tz' => 'Africa/Cairo', 'pound' => 'الجنيه الذهب'],
            'ma' => ['name' => 'المغرب',    'name_en' => 'Morocco', 'en' => 'morocco',      'currency' => 'MAD', 'currency_name' => 'درهم مغربي',   'unit' => 'درهم',  'symbol' => 'د.م', 'capital' => 'الرباط',   'tz' => 'Africa/Casablanca', 'term' => 'ثمن'],
            'dz' => ['name' => 'الجزائر',   'name_en' => 'Algeria', 'en' => 'algeria',      'currency' => 'DZD', 'currency_name' => 'دينار جزائري', 'unit' => 'دينار', 'symbol' => 'د.ج', 'capital' => 'الجزائر',  'tz' => 'Africa/Algiers'],
            'tn' => ['name' => 'تونس',      'name_en' => 'Tunisia', 'en' => 'tunisia',      'currency' => 'TND', 'currency_name' => 'دينار تونسي',  'unit' => 'دينار', 'symbol' => 'د.ت', 'capital' => 'تونس',     'tz' => 'Africa/Tunis'],
            'ly' => ['name' => 'ليبيا',     'name_en' => 'Libya', 'en' => 'libya',        'currency' => 'LYD', 'currency_name' => 'دينار ليبي',   'unit' => 'دينار', 'symbol' => 'د.ل', 'capital' => 'طرابلس',   'tz' => 'Africa/Tripoli', 'parallel' => true],
            'jo' => ['name' => 'الأردن',    'name_en' => 'Jordan', 'en' => 'jordan',       'currency' => 'JOD', 'currency_name' => 'دينار أردني',  'unit' => 'دينار', 'symbol' => 'د.أ', 'capital' => 'عمّان',    'tz' => 'Asia/Amman', 'levant' => true],
            'lb' => ['name' => 'لبنان',     'name_en' => 'Lebanon', 'en' => 'lebanon',      'currency' => 'LBP', 'currency_name' => 'ليرة لبنانية', 'unit' => 'ليرة',  'symbol' => 'ل.ل', 'capital' => 'بيروت',    'tz' => 'Asia/Beirut', 'levant' => true, 'parallel' => true],
            'sy' => ['name' => 'سوريا',     'name_en' => 'Syria', 'en' => 'syria',        'currency' => 'SYP', 'currency_name' => 'ليرة سورية',   'unit' => 'ليرة',  'symbol' => 'ل.س', 'capital' => 'دمشق',     'tz' => 'Asia/Damascus', 'levant' => true, 'parallel' => true],
            'iq' => ['name' => 'العراق',    'name_en' => 'Iraq', 'en' => 'iraq',         'currency' => 'IQD', 'currency_name' => 'دينار عراقي',  'unit' => 'دينار', 'symbol' => 'د.ع', 'capital' => 'بغداد',    'tz' => 'Asia/Baghdad', 'levant' => true],
            'ps' => ['name' => 'فلسطين',    'name_en' => 'Palestine', 'en' => 'palestine',    'currency' => 'ILS', 'currency_name' => 'شيكل',         'unit' => 'شيكل',  'symbol' => '₪',   'capital' => 'القدس',    'tz' => 'Asia/Hebron', 'levant' => true],
            'ye' => ['name' => 'اليمن',     'name_en' => 'Yemen', 'en' => 'yemen',        'currency' => 'YER', 'currency_name' => 'ريال يمني',    'unit' => 'ريال',  'symbol' => 'ر.ي', 'capital' => 'صنعاء',    'tz' => 'Asia/Aden', 'parallel' => true],
            'sd' => ['name' => 'السودان',   'name_en' => 'Sudan', 'en' => 'sudan',        'currency' => 'SDG', 'currency_name' => 'جنيه سوداني',  'unit' => 'جنيه',  'symbol' => 'ج.س', 'capital' => 'الخرطوم',  'tz' => 'Africa/Khartoum', 'parallel' => true],
            'mr' => ['name' => 'موريتانيا', 'name_en' => 'Mauritania', 'en' => 'mauritania',   'currency' => 'MRU', 'currency_name' => 'أوقية موريتانية', 'unit' => 'أوقية', 'symbol' => 'أ.م', 'capital' => 'نواكشوط', 'tz' => 'Africa/Nouakchott'],
            'so' => ['name' => 'الصومال',   'name_en' => 'Somalia', 'en' => 'somalia',      'currency' => 'SOS', 'currency_name' => 'شلن صومالي',   'unit' => 'شلن',   'symbol' => 'ش.ص', 'capital' => 'مقديشو',   'tz' => 'Africa/Mogadishu'],
            'dj' => ['name' => 'جيبوتي',    'name_en' => 'Djibouti', 'en' => 'djibouti',     'currency' => 'DJF', 'currency_name' => 'فرنك جيبوتي',  'unit' => 'فرنك',  'symbol' => 'ف.ج', 'capital' => 'جيبوتي',   'tz' => 'Africa/Djibouti'],
            'km' => ['name' => 'جزر القمر', 'name_en' => 'Comoros', 'en' => 'comoros',      'currency' => 'KMF', 'currency_name' => 'فرنك قمري',    'unit' => 'فرنك',  'symbol' => 'ف.ق', 'capital' => 'موروني',   'tz' => 'Indian/Comoro'],

            // مقال عام غير مرتبط بدولة: سعر الذهب عالمياً بالدولار (عربي)
            'world' => ['name' => 'العالم', 'name_en' => 'World', 'en' => 'world', 'currency' => 'USD', 'currency_name' => 'دولار أمريكي', 'unit' => 'دولار', 'symbol' => '$', 'capital' => 'غرينتش', 'tz' => 'UTC',
                'global' => true, 'prefix' => 'global', 'headline' => 'سعر الذهب عالمياً اليوم', 'category_name' => 'سعر الذهب عالمياً', 'admin_label' => 'سعر الذهب عالمياً (عربي)'],
        ];
    }

    public static function get($code) {
        $all = self::all();
        if (!isset($all[$code])) {
            return null;
        }
        return array_merge(
            ['code' => $code, 'term' => 'سعر', 'levant' => false, 'parallel' => false, 'pound' => '', 'global' => false, 'prefix' => '', 'lang' => 'ar', 'headline' => '', 'category_name' => ''],
            $all[$code]
        );
    }

    /**
     * رموز الدول الفعلية فقط (بدون المقالات العامة)
     */
    public static function country_codes() {
        return array_keys(array_filter(self::all(), function ($c) {
            return empty($c['global']);
        }));
    }

    public static function admin_label($code) {
        $c = self::get($code);
        if (!$c) {
            return $code;
        }
        return isset($c['admin_label']) ? $c['admin_label'] : $c['name'] . ' (' . $c['currency'] . ')';
    }

    public static function timezone($code) {
        $country = self::get($code);
        try {
            return new DateTimeZone($country ? $country['tz'] : 'UTC');
        } catch (Exception $e) {
            return wp_timezone();
        }
    }

    /**
     * التاريخ المحلي للدولة بصيغ مختلفة للاستخدام في النصوص
     */
    public static function local_date($code, $timestamp = null) {
        $country = self::get($code);
        $date = new DateTime('@' . ($timestamp ?: time()));
        $date->setTimezone(self::timezone($code));

        $days = ['الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];
        $months = ['', 'يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو', 'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'];
        $levant = ['', 'كانون الثاني', 'شباط', 'آذار', 'نيسان', 'أيار', 'حزيران', 'تموز', 'آب', 'أيلول', 'تشرين الأول', 'تشرين الثاني', 'كانون الأول'];

        $m = (int) $date->format('n');
        $month = ($country && $country['levant']) ? $levant[$m] : $months[$m];

        return [
            'ymd'     => $date->format('Y-m-d'),
            'hm'      => $date->format('H:i'),
            'weekday' => $days[(int) $date->format('w')],
            'day'     => $date->format('j'),
            'month'   => $month,
            'year'    => $date->format('Y'),
            'date'    => $date->format('j') . ' ' . $month . ' ' . $date->format('Y'),
            'is_weekend_market' => in_array((int) $date->format('w'), [0, 6], true),
            'day_of_year' => (int) $date->format('z'),
            'weekday_en'  => $date->format('l'),
            'month_en'    => $date->format('F'),
            'date_en'     => $date->format('F j, Y'),
        ];
    }
}
