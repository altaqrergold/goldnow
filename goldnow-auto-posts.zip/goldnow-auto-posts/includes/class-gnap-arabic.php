<?php
/**
 * تشكيل النص العربي للرسم بمكتبة GD (التي لا تدعم الربط ولا الاتجاه من اليمين لليسار)
 *
 * - تحويل الحروف إلى أشكالها المتصلة (Presentation Forms-B) مع دعم لام ألف
 * - ترتيب النص بصرياً من اليمين لليسار مع إبقاء الأرقام والكلمات اللاتينية كما هي
 */

if (!defined('ABSPATH')) {
    exit;
}

class GNAP_Arabic {

    // [منفصل، نهائي، أولي، وسطي] — الحروف غير الواصلة لليسار لها شكلان فقط
    private static $forms = [
        'ء' => [0xFE80],
        'آ' => [0xFE81, 0xFE82], 'أ' => [0xFE83, 0xFE84], 'ؤ' => [0xFE85, 0xFE86],
        'إ' => [0xFE87, 0xFE88], 'ئ' => [0xFE89, 0xFE8A, 0xFE8B, 0xFE8C], 'ا' => [0xFE8D, 0xFE8E],
        'ب' => [0xFE8F, 0xFE90, 0xFE91, 0xFE92], 'ة' => [0xFE93, 0xFE94],
        'ت' => [0xFE95, 0xFE96, 0xFE97, 0xFE98], 'ث' => [0xFE99, 0xFE9A, 0xFE9B, 0xFE9C],
        'ج' => [0xFE9D, 0xFE9E, 0xFE9F, 0xFEA0], 'ح' => [0xFEA1, 0xFEA2, 0xFEA3, 0xFEA4],
        'خ' => [0xFEA5, 0xFEA6, 0xFEA7, 0xFEA8], 'د' => [0xFEA9, 0xFEAA], 'ذ' => [0xFEAB, 0xFEAC],
        'ر' => [0xFEAD, 0xFEAE], 'ز' => [0xFEAF, 0xFEB0],
        'س' => [0xFEB1, 0xFEB2, 0xFEB3, 0xFEB4], 'ش' => [0xFEB5, 0xFEB6, 0xFEB7, 0xFEB8],
        'ص' => [0xFEB9, 0xFEBA, 0xFEBB, 0xFEBC], 'ض' => [0xFEBD, 0xFEBE, 0xFEBF, 0xFEC0],
        'ط' => [0xFEC1, 0xFEC2, 0xFEC3, 0xFEC4], 'ظ' => [0xFEC5, 0xFEC6, 0xFEC7, 0xFEC8],
        'ع' => [0xFEC9, 0xFECA, 0xFECB, 0xFECC], 'غ' => [0xFECD, 0xFECE, 0xFECF, 0xFED0],
        'ف' => [0xFED1, 0xFED2, 0xFED3, 0xFED4], 'ق' => [0xFED5, 0xFED6, 0xFED7, 0xFED8],
        'ك' => [0xFED9, 0xFEDA, 0xFEDB, 0xFEDC], 'ل' => [0xFEDD, 0xFEDE, 0xFEDF, 0xFEE0],
        'م' => [0xFEE1, 0xFEE2, 0xFEE3, 0xFEE4], 'ن' => [0xFEE5, 0xFEE6, 0xFEE7, 0xFEE8],
        'ه' => [0xFEE9, 0xFEEA, 0xFEEB, 0xFEEC], 'و' => [0xFEED, 0xFEEE],
        'ى' => [0xFEEF, 0xFEF0], 'ي' => [0xFEF1, 0xFEF2, 0xFEF3, 0xFEF4],
        'ـ' => [0x0640, 0x0640, 0x0640, 0x0640],
    ];

    // لام ألف: [منفصل، نهائي]
    private static $lam_alef = [
        'آ' => [0xFEF5, 0xFEF6], 'أ' => [0xFEF7, 0xFEF8], 'إ' => [0xFEF9, 0xFEFA], 'ا' => [0xFEFB, 0xFEFC],
    ];

    private static $mirror = ['(' => ')', ')' => '(', '[' => ']', ']' => '[', '{' => '}', '}' => '{', '<' => '>', '>' => '<', '«' => '»', '»' => '«'];

    /**
     * يعيد النص جاهزاً لـ imagettftext
     */
    public static function visual($text) {
        $chars = preg_split('//u', (string) $text, -1, PREG_SPLIT_NO_EMPTY);
        $shaped = self::shape($chars);
        return self::reorder($shaped);
    }

    private static function joins_left($char) {
        return isset(self::$forms[$char]) && count(self::$forms[$char]) === 4;
    }

    private static function is_letter($char) {
        return isset(self::$forms[$char]);
    }

    /**
     * يعيد مصفوفة وحدات: كل حرف عربي مُشكّل كوحدة، وكل حرف آخر كما هو
     */
    private static function shape(array $chars) {
        $out = [];
        $count = count($chars);

        for ($i = 0; $i < $count; $i++) {
            $char = $chars[$i];

            if (!self::is_letter($char)) {
                $out[] = $char;
                continue;
            }

            $prev = $i > 0 ? $chars[$i - 1] : '';
            $connects_prev = $prev !== '' && self::joins_left($prev);

            // لام ألف
            $next = $i + 1 < $count ? $chars[$i + 1] : '';
            if ($char === 'ل' && isset(self::$lam_alef[$next])) {
                $out[] = mb_chr(self::$lam_alef[$next][$connects_prev ? 1 : 0], 'UTF-8');
                $i++;
                continue;
            }

            $connects_next = self::joins_left($char) && $next !== '' && self::is_letter($next) && $next !== 'ء';
            $forms = self::$forms[$char];

            if ($connects_prev && $connects_next) {
                $cp = $forms[3];
            } elseif ($connects_prev) {
                $cp = isset($forms[1]) ? $forms[1] : $forms[0];
            } elseif ($connects_next) {
                $cp = $forms[2];
            } else {
                // الشكل المنفصل هو الحرف الأساسي نفسه، وبعض الخطوط (مثل Cairo) لا تحتوي رموز FExx المنفصلة
                $out[] = $char;
                continue;
            }
            $out[] = mb_chr($cp, 'UTF-8');
        }

        return $out;
    }

    /**
     * ترتيب بصري لسطر اتجاهه الأساسي من اليمين لليسار:
     * تُجمع الأرقام واللاتينية (مع الفواصل والنقاط بينها) في كتلة واحدة لا تُعكس
     */
    private static function reorder(array $units) {
        $blocks = [];
        $ltr = '';
        $count = count($units);

        for ($i = 0; $i < $count; $i++) {
            $u = $units[$i];
            $is_strong_ltr = (bool) preg_match('/^[0-9A-Za-z$€£]$/u', $u);
            // فاصل رقمي بين رقمين (1,234.5) أو علامات ملاصقة للرقم (+1.2% / 12:30)
            $is_joiner = $ltr !== '' && preg_match('/^[.,:\/%\-]$/u', $u)
                && ($u === '%' || ($i + 1 < $count && preg_match('/^[0-9A-Za-z]$/u', $units[$i + 1])));
            $is_sign = $ltr === '' && preg_match('/^[+\-]$/u', $u)
                && $i + 1 < $count && preg_match('/^[0-9]$/u', $units[$i + 1]);

            if ($is_strong_ltr || $is_joiner || $is_sign) {
                $ltr .= $u;
                continue;
            }
            if ($ltr !== '') {
                $blocks[] = $ltr;
                $ltr = '';
            }
            $blocks[] = isset(self::$mirror[$u]) ? self::$mirror[$u] : $u;
        }
        if ($ltr !== '') {
            $blocks[] = $ltr;
        }

        return implode('', array_reverse($blocks));
    }
}
