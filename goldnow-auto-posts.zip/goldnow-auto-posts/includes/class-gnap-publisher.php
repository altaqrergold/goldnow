<?php
/**
 * إنشاء/تحديث المقال اليومي لدولة واحدة
 */

if (!defined('ABSPATH')) {
    exit;
}

class GNAP_Publisher {

    /**
     * @param string $code    رمز الدولة
     * @param string $context cron أو manual
     * @return array ['result' => created|updated|skipped|error, 'post_id' => int, 'message' => string]
     */
    public static function publish($code, $context = 'cron') {
        $country = GNAP_Countries::get($code);
        if (!$country) {
            return self::result('error', 0, 'دولة غير معروفة: ' . $code);
        }

        $settings = GNAP_Settings::get();
        $date = GNAP_Countries::local_date($code);
        $key = $code . '_' . $date['ymd'];

        // في النشر التلقائي نحسب المقال المحذوف (سلة المهملات) كموجود حتى لا يُعاد إنشاؤه
        $existing = self::find_post($key, $context === 'cron');
        if ($existing && ($context === 'cron' || $settings['on_exists'] === 'skip')) {
            $message = 'مقال اليوم موجود مسبقاً لـ ' . $country['name'] . '.';
            GNAP_Log::set_status($code, $date['ymd'], 'skipped', $message, $existing);
            return self::result('skipped', $existing, $message);
        }

        $snapshot = GNAP_Prices::snapshot($code);
        if (is_wp_error($snapshot)) {
            GNAP_Log::set_status($code, $date['ymd'], 'error', $snapshot->get_error_message());
            return self::result('error', 0, $snapshot->get_error_message());
        }

        $previous = self::previous_prices($code, $date['ymd']);
        // عند تحديث مقال موجود نحافظ على نفس القوالب (العنوان/المقدمة...) بدل استهلاك قوالب جديدة
        $variants = $existing ? get_post_meta($existing, '_gnap_variants', true) : [];
        $built = GNAP_Content::build($snapshot, $date, $previous, self::country_url($code), $variants);

        $postarr = [
            'post_title'   => $built['title'],
            'post_content' => $built['content'],
            'post_excerpt' => $built['description'],
            'meta_input'   => [
                '_gnap_country'             => $code,
                '_gnap_date'                => $date['ymd'],
                '_gnap_key'                 => $key,
                '_gnap_prices'              => self::price_meta($snapshot['local']),
                '_gnap_faq'                 => $built['faq'],
                '_gnap_description'         => $built['description'],
                '_gnap_variants'            => $built['variants'],
                // Yoast SEO
                '_yoast_wpseo_metadesc'     => $built['description'],
                '_yoast_wpseo_focuskw'      => $built['focus_keyword'],
                // Rank Math
                'rank_math_description'     => $built['description'],
                'rank_math_focus_keyword'   => $built['focus_keyword'],
            ],
        ];

        if ($existing) {
            $postarr['ID'] = $existing;
            $post_id = wp_update_post($postarr, true);
            $result = 'updated';
        } else {
            $postarr += [
                'post_status'   => $settings['post_status'],
                'post_type'     => 'post',
                'post_author'   => self::author_id($settings),
                'post_name'     => self::slug($country, $settings, $date['ymd']),
                'post_category' => self::category_ids($country, $settings),
            ];
            $post_id = wp_insert_post($postarr, true);
            $result = 'created';
        }

        if (is_wp_error($post_id)) {
            GNAP_Log::set_status($code, $date['ymd'], 'error', 'فشل حفظ المقال: ' . $post_id->get_error_message());
            return self::result('error', 0, $post_id->get_error_message());
        }

        wp_set_post_tags($post_id, $built['tags'], false);
        self::assign_country_term($post_id, $code);

        $image_note = '';
        if ($settings['image']) {
            $image = self::attach_image($post_id, $snapshot, $date, $built);
            if (is_wp_error($image)) {
                $image_note = ' (بدون صورة: ' . $image->get_error_message() . ')';
            }
        }

        $message = sprintf(
            '%s مقال %s: %s%s',
            $result === 'created' ? 'تم نشر' : 'تم تحديث',
            $country['name'],
            $built['title'],
            $image_note
        );
        GNAP_Log::set_status($code, $date['ymd'], $result, $message, $post_id);

        return self::result($result, $post_id, $message);
    }

    private static function result($result, $post_id, $message) {
        return ['result' => $result, 'post_id' => (int) $post_id, 'message' => $message];
    }

    public static function find_post($key, $include_trash = false) {
        $statuses = ['publish', 'draft', 'pending', 'future', 'private'];
        if ($include_trash) {
            $statuses[] = 'trash';
        }
        $ids = get_posts([
            'post_type'        => 'post',
            'post_status'      => $statuses,
            'posts_per_page'   => 1,
            'fields'           => 'ids',
            'no_found_rows'    => true,
            'suppress_filters' => true,
            'meta_key'         => '_gnap_key',
            'meta_value'       => $key,
        ]);
        return $ids ? (int) $ids[0] : 0;
    }

    /**
     * أسعار آخر مقال سابق لنفس الدولة للمقارنة
     */
    private static function previous_prices($code, $ymd) {
        $ids = get_posts([
            'post_type'        => 'post',
            'post_status'      => ['publish', 'draft', 'pending', 'future', 'private'],
            'posts_per_page'   => 1,
            'fields'           => 'ids',
            'no_found_rows'    => true,
            'suppress_filters' => true,
            'meta_key'         => '_gnap_date',
            'orderby'          => 'meta_value',
            'order'            => 'DESC',
            'meta_query'       => [
                ['key' => '_gnap_country', 'value' => $code],
                ['key' => '_gnap_date', 'value' => $ymd, 'compare' => '<'],
            ],
        ]);
        if (!$ids) {
            return null;
        }
        $prices = get_post_meta($ids[0], '_gnap_prices', true);
        if (!is_array($prices) || empty($prices['21k'])) {
            return null;
        }
        return ['date' => get_post_meta($ids[0], '_gnap_date', true), 'local' => $prices];
    }

    private static function price_meta($local) {
        $out = [];
        foreach ($local as $carat => $value) {
            $out[$carat] = round($value, 4);
        }
        return $out;
    }

    private static function author_id($settings) {
        if ($settings['author'] && get_userdata($settings['author'])) {
            return (int) $settings['author'];
        }
        $admins = get_users(['role' => 'administrator', 'number' => 1, 'fields' => 'ID', 'orderby' => 'ID']);
        return $admins ? (int) $admins[0] : 1;
    }

    private static function slug($country, $settings, $ymd) {
        if ($country['global']) {
            return $settings[$country['prefix'] . '_slug'] . '-' . $ymd;
        }
        return $settings['slug_prefix'] . '-' . $country['en'] . '-' . $ymd;
    }

    /**
     * التصنيف الرئيسي، أو تصنيف فرعي لكل دولة (يُنشأ تلقائياً).
     * المقالات العامة (عالمي/إنجليزي) لها تصنيف مستقل: المحدد في إعداداتها، أو تصنيف يُنشأ تلقائياً
     */
    private static function category_ids($country, $settings) {
        if ($country['global']) {
            $chosen = (int) $settings[$country['prefix'] . '_category'];
            if ($chosen && term_exists($chosen, 'category')) {
                return [$chosen];
            }
            // مقالات اللغات: الرابط اللاتيني للغة (gold-price-today، prix-or-aujourdhui...)
            $slug = $country['lang'] === 'ar' ? 'gold-price-' . $country['en'] : $country['en'];
            $term = get_term_by('slug', $slug, 'category');
            if ($term) {
                return [(int) $term->term_id];
            }
            $created = wp_insert_term($country['category_name'], 'category', ['slug' => $slug]);
            return is_wp_error($created) ? [] : [(int) $created['term_id']];
        }

        $parent = (int) $settings['category'];
        if ($parent && !term_exists($parent, 'category')) {
            $parent = 0;
        }
        if (!$settings['sub_categories']) {
            return $parent ? [$parent] : [];
        }

        $slug = 'gold-price-' . $country['en'];
        $term = get_term_by('slug', $slug, 'category');
        if ($term) {
            return [(int) $term->term_id];
        }
        $created = wp_insert_term($country['term'] . ' الذهب في ' . $country['name'], 'category', [
            'slug'   => $slug,
            'parent' => $parent,
        ]);
        if (is_wp_error($created)) {
            return $parent ? [$parent] : [];
        }
        return [(int) $created['term_id']];
    }

    /**
     * ربط المقال بتصنيف "countries" الخاص بالقالب إن كان مفعلاً للمقالات
     */
    private static function country_term($code) {
        if (!taxonomy_exists('countries')) {
            return null;
        }
        $terms = get_terms([
            'taxonomy'   => 'countries',
            'hide_empty' => false,
            'number'     => 1,
            'meta_key'   => 'country_code',
            'meta_value' => $code,
        ]);
        return (!is_wp_error($terms) && $terms) ? $terms[0] : null;
    }

    private static function assign_country_term($post_id, $code) {
        if (!is_object_in_taxonomy('post', 'countries')) {
            return;
        }
        $term = self::country_term($code);
        if ($term) {
            wp_set_object_terms($post_id, (int) $term->term_id, 'countries', true);
        }
    }

    private static function country_url($code) {
        $term = self::country_term($code);
        if (!$term) {
            return '';
        }
        $link = get_term_link($term);
        return is_wp_error($link) ? '' : $link;
    }

    public static function gd_editor() {
        return ['WP_Image_Editor_GD'];
    }

    public static function limit_sizes($sizes) {
        $keep = apply_filters('gnap_image_sizes', ['thumbnail', 'medium']);
        return array_intersect_key($sizes, array_flip($keep));
    }

    /**
     * توليد الصورة ورفعها كمرفق وتعيينها صورة بارزة (مع حذف الصورة القديمة عند التحديث)
     */
    private static function attach_image($post_id, $snapshot, $date, $built) {
        $upload = wp_upload_dir();
        if (!empty($upload['error'])) {
            return new WP_Error('gnap_upload', $upload['error']);
        }

        $post = get_post($post_id);
        $filename = wp_unique_filename($upload['path'], $post->post_name . '.jpg');
        $path = trailingslashit($upload['path']) . $filename;
        $site = wp_parse_url(home_url(), PHP_URL_HOST);

        $generated = GNAP_Image::generate($snapshot, $date, $built['change_pct'], $site, $path);
        if (is_wp_error($generated)) {
            return $generated;
        }

        $attachment_id = wp_insert_attachment([
            'post_mime_type' => 'image/jpeg',
            'post_title'     => $built['title'],
            'post_content'   => '',
            'post_status'    => 'inherit',
            'guid'           => trailingslashit($upload['url']) . $filename,
        ], $path, $post_id, true);

        if (is_wp_error($attachment_id)) {
            @unlink($path);
            return $attachment_id;
        }

        require_once ABSPATH . 'wp-admin/includes/image.php';
        // توليد المقاسات التي يستخدمها القالب فقط بدل كل المقاسات المسجلة (توفير للمعالج والمساحة)
        add_filter('intermediate_image_sizes_advanced', [__CLASS__, 'limit_sizes']);
        add_filter('big_image_size_threshold', '__return_false');
        // GD بدل Imagick: Imagick قد يستهلك كل أنوية المعالج أثناء تصغير الصور
        add_filter('wp_image_editors', [__CLASS__, 'gd_editor']);
        wp_update_attachment_metadata($attachment_id, wp_generate_attachment_metadata($attachment_id, $path));
        remove_filter('intermediate_image_sizes_advanced', [__CLASS__, 'limit_sizes']);
        remove_filter('big_image_size_threshold', '__return_false');
        remove_filter('wp_image_editors', [__CLASS__, 'gd_editor']);
        update_post_meta($attachment_id, '_wp_attachment_image_alt', $built['title']);
        update_post_meta($attachment_id, '_gnap_image', 1);

        $old = (int) get_post_thumbnail_id($post_id);
        set_post_thumbnail($post_id, $attachment_id);
        if ($old && $old !== $attachment_id && get_post_meta($old, '_gnap_image', true)) {
            wp_delete_attachment($old, true);
        }
        return $attachment_id;
    }
}
