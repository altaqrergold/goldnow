<?php
/**
 * حزم اللغات للمقالات العامة بلغات أجنبية (سعر الذهب عالمياً بالدولار)
 *
 * لكل لغة: رمز المقال، أسماء الأيام والأشهر، تنسيق الأرقام والعملة، القوالب الافتراضية
 * (العنوان/الوصف/المقدمة/الوسوم/الملاحظة) التي تُعدّل من الإعدادات، ونصوص جسم المقال والصورة.
 *
 * لإضافة لغة جديدة يكفي إضافة حزمة هنا: تظهر تلقائياً في الإعدادات والنشر.
 */

if (!defined('ABSPATH')) {
    exit;
}

class GNAP_Languages {

    const NBSP = "\u{00A0}";

    public static function all() {
        static $packs = null;
        if ($packs === null) {
            $packs = [
                'en' => self::en(),
                'fr' => self::fr(),
                'de' => self::de(),
                'it' => self::it(),
                'pt' => self::pt(),
                'ru' => self::ru(),
                'hi' => self::hi(),
            ];
        }
        return $packs;
    }

    public static function get($lang) {
        $all = self::all();
        return isset($all[$lang]) ? $all[$lang] : null;
    }

    /**
     * تنسيق رقم حسب اللغة. $decimals = null: بدون كسور للأرقام الكبيرة (مثل GNAP_Prices::format)
     */
    public static function num($value, $decimals, $lang) {
        $p = self::get($lang);
        if ($decimals === null) {
            $decimals = abs($value) >= 1000 ? 0 : 2;
        }
        return number_format((float) $value, $decimals, $p['dec'], $p['thou']);
    }

    public static function money($value, $decimals, $lang) {
        return sprintf(self::get($lang)['money'], self::num($value, $decimals, $lang));
    }

    /**
     * التاريخ بلغة الحزمة: weekday, date (بدون اليوم), day, month, year
     */
    public static function date($lang, $ymd) {
        $p = self::get($lang);
        $d = new DateTime($ymd);
        $out = [
            '{weekday}' => $p['weekdays'][(int) $d->format('w')],
            '{day}'     => $d->format('j'),
            '{month}'   => $p['months'][(int) $d->format('n') - 1],
            '{year}'    => $d->format('Y'),
        ];
        $out['{date}'] = strtr($p['date_format'], $out);
        return $out;
    }

    public static function upper_first($text) {
        return mb_strtoupper(mb_substr($text, 0, 1, 'UTF-8'), 'UTF-8') . mb_substr($text, 1, null, 'UTF-8');
    }

    /* ---------------------------------------------------------------- English */

    private static function en() {
        return [
            'code'        => 'english',
            'name'        => 'English',
            'admin_label' => 'Gold Price Today (English)',
            'headline'    => 'Gold Price Today',
            'category'    => 'Gold Price Today',
            'slug'        => 'gold-price-today',
            'dec' => '.', 'thou' => ',', 'money' => '$%s',
            'weekdays'    => ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'],
            'months'      => ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
            'date_format' => '{month} {day}, {year}',
            'full_date'   => '{weekday}, {date}',
            'defaults' => [
                'title_templates' => [
                    'Gold Price Today, {weekday} {date}: Ounce at ${oz}',
                    'Gold Price Today in USD per Gram and Ounce - {date}',
                    'Gold Rate Today {date}: 24K Gold at ${p24} per Gram',
                    'Live Gold Price Today {weekday}, {date} in US Dollars',
                    'Gold Price per Ounce Today, {date}: ${oz}',
                    'Today\'s Gold Price, {date}: 24K, 22K, 21K and 18K in USD',
                    'Gold Price Update {weekday}, {date} - Spot Gold at ${oz}',
                    'How Much Is Gold Worth Today, {date}',
                    'Gold Price per Gram Today in USD - {weekday}, {date}',
                    'Spot Gold Price Today, {date}: Ounce and Gram Rates',
                    'Gold Prices Today, {date}: 21K Gold at ${p21} per Gram',
                    'Gold Price in Arab Countries and Worldwide Today - {date}',
                ],
                'desc_templates' => [
                    'Gold price today {weekday}, {date}: spot gold at ${oz} per ounce and 24K gold at ${p24} per gram, plus 22K, 21K and 18K rates and prices across Arab countries.',
                    'Check today\'s gold price in USD for {date}: ${oz} per ounce, ${p24} per gram for 24K, with a comparison to yesterday and local prices in Arab currencies.',
                    'Live gold rates for {weekday}, {date}: 24K at ${p24}, 21K at ${p21} and 18K at ${p18} per gram, with the ounce trading at ${oz}.',
                ],
                'intro_templates' => [
                    'The spot price of gold stands at ${oz} per troy ounce today, {weekday}, {date}, putting 24-karat gold at ${p24} per gram and 21-karat gold at ${p21} per gram.',
                    'Here is the latest gold price for {weekday}, {date}. One ounce of gold is trading at ${oz}, while a gram of 24K gold costs ${p24} and a gram of 18K gold costs ${p18}.',
                    'Gold is trading at ${oz} per ounce on {weekday}, {date}. Based on this spot rate, 24K gold is priced at ${p24} per gram, 22K at ${p22} and 21K at ${p21}.',
                    'Looking for the gold rate today? On {weekday}, {date}, an ounce of gold is worth ${oz}, which works out to ${p24} per gram for pure 24K gold.',
                    'In today\'s gold price update for {weekday}, {date}, the precious metal is quoted at ${oz} per ounce, with 24K gold at ${p24} per gram and 18K gold at ${p18} per gram.',
                ],
                'tags'        => 'gold price today, gold price per ounce, gold price per gram, gold rate in USD',
                'footer_note' => 'Prices are indicative, based on the international spot price of gold and official exchange rates. They do not include making charges or taxes and may vary slightly between jewellers.',
            ],
            's' => [
                'change_flat'  => 'The price is little changed from the previous day.',
                'change_up'    => 'That is up %1$s (%2$s%%) from the previous price of %3$s.',
                'change_down'  => 'That is down %1$s (%2$s%%) from the previous price of %3$s.',
                'weekend'      => 'Global markets are closed for the weekend, so prices remain close to Friday\'s closing levels.',
                'h_table'      => ['Gold Price per Gram Today by Karat', 'Today\'s Gold Rates for All Karats in USD', 'Gold Price Table for {date}'],
                'th_karat'     => 'Karat', 'th_gram' => 'Price per Gram (USD)', 'th_purity' => 'Purity',
                'h_units'      => ['Gold Price by Weight Today', 'Gold Price per Tola, Ounce and Kilogram', 'How Much Is Gold Worth by Weight'],
                'th_weight'    => 'Weight', 'th_price' => 'Price (USD)',
                'weights'      => ['1 Gram (24K)', '10 Grams (24K)', '1 Tola (11.66 g)', '1 Troy Ounce (31.10 g)', '1 Kilogram (24K)'],
                'h_ounce'      => ['Gold Price per Ounce Today', 'Gold Ounce Price over the Last 30 Days', 'Spot Gold Price Range This Month'],
                'ounce_text'   => 'The troy ounce is the standard unit used to price gold on international markets. Today it is quoted at {oz_money}.',
                'range'        => 'Over the last 30 days, the ounce reached a high of %1$s and a low of %2$s.',
                'range_top'    => 'Gold is currently trading near the top of this range.',
                'range_bottom' => 'Gold is currently trading near the bottom of this range.',
                'range_mid'    => 'Gold is currently trading within the middle of this range.',
                'h_arab'       => ['Gold Price in Arab Countries Today', '21K Gold Price per Gram in Arab Countries - {date}', 'Gold Rates in Local Arab Currencies Today'],
                'arab_text'    => 'Based on the spot price and official exchange rates, here is what a gram of gold costs across the Arab world today:',
                'th_country'   => 'Country', 'th_21' => '21K per Gram', 'th_24' => '24K per Gram',
                'h_compare'    => ['Gold Price Today vs. Yesterday', 'How Gold Prices Changed Since the Last Update', 'Gold Price Change Compared with the Previous Day'],
                'th_prev'      => 'Previous', 'th_today' => 'Today', 'th_change' => 'Change',
                'h_faq'        => ['Gold Price FAQ', 'Frequently Asked Questions about Gold Prices', 'Quick Answers about Today\'s Gold Rate'],
                'faq' => [
                    ['What is the gold price per ounce today?', 'On {weekday}, {date}, one troy ounce of gold costs {oz_money}.'],
                    ['What is the price of 24K gold per gram today?', 'A gram of 24-karat gold costs {p24_money} today.'],
                    ['What is the price of 22K gold per gram today?', 'A gram of 22-karat gold costs {p22_money} today.'],
                    ['What is the price of 21K and 18K gold per gram?', '21K gold costs {p21_money} per gram and 18K gold costs {p18_money} per gram today.'],
                    ['How many grams are in an ounce of gold?', 'One troy ounce, the standard unit for gold, equals 31.1035 grams.'],
                    ['Do these prices include making charges?', 'No. These are raw gold prices based on the spot market and do not include making charges, VAT or dealer premiums.'],
                ],
                'updated'      => 'Last updated: {time} GMT.',
                'ounce'        => 'Ounce',
                'karat'        => '%dK',
                'focus'        => 'gold price today',
            ],
            'img' => ['main' => 'Gold Price per Ounce', 'gram' => '%dK per gram', 'kilo' => '1 kg of 24K gold', 'updated' => 'Last update %s GMT'],
            'countries' => [], // الإنجليزية تستخدم name_en من GNAP_Countries
        ];
    }

    /* ---------------------------------------------------------------- Français */

    private static function fr() {
        return [
            'code'        => 'french',
            'name'        => 'Français',
            'admin_label' => 'Prix de l’or (Français)',
            'headline'    => 'Prix de l’or aujourd’hui',
            'category'    => 'Prix de l’or aujourd’hui',
            'slug'        => 'prix-or-aujourdhui',
            'dec' => ',', 'thou' => self::NBSP, 'money' => '%s' . self::NBSP . '$',
            'weekdays'    => ['dimanche', 'lundi', 'mardi', 'mercredi', 'jeudi', 'vendredi', 'samedi'],
            'months'      => ['janvier', 'février', 'mars', 'avril', 'mai', 'juin', 'juillet', 'août', 'septembre', 'octobre', 'novembre', 'décembre'],
            'date_format' => '{day} {month} {year}',
            'full_date'   => '{weekday} {date}',
            'defaults' => [
                'title_templates' => [
                    'Prix de l’or aujourd’hui, {weekday} {date} : l’once à {oz_money}',
                    'Cours de l’or du {date} en dollars : once et gramme',
                    'Prix de l’or au gramme le {date} : 24 carats à {p24_money}',
                    'Combien vaut l’or aujourd’hui, {weekday} {date}',
                    'Cours de l’once d’or le {date} : {oz_money}',
                    'Prix de l’or 24, 22, 21 et 18 carats le {date}',
                    'Or : le cours du {weekday} {date} à {oz_money} l’once',
                    'Prix de l’or en dollars aujourd’hui - {date}',
                    'Cours de l’or actualisé, {weekday} {date}',
                    'Prix de l’or dans les pays arabes et dans le monde le {date}',
                ],
                'desc_templates' => [
                    'Prix de l’or aujourd’hui, {weekday} {date} : l’once cote {oz_money} et le gramme d’or 24 carats {p24_money}, avec les prix en 22, 21 et 18 carats et dans les pays arabes.',
                    'Découvrez le cours de l’or du {date} en dollars : {oz_money} l’once, {p24_money} le gramme en 24 carats, comparaison avec la veille et prix en devises arabes.',
                    'Cours de l’or du {weekday} {date} : 24 carats à {p24_money}, 21 carats à {p21_money} et 18 carats à {p18_money} le gramme, l’once à {oz_money}.',
                ],
                'intro_templates' => [
                    'Le cours de l’or s’établit à {oz_money} l’once ce {weekday} {date}, ce qui place le gramme d’or 24 carats à {p24_money} et le gramme 21 carats à {p21_money}.',
                    'Voici le dernier prix de l’or pour le {weekday} {date}. Une once d’or s’échange à {oz_money}, tandis que le gramme d’or 24 carats coûte {p24_money} et le gramme 18 carats {p18_money}.',
                    'L’or se négocie à {oz_money} l’once ce {weekday} {date}. Sur cette base, le gramme coûte {p24_money} en 24 carats, {p22_money} en 22 carats et {p21_money} en 21 carats.',
                    'Vous cherchez le prix de l’or aujourd’hui ? Ce {weekday} {date}, une once d’or vaut {oz_money}, soit {p24_money} le gramme d’or pur 24 carats.',
                    'Dans notre point quotidien du {weekday} {date}, le métal jaune est coté {oz_money} l’once, avec le 24 carats à {p24_money} le gramme et le 18 carats à {p18_money} le gramme.',
                ],
                'tags'        => 'prix de l’or aujourd’hui, cours de l’or, prix de l’once d’or, prix de l’or au gramme',
                'footer_note' => 'Les prix sont indicatifs et calculés à partir du cours mondial de l’or et des taux de change officiels. Ils n’incluent ni la façon ni les taxes et peuvent varier légèrement d’un bijoutier à l’autre.',
            ],
            's' => [
                'change_flat'  => 'Le prix est quasiment inchangé par rapport à la veille.',
                'change_up'    => 'Il est en hausse de %1$s (%2$s %%) par rapport au prix précédent de %3$s.',
                'change_down'  => 'Il est en baisse de %1$s (%2$s %%) par rapport au prix précédent de %3$s.',
                'weekend'      => 'Les marchés mondiaux étant fermés le week-end, les prix restent proches de leurs niveaux de clôture du vendredi.',
                'h_table'      => ['Prix de l’or au gramme aujourd’hui par carat', 'Cours de l’or pour tous les carats en dollars', 'Tableau des prix de l’or du {date}'],
                'th_karat'     => 'Carat', 'th_gram' => 'Prix du gramme (USD)', 'th_purity' => 'Pureté',
                'h_units'      => ['Prix de l’or selon le poids', 'Prix de l’or au tola, à l’once et au kilo', 'Combien vaut l’or selon le poids'],
                'th_weight'    => 'Poids', 'th_price' => 'Prix (USD)',
                'weights'      => ['1 gramme (24 carats)', '10 grammes (24 carats)', '1 tola (11,66 g)', '1 once troy (31,10 g)', '1 kilogramme (24 carats)'],
                'h_ounce'      => ['Prix de l’once d’or aujourd’hui', 'L’once d’or sur les 30 derniers jours', 'Fourchette du cours de l’or ce mois-ci'],
                'ounce_text'   => 'L’once troy est l’unité de référence pour coter l’or sur les marchés internationaux. Elle s’échange aujourd’hui à {oz_money}.',
                'range'        => 'Sur les 30 derniers jours, l’once a atteint un plus haut de %1$s et un plus bas de %2$s.',
                'range_top'    => 'L’or évolue actuellement près du haut de cette fourchette.',
                'range_bottom' => 'L’or évolue actuellement près du bas de cette fourchette.',
                'range_mid'    => 'L’or évolue actuellement au milieu de cette fourchette.',
                'h_arab'       => ['Prix de l’or dans les pays arabes aujourd’hui', 'Prix du gramme d’or 21 carats dans les pays arabes - {date}', 'Cours de l’or en devises arabes aujourd’hui'],
                'arab_text'    => 'Sur la base du cours mondial et des taux de change officiels, voici le prix du gramme d’or dans le monde arabe aujourd’hui :',
                'th_country'   => 'Pays', 'th_21' => '21 carats / g', 'th_24' => '24 carats / g',
                'h_compare'    => ['Prix de l’or aujourd’hui par rapport à hier', 'Évolution du prix de l’or depuis la dernière mise à jour', 'Variation du prix de l’or par rapport à la veille'],
                'th_prev'      => 'Précédent', 'th_today' => 'Aujourd’hui', 'th_change' => 'Variation',
                'h_faq'        => ['Questions fréquentes sur le prix de l’or', 'FAQ : le cours de l’or', 'Réponses rapides sur le prix de l’or du jour'],
                'faq' => [
                    ['Quel est le prix de l’once d’or aujourd’hui ?', 'Ce {weekday} {date}, une once troy d’or coûte {oz_money}.'],
                    ['Quel est le prix du gramme d’or 24 carats aujourd’hui ?', 'Le gramme d’or 24 carats coûte {p24_money} aujourd’hui.'],
                    ['Quel est le prix du gramme d’or 22 carats aujourd’hui ?', 'Le gramme d’or 22 carats coûte {p22_money} aujourd’hui.'],
                    ['Quel est le prix de l’or 21 et 18 carats au gramme ?', 'Le gramme coûte {p21_money} en 21 carats et {p18_money} en 18 carats aujourd’hui.'],
                    ['Combien de grammes dans une once d’or ?', 'Une once troy, l’unité de référence pour l’or, équivaut à 31,1035 grammes.'],
                    ['Ces prix incluent-ils la façon ?', 'Non. Il s’agit du prix de l’or brut basé sur le cours mondial, hors façon, TVA et marge du vendeur.'],
                ],
                'updated'      => 'Dernière mise à jour : {time} GMT.',
                'ounce'        => 'Once',
                'karat'        => '%d carats',
                'focus'        => 'prix de l’or aujourd’hui',
            ],
            'img' => ['main' => 'Prix de l’once d’or', 'gram' => '%d carats / g', 'kilo' => '1 kg d’or 24 carats', 'updated' => 'Mise à jour %s GMT'],
            'countries' => [
                'sa' => 'Arabie saoudite', 'ae' => 'Émirats arabes unis', 'kw' => 'Koweït', 'qa' => 'Qatar', 'bh' => 'Bahreïn', 'om' => 'Oman',
                'eg' => 'Égypte', 'ma' => 'Maroc', 'dz' => 'Algérie', 'tn' => 'Tunisie', 'ly' => 'Libye', 'jo' => 'Jordanie', 'lb' => 'Liban',
                'sy' => 'Syrie', 'iq' => 'Irak', 'ps' => 'Palestine', 'ye' => 'Yémen', 'sd' => 'Soudan', 'mr' => 'Mauritanie', 'so' => 'Somalie',
                'dj' => 'Djibouti', 'km' => 'Comores',
            ],
        ];
    }

    /* ---------------------------------------------------------------- Deutsch */

    private static function de() {
        return [
            'code'        => 'german',
            'name'        => 'Deutsch',
            'admin_label' => 'Goldpreis heute (Deutsch)',
            'headline'    => 'Goldpreis heute',
            'category'    => 'Goldpreis heute',
            'slug'        => 'goldpreis-heute',
            'dec' => ',', 'thou' => '.', 'money' => '%s' . self::NBSP . '$',
            'weekdays'    => ['Sonntag', 'Montag', 'Dienstag', 'Mittwoch', 'Donnerstag', 'Freitag', 'Samstag'],
            'months'      => ['Januar', 'Februar', 'März', 'April', 'Mai', 'Juni', 'Juli', 'August', 'September', 'Oktober', 'November', 'Dezember'],
            'date_format' => '{day}. {month} {year}',
            'full_date'   => '{weekday}, {date}',
            'defaults' => [
                'title_templates' => [
                    'Goldpreis heute, {weekday}, {date}: Unze bei {oz_money}',
                    'Goldpreis pro Gramm und Unze in US-Dollar am {date}',
                    'Goldkurs am {date}: 24 Karat Gold kostet {p24_money} pro Gramm',
                    'Aktueller Goldpreis am {weekday}, {date}',
                    'Goldpreis pro Unze am {date}: {oz_money}',
                    'Goldpreise am {date}: 24, 22, 21 und 18 Karat in US-Dollar',
                    'Gold am {weekday}, {date}: Unze notiert bei {oz_money}',
                    'Was kostet Gold heute, {date}',
                    'Goldpreis pro Gramm heute in US-Dollar - {weekday}, {date}',
                    'Goldpreis in arabischen Ländern und weltweit am {date}',
                ],
                'desc_templates' => [
                    'Goldpreis heute, {weekday}, {date}: Die Unze kostet {oz_money}, ein Gramm 24 Karat Gold {p24_money}. Dazu Preise für 22, 21 und 18 Karat sowie in arabischen Ländern.',
                    'Aktueller Goldkurs vom {date} in US-Dollar: {oz_money} pro Unze, {p24_money} pro Gramm 24 Karat, mit Vergleich zum Vortag und Preisen in arabischen Währungen.',
                    'Goldpreise am {weekday}, {date}: 24 Karat {p24_money}, 21 Karat {p21_money} und 18 Karat {p18_money} pro Gramm, die Unze bei {oz_money}.',
                ],
                'intro_templates' => [
                    'Der Goldpreis liegt heute, am {weekday}, {date}, bei {oz_money} je Feinunze. Damit kostet ein Gramm 24 Karat Gold {p24_money} und ein Gramm 21 Karat Gold {p21_money}.',
                    'Hier ist der aktuelle Goldpreis für {weekday}, den {date}. Eine Unze Gold wird zu {oz_money} gehandelt, ein Gramm 24 Karat kostet {p24_money} und ein Gramm 18 Karat {p18_money}.',
                    'Gold notiert am {weekday}, {date}, bei {oz_money} pro Unze. Auf dieser Basis kostet ein Gramm 24 Karat {p24_money}, 22 Karat {p22_money} und 21 Karat {p21_money}.',
                    'Sie suchen den Goldpreis von heute? Am {weekday}, {date}, ist eine Unze Gold {oz_money} wert – das entspricht {p24_money} pro Gramm reinem 24-Karat-Gold.',
                    'Im heutigen Goldpreis-Update für {weekday}, den {date}, wird das Edelmetall mit {oz_money} je Unze bewertet, 24 Karat Gold mit {p24_money} und 18 Karat Gold mit {p18_money} pro Gramm.',
                ],
                'tags'        => 'Goldpreis heute, Goldkurs, Goldpreis pro Unze, Goldpreis pro Gramm',
                'footer_note' => 'Die Preise sind Richtwerte auf Basis des internationalen Goldkurses und der offiziellen Wechselkurse. Verarbeitungskosten und Steuern sind nicht enthalten; die Preise können je nach Händler leicht abweichen.',
            ],
            's' => [
                'change_flat'  => 'Der Preis ist gegenüber dem Vortag nahezu unverändert.',
                'change_up'    => 'Das ist ein Plus von %1$s (%2$s %%) gegenüber dem vorherigen Preis von %3$s.',
                'change_down'  => 'Das ist ein Minus von %1$s (%2$s %%) gegenüber dem vorherigen Preis von %3$s.',
                'weekend'      => 'Da die internationalen Märkte am Wochenende geschlossen sind, bleiben die Preise nahe den Schlusskursen vom Freitag.',
                'h_table'      => ['Goldpreis pro Gramm heute nach Karat', 'Aktuelle Goldpreise für alle Karat in US-Dollar', 'Goldpreistabelle vom {date}'],
                'th_karat'     => 'Karat', 'th_gram' => 'Preis pro Gramm (USD)', 'th_purity' => 'Feingehalt',
                'h_units'      => ['Goldpreis nach Gewicht', 'Goldpreis pro Tola, Unze und Kilogramm', 'Was ist Gold nach Gewicht wert'],
                'th_weight'    => 'Gewicht', 'th_price' => 'Preis (USD)',
                'weights'      => ['1 Gramm (24 Karat)', '10 Gramm (24 Karat)', '1 Tola (11,66 g)', '1 Feinunze (31,10 g)', '1 Kilogramm (24 Karat)'],
                'h_ounce'      => ['Goldpreis pro Unze heute', 'Die Goldunze in den letzten 30 Tagen', 'Spanne des Goldpreises in diesem Monat'],
                'ounce_text'   => 'Die Feinunze ist die Standardeinheit für den Goldhandel an den internationalen Märkten. Heute wird sie mit {oz_money} gehandelt.',
                'range'        => 'In den letzten 30 Tagen erreichte die Unze ein Hoch von %1$s und ein Tief von %2$s.',
                'range_top'    => 'Gold notiert derzeit nahe dem oberen Ende dieser Spanne.',
                'range_bottom' => 'Gold notiert derzeit nahe dem unteren Ende dieser Spanne.',
                'range_mid'    => 'Gold notiert derzeit etwa in der Mitte dieser Spanne.',
                'h_arab'       => ['Goldpreis in arabischen Ländern heute', 'Preis für 21 Karat Gold pro Gramm in arabischen Ländern - {date}', 'Goldpreise in arabischen Währungen heute'],
                'arab_text'    => 'Auf Basis des Weltmarktpreises und der offiziellen Wechselkurse kostet ein Gramm Gold in der arabischen Welt heute:',
                'th_country'   => 'Land', 'th_21' => '21 Karat / g', 'th_24' => '24 Karat / g',
                'h_compare'    => ['Goldpreis heute im Vergleich zu gestern', 'So hat sich der Goldpreis seit dem letzten Update verändert', 'Veränderung des Goldpreises zum Vortag'],
                'th_prev'      => 'Vorher', 'th_today' => 'Heute', 'th_change' => 'Veränderung',
                'h_faq'        => ['Häufige Fragen zum Goldpreis', 'FAQ zum Goldkurs', 'Kurze Antworten zum heutigen Goldpreis'],
                'faq' => [
                    ['Wie hoch ist der Goldpreis pro Unze heute?', 'Am {weekday}, {date}, kostet eine Feinunze Gold {oz_money}.'],
                    ['Was kostet ein Gramm 24 Karat Gold heute?', 'Ein Gramm 24 Karat Gold kostet heute {p24_money}.'],
                    ['Was kostet ein Gramm 22 Karat Gold heute?', 'Ein Gramm 22 Karat Gold kostet heute {p22_money}.'],
                    ['Was kosten 21 und 18 Karat Gold pro Gramm?', '21 Karat Gold kostet heute {p21_money} pro Gramm, 18 Karat Gold {p18_money} pro Gramm.'],
                    ['Wie viele Gramm hat eine Unze Gold?', 'Eine Feinunze, die Standardeinheit für Gold, entspricht 31,1035 Gramm.'],
                    ['Sind Verarbeitungskosten in diesen Preisen enthalten?', 'Nein. Es handelt sich um Rohgoldpreise auf Basis des Weltmarktpreises, ohne Verarbeitungskosten, Mehrwertsteuer oder Händleraufschläge.'],
                ],
                'updated'      => 'Letzte Aktualisierung: {time} Uhr GMT.',
                'ounce'        => 'Unze',
                'karat'        => '%d Karat',
                'focus'        => 'Goldpreis heute',
            ],
            'img' => ['main' => 'Goldpreis pro Unze', 'gram' => '%d Karat / g', 'kilo' => '1 kg Gold (24 Karat)', 'updated' => 'Stand: %s Uhr GMT'],
            'countries' => [
                'sa' => 'Saudi-Arabien', 'ae' => 'Vereinigte Arabische Emirate', 'kw' => 'Kuwait', 'qa' => 'Katar', 'bh' => 'Bahrain', 'om' => 'Oman',
                'eg' => 'Ägypten', 'ma' => 'Marokko', 'dz' => 'Algerien', 'tn' => 'Tunesien', 'ly' => 'Libyen', 'jo' => 'Jordanien', 'lb' => 'Libanon',
                'sy' => 'Syrien', 'iq' => 'Irak', 'ps' => 'Palästina', 'ye' => 'Jemen', 'sd' => 'Sudan', 'mr' => 'Mauretanien', 'so' => 'Somalia',
                'dj' => 'Dschibuti', 'km' => 'Komoren',
            ],
        ];
    }

    /* ---------------------------------------------------------------- Italiano */

    private static function it() {
        return [
            'code'        => 'italian',
            'name'        => 'Italiano',
            'admin_label' => 'Prezzo dell’oro oggi (Italiano)',
            'headline'    => 'Prezzo dell’oro oggi',
            'category'    => 'Prezzo dell’oro oggi',
            'slug'        => 'prezzo-oro-oggi',
            'dec' => ',', 'thou' => '.', 'money' => '%s' . self::NBSP . '$',
            'weekdays'    => ['domenica', 'lunedì', 'martedì', 'mercoledì', 'giovedì', 'venerdì', 'sabato'],
            'months'      => ['gennaio', 'febbraio', 'marzo', 'aprile', 'maggio', 'giugno', 'luglio', 'agosto', 'settembre', 'ottobre', 'novembre', 'dicembre'],
            'date_format' => '{day} {month} {year}',
            'full_date'   => '{weekday} {date}',
            'defaults' => [
                'title_templates' => [
                    'Prezzo dell’oro oggi, {weekday} {date}: l’oncia a {oz_money}',
                    'Quotazione dell’oro del {date} in dollari: oncia e grammo',
                    'Prezzo dell’oro al grammo del {date}: 24 carati a {p24_money}',
                    'Quanto vale l’oro oggi, {weekday} {date}',
                    'Prezzo dell’oncia d’oro il {date}: {oz_money}',
                    'Prezzi dell’oro a 24, 22, 21 e 18 carati del {date}',
                    'Oro, quotazione di {weekday} {date}: oncia a {oz_money}',
                    'Prezzo dell’oro in dollari oggi - {date}',
                    'Quotazione aggiornata dell’oro, {weekday} {date}',
                    'Prezzo dell’oro nei paesi arabi e nel mondo il {date}',
                ],
                'desc_templates' => [
                    'Prezzo dell’oro oggi, {weekday} {date}: l’oncia quota {oz_money} e il grammo d’oro a 24 carati {p24_money}, con i prezzi a 22, 21 e 18 carati e nei paesi arabi.',
                    'Scopri la quotazione dell’oro del {date} in dollari: {oz_money} l’oncia, {p24_money} al grammo per il 24 carati, con il confronto con ieri e i prezzi nelle valute arabe.',
                    'Quotazioni dell’oro di {weekday} {date}: 24 carati a {p24_money}, 21 carati a {p21_money} e 18 carati a {p18_money} al grammo, oncia a {oz_money}.',
                ],
                'intro_templates' => [
                    'Il prezzo dell’oro si attesta oggi, {weekday} {date}, a {oz_money} per oncia troy: il grammo d’oro a 24 carati costa quindi {p24_money} e quello a 21 carati {p21_money}.',
                    'Ecco l’ultimo prezzo dell’oro per {weekday} {date}. Un’oncia d’oro viene scambiata a {oz_money}, mentre un grammo d’oro a 24 carati costa {p24_money} e uno a 18 carati {p18_money}.',
                    'Oggi, {weekday} {date}, l’oro è quotato {oz_money} l’oncia. Su questa base, il grammo costa {p24_money} a 24 carati, {p22_money} a 22 carati e {p21_money} a 21 carati.',
                    'Cerchi il prezzo dell’oro di oggi? In data {weekday} {date} un’oncia d’oro vale {oz_money}, pari a {p24_money} al grammo per l’oro puro a 24 carati.',
                    'Nell’aggiornamento di oggi, {weekday} {date}, il metallo giallo è quotato {oz_money} l’oncia, con l’oro a 24 carati a {p24_money} al grammo e quello a 18 carati a {p18_money} al grammo.',
                ],
                'tags'        => 'prezzo oro oggi, quotazione oro, prezzo oncia oro, prezzo oro al grammo',
                'footer_note' => 'I prezzi sono indicativi e calcolati sulla base della quotazione internazionale dell’oro e dei tassi di cambio ufficiali. Non includono lavorazione né tasse e possono variare leggermente da un gioielliere all’altro.',
            ],
            's' => [
                'change_flat'  => 'Il prezzo è praticamente invariato rispetto al giorno precedente.',
                'change_up'    => 'Si tratta di un rialzo di %1$s (%2$s%%) rispetto al prezzo precedente di %3$s.',
                'change_down'  => 'Si tratta di un calo di %1$s (%2$s%%) rispetto al prezzo precedente di %3$s.',
                'weekend'      => 'Con i mercati internazionali chiusi nel fine settimana, i prezzi restano vicini ai livelli di chiusura del venerdì.',
                'h_table'      => ['Prezzo dell’oro al grammo oggi per caratura', 'Quotazioni dell’oro per tutte le carature in dollari', 'Tabella dei prezzi dell’oro del {date}'],
                'th_karat'     => 'Caratura', 'th_gram' => 'Prezzo al grammo (USD)', 'th_purity' => 'Purezza',
                'h_units'      => ['Prezzo dell’oro in base al peso', 'Prezzo dell’oro per tola, oncia e chilogrammo', 'Quanto vale l’oro in base al peso'],
                'th_weight'    => 'Peso', 'th_price' => 'Prezzo (USD)',
                'weights'      => ['1 grammo (24 carati)', '10 grammi (24 carati)', '1 tola (11,66 g)', '1 oncia troy (31,10 g)', '1 chilogrammo (24 carati)'],
                'h_ounce'      => ['Prezzo dell’oncia d’oro oggi', 'L’oncia d’oro negli ultimi 30 giorni', 'Intervallo di prezzo dell’oro questo mese'],
                'ounce_text'   => 'L’oncia troy è l’unità di riferimento per la quotazione dell’oro sui mercati internazionali. Oggi è scambiata a {oz_money}.',
                'range'        => 'Negli ultimi 30 giorni l’oncia ha toccato un massimo di %1$s e un minimo di %2$s.',
                'range_top'    => 'L’oro viene attualmente scambiato vicino al massimo di questo intervallo.',
                'range_bottom' => 'L’oro viene attualmente scambiato vicino al minimo di questo intervallo.',
                'range_mid'    => 'L’oro viene attualmente scambiato a metà di questo intervallo.',
                'h_arab'       => ['Prezzo dell’oro nei paesi arabi oggi', 'Prezzo dell’oro a 21 carati al grammo nei paesi arabi - {date}', 'Quotazioni dell’oro nelle valute arabe oggi'],
                'arab_text'    => 'Sulla base della quotazione internazionale e dei tassi di cambio ufficiali, ecco quanto costa oggi un grammo d’oro nel mondo arabo:',
                'th_country'   => 'Paese', 'th_21' => '21 carati / g', 'th_24' => '24 carati / g',
                'h_compare'    => ['Prezzo dell’oro oggi rispetto a ieri', 'Come è cambiato il prezzo dell’oro dall’ultimo aggiornamento', 'Variazione del prezzo dell’oro rispetto al giorno precedente'],
                'th_prev'      => 'Precedente', 'th_today' => 'Oggi', 'th_change' => 'Variazione',
                'h_faq'        => ['Domande frequenti sul prezzo dell’oro', 'FAQ sulla quotazione dell’oro', 'Risposte rapide sul prezzo dell’oro di oggi'],
                'faq' => [
                    ['Qual è il prezzo dell’oncia d’oro oggi?', 'In data {weekday} {date}, un’oncia troy d’oro costa {oz_money}.'],
                    ['Quanto costa un grammo d’oro a 24 carati oggi?', 'Un grammo d’oro a 24 carati costa oggi {p24_money}.'],
                    ['Quanto costa un grammo d’oro a 22 carati oggi?', 'Un grammo d’oro a 22 carati costa oggi {p22_money}.'],
                    ['Quanto costa l’oro a 21 e 18 carati al grammo?', 'Oggi l’oro a 21 carati costa {p21_money} al grammo e quello a 18 carati {p18_money} al grammo.'],
                    ['Quanti grammi ci sono in un’oncia d’oro?', 'Un’oncia troy, l’unità standard per l’oro, equivale a 31,1035 grammi.'],
                    ['Questi prezzi includono la lavorazione?', 'No. Si tratta dei prezzi dell’oro grezzo basati sulla quotazione internazionale, esclusi lavorazione, IVA e ricarichi del venditore.'],
                ],
                'updated'      => 'Ultimo aggiornamento: ore {time} GMT.',
                'ounce'        => 'Oncia',
                'karat'        => '%d carati',
                'focus'        => 'prezzo oro oggi',
            ],
            'img' => ['main' => 'Prezzo dell’oncia d’oro', 'gram' => '%d carati / g', 'kilo' => '1 kg d’oro a 24 carati', 'updated' => 'Aggiornato alle %s GMT'],
            'countries' => [
                'sa' => 'Arabia Saudita', 'ae' => 'Emirati Arabi Uniti', 'kw' => 'Kuwait', 'qa' => 'Qatar', 'bh' => 'Bahrein', 'om' => 'Oman',
                'eg' => 'Egitto', 'ma' => 'Marocco', 'dz' => 'Algeria', 'tn' => 'Tunisia', 'ly' => 'Libia', 'jo' => 'Giordania', 'lb' => 'Libano',
                'sy' => 'Siria', 'iq' => 'Iraq', 'ps' => 'Palestina', 'ye' => 'Yemen', 'sd' => 'Sudan', 'mr' => 'Mauritania', 'so' => 'Somalia',
                'dj' => 'Gibuti', 'km' => 'Comore',
            ],
        ];
    }

    /* ---------------------------------------------------------------- Português */

    private static function pt() {
        return [
            'code'        => 'portuguese',
            'name'        => 'Português',
            'admin_label' => 'Preço do ouro hoje (Português)',
            'headline'    => 'Preço do ouro hoje',
            'category'    => 'Preço do ouro hoje',
            'slug'        => 'preco-ouro-hoje',
            'dec' => ',', 'thou' => '.', 'money' => 'US$' . self::NBSP . '%s',
            'weekdays'    => ['domingo', 'segunda-feira', 'terça-feira', 'quarta-feira', 'quinta-feira', 'sexta-feira', 'sábado'],
            'months'      => ['janeiro', 'fevereiro', 'março', 'abril', 'maio', 'junho', 'julho', 'agosto', 'setembro', 'outubro', 'novembro', 'dezembro'],
            'date_format' => '{day} de {month} de {year}',
            'full_date'   => '{weekday}, {date}',
            'defaults' => [
                'title_templates' => [
                    'Preço do ouro hoje, {weekday}, {date}: onça a {oz_money}',
                    'Cotação do ouro em {date} em dólares: onça e grama',
                    'Preço do grama de ouro em {date}: 24 quilates a {p24_money}',
                    'Quanto vale o ouro hoje, {weekday}, {date}',
                    'Cotação da onça de ouro em {date}: {oz_money}',
                    'Preço do ouro 24, 22, 21 e 18 quilates em {date}',
                    'Ouro: cotação de {weekday}, {date}, com a onça a {oz_money}',
                    'Preço do ouro em dólar hoje - {date}',
                    'Cotação atualizada do ouro, {weekday}, {date}',
                    'Preço do ouro nos países árabes e no mundo em {date}',
                ],
                'desc_templates' => [
                    'Preço do ouro hoje, {weekday}, {date}: a onça está cotada a {oz_money} e o grama de ouro 24 quilates a {p24_money}, com preços de 22, 21 e 18 quilates e nos países árabes.',
                    'Confira a cotação do ouro de {date} em dólares: {oz_money} a onça, {p24_money} o grama de 24 quilates, com comparação com ontem e preços em moedas árabes.',
                    'Cotação do ouro de {weekday}, {date}: 24 quilates a {p24_money}, 21 quilates a {p21_money} e 18 quilates a {p18_money} o grama, com a onça a {oz_money}.',
                ],
                'intro_templates' => [
                    'O preço do ouro está em {oz_money} por onça troy hoje, {weekday}, {date}, o que coloca o grama de ouro 24 quilates em {p24_money} e o de 21 quilates em {p21_money}.',
                    'Confira o preço mais recente do ouro para {weekday}, {date}. Uma onça de ouro é negociada a {oz_money}, enquanto o grama de ouro 24 quilates custa {p24_money} e o de 18 quilates, {p18_money}.',
                    'O ouro é negociado hoje ({date}) a {oz_money} por onça. Com base nessa cotação, o grama custa {p24_money} no ouro 24 quilates, {p22_money} no 22 quilates e {p21_money} no 21 quilates.',
                    'Procurando o preço do ouro hoje? Em {date}, uma onça de ouro vale {oz_money}, o equivalente a {p24_money} por grama de ouro puro 24 quilates.',
                    'Na atualização de hoje, {weekday}, {date}, o metal amarelo está cotado a {oz_money} por onça, com o ouro 24 quilates a {p24_money} o grama e o de 18 quilates a {p18_money} o grama.',
                ],
                'tags'        => 'preço do ouro hoje, cotação do ouro, preço da onça de ouro, preço do grama de ouro',
                'footer_note' => 'Os preços são indicativos, calculados com base na cotação internacional do ouro e nas taxas de câmbio oficiais. Não incluem mão de obra nem impostos e podem variar ligeiramente entre joalherias.',
            ],
            's' => [
                'change_flat'  => 'O preço está praticamente estável em relação ao dia anterior.',
                'change_up'    => 'Isso representa uma alta de %1$s (%2$s%%) em relação ao preço anterior de %3$s.',
                'change_down'  => 'Isso representa uma queda de %1$s (%2$s%%) em relação ao preço anterior de %3$s.',
                'weekend'      => 'Com os mercados internacionais fechados no fim de semana, os preços permanecem próximos aos níveis de fechamento de sexta-feira.',
                'h_table'      => ['Preço do grama de ouro hoje por quilate', 'Cotação do ouro para todos os quilates em dólares', 'Tabela de preços do ouro de {date}'],
                'th_karat'     => 'Quilate', 'th_gram' => 'Preço por grama (USD)', 'th_purity' => 'Pureza',
                'h_units'      => ['Preço do ouro por peso', 'Preço do ouro por tola, onça e quilo', 'Quanto vale o ouro por peso'],
                'th_weight'    => 'Peso', 'th_price' => 'Preço (USD)',
                'weights'      => ['1 grama (24 quilates)', '10 gramas (24 quilates)', '1 tola (11,66 g)', '1 onça troy (31,10 g)', '1 quilo (24 quilates)'],
                'h_ounce'      => ['Preço da onça de ouro hoje', 'A onça de ouro nos últimos 30 dias', 'Faixa de preço do ouro neste mês'],
                'ounce_text'   => 'A onça troy é a unidade padrão usada para cotar o ouro nos mercados internacionais. Hoje ela é negociada a {oz_money}.',
                'range'        => 'Nos últimos 30 dias, a onça atingiu uma máxima de %1$s e uma mínima de %2$s.',
                'range_top'    => 'O ouro é negociado atualmente perto do topo dessa faixa.',
                'range_bottom' => 'O ouro é negociado atualmente perto da parte mais baixa dessa faixa.',
                'range_mid'    => 'O ouro é negociado atualmente no meio dessa faixa.',
                'h_arab'       => ['Preço do ouro nos países árabes hoje', 'Preço do grama de ouro 21 quilates nos países árabes - {date}', 'Cotação do ouro em moedas árabes hoje'],
                'arab_text'    => 'Com base na cotação internacional e nas taxas de câmbio oficiais, veja quanto custa hoje um grama de ouro no mundo árabe:',
                'th_country'   => 'País', 'th_21' => '21 quilates / g', 'th_24' => '24 quilates / g',
                'h_compare'    => ['Preço do ouro hoje em comparação com ontem', 'Como o preço do ouro mudou desde a última atualização', 'Variação do preço do ouro em relação ao dia anterior'],
                'th_prev'      => 'Anterior', 'th_today' => 'Hoje', 'th_change' => 'Variação',
                'h_faq'        => ['Perguntas frequentes sobre o preço do ouro', 'Dúvidas comuns sobre a cotação do ouro', 'Respostas rápidas sobre o preço do ouro hoje'],
                'faq' => [
                    ['Qual é o preço da onça de ouro hoje?', 'Em {date}, uma onça troy de ouro custa {oz_money}.'],
                    ['Quanto custa o grama de ouro 24 quilates hoje?', 'O grama de ouro 24 quilates custa {p24_money} hoje.'],
                    ['Quanto custa o grama de ouro 22 quilates hoje?', 'O grama de ouro 22 quilates custa {p22_money} hoje.'],
                    ['Quanto custa o ouro 21 e 18 quilates por grama?', 'Hoje, o ouro 21 quilates custa {p21_money} por grama e o de 18 quilates, {p18_money} por grama.'],
                    ['Quantos gramas tem uma onça de ouro?', 'Uma onça troy, a unidade padrão do ouro, equivale a 31,1035 gramas.'],
                    ['Esses preços incluem mão de obra?', 'Não. São preços do ouro bruto com base na cotação internacional, sem mão de obra, impostos ou margem do vendedor.'],
                ],
                'updated'      => 'Última atualização: {time} GMT.',
                'ounce'        => 'Onça',
                'karat'        => '%d quilates',
                'focus'        => 'preço do ouro hoje',
            ],
            'img' => ['main' => 'Preço da onça de ouro', 'gram' => '%d quilates / g', 'kilo' => '1 kg de ouro 24 quilates', 'updated' => 'Atualizado às %s GMT'],
            'countries' => [
                'sa' => 'Arábia Saudita', 'ae' => 'Emirados Árabes Unidos', 'kw' => 'Kuwait', 'qa' => 'Catar', 'bh' => 'Bahrein', 'om' => 'Omã',
                'eg' => 'Egito', 'ma' => 'Marrocos', 'dz' => 'Argélia', 'tn' => 'Tunísia', 'ly' => 'Líbia', 'jo' => 'Jordânia', 'lb' => 'Líbano',
                'sy' => 'Síria', 'iq' => 'Iraque', 'ps' => 'Palestina', 'ye' => 'Iêmen', 'sd' => 'Sudão', 'mr' => 'Mauritânia', 'so' => 'Somália',
                'dj' => 'Djibuti', 'km' => 'Comores',
            ],
        ];
    }

    /* ---------------------------------------------------------------- Русский */

    private static function ru() {
        return [
            'code'        => 'russian',
            'name'        => 'Русский',
            'admin_label' => 'Цена золота сегодня (Русский)',
            'headline'    => 'Цена золота сегодня',
            'category'    => 'Цена золота сегодня',
            'slug'        => 'cena-zolota-segodnya',
            'dec' => ',', 'thou' => self::NBSP, 'money' => '%s' . self::NBSP . '$',
            'weekdays'    => ['воскресенье', 'понедельник', 'вторник', 'среда', 'четверг', 'пятница', 'суббота'],
            // родительный падеж: «31 октября»
            'months'      => ['января', 'февраля', 'марта', 'апреля', 'мая', 'июня', 'июля', 'августа', 'сентября', 'октября', 'ноября', 'декабря'],
            'date_format' => '{day} {month} {year}',
            'full_date'   => '{weekday}, {date}',
            // خط Cairo لا يدعم الحروف الروسية
            'font'        => 'PTSans',
            'defaults' => [
                'title_templates' => [
                    'Цена золота сегодня, {weekday}, {date}: унция стоит {oz_money}',
                    'Курс золота на {date} в долларах: унция и грамм',
                    'Цена грамма золота на {date}: 24 карата за {p24_money}',
                    'Сколько стоит золото сегодня, {date}',
                    'Цена унции золота на {date}: {oz_money}',
                    'Цены на золото 24, 22, 21 и 18 карат на {date}',
                    'Золото на {date}: унция торгуется по {oz_money}',
                    'Цена золота в долларах сегодня - {date}',
                    'Актуальный курс золота, {weekday}, {date}',
                    'Цены на золото в арабских странах и в мире на {date}',
                ],
                'desc_templates' => [
                    'Цена золота сегодня, {weekday}, {date}: унция стоит {oz_money}, грамм золота 24 карата — {p24_money}. Также цены на золото 22, 21 и 18 карат и в арабских странах.',
                    'Актуальный курс золота на {date} в долларах: {oz_money} за унцию, {p24_money} за грамм 24 карата, сравнение со вчерашним днём и цены в арабских валютах.',
                    'Цены на золото на {date}: 24 карата — {p24_money}, 21 карат — {p21_money}, 18 карат — {p18_money} за грамм, унция — {oz_money}.',
                ],
                'intro_templates' => [
                    'Сегодня, {weekday}, {date}, цена золота составляет {oz_money} за тройскую унцию, а значит грамм золота 24 карата стоит {p24_money}, а грамм золота 21 карат — {p21_money}.',
                    'Актуальная цена золота на {date}: унция золота торгуется по {oz_money}, грамм золота 24 карата стоит {p24_money}, а грамм 18 карат — {p18_money}.',
                    'Золото торгуется сегодня ({date}) по {oz_money} за унцию. Исходя из этого курса, грамм золота 24 карата стоит {p24_money}, 22 карата — {p22_money}, 21 карат — {p21_money}.',
                    'Ищете цену золота на сегодня? По состоянию на {date} унция золота стоит {oz_money}, что соответствует {p24_money} за грамм чистого золота 24 карата.',
                    'В сегодняшнем обзоре за {date} драгоценный металл оценивается в {oz_money} за унцию: золото 24 карата стоит {p24_money} за грамм, а 18 карат — {p18_money} за грамм.',
                ],
                'tags'        => 'цена золота сегодня, курс золота, цена унции золота, цена грамма золота',
                'footer_note' => 'Цены носят ориентировочный характер и рассчитаны на основе мировой цены золота и официальных обменных курсов. Они не включают стоимость работы и налоги и могут немного отличаться у разных ювелиров.',
            ],
            's' => [
                'change_flat'  => 'Цена практически не изменилась по сравнению с предыдущим днём.',
                'change_up'    => 'Это на %1$s (%2$s%%) выше предыдущей цены %3$s.',
                'change_down'  => 'Это на %1$s (%2$s%%) ниже предыдущей цены %3$s.',
                'weekend'      => 'Мировые рынки закрыты на выходные, поэтому цены остаются близкими к уровням закрытия пятницы.',
                'h_table'      => ['Цена грамма золота сегодня по каратам', 'Актуальные цены на золото всех карат в долларах', 'Таблица цен на золото на {date}'],
                'th_karat'     => 'Каратность', 'th_gram' => 'Цена за грамм (USD)', 'th_purity' => 'Чистота',
                'h_units'      => ['Цена золота по весу', 'Цена золота за тола, унцию и килограмм', 'Сколько стоит золото в зависимости от веса'],
                'th_weight'    => 'Вес', 'th_price' => 'Цена (USD)',
                'weights'      => ['1 грамм (24 карата)', '10 граммов (24 карата)', '1 тола (11,66 г)', '1 тройская унция (31,10 г)', '1 килограмм (24 карата)'],
                'h_ounce'      => ['Цена унции золота сегодня', 'Унция золота за последние 30 дней', 'Диапазон цен на золото в этом месяце'],
                'ounce_text'   => 'Тройская унция — стандартная единица, в которой котируется золото на мировых рынках. Сегодня она торгуется по {oz_money}.',
                'range'        => 'За последние 30 дней унция достигала максимума %1$s и минимума %2$s.',
                'range_top'    => 'Сейчас золото торгуется вблизи верхней границы этого диапазона.',
                'range_bottom' => 'Сейчас золото торгуется вблизи нижней границы этого диапазона.',
                'range_mid'    => 'Сейчас золото торгуется в середине этого диапазона.',
                'h_arab'       => ['Цена золота в арабских странах сегодня', 'Цена грамма золота 21 карат в арабских странах на {date}', 'Цены на золото в арабских валютах сегодня'],
                'arab_text'    => 'На основе мировой цены и официальных обменных курсов стоимость грамма золота в арабских странах сегодня составляет:',
                'th_country'   => 'Страна', 'th_21' => '21 карат / г', 'th_24' => '24 карата / г',
                'h_compare'    => ['Цена золота сегодня по сравнению со вчерашней', 'Как изменилась цена золота с прошлого обновления', 'Изменение цены золота по сравнению с предыдущим днём'],
                'th_prev'      => 'Предыдущая', 'th_today' => 'Сегодня', 'th_change' => 'Изменение',
                'h_faq'        => ['Частые вопросы о цене золота', 'Вопросы и ответы о курсе золота', 'Коротко о сегодняшней цене золота'],
                'faq' => [
                    ['Сколько стоит унция золота сегодня?', 'На {date} тройская унция золота стоит {oz_money}.'],
                    ['Сколько стоит грамм золота 24 карата сегодня?', 'Грамм золота 24 карата сегодня стоит {p24_money}.'],
                    ['Сколько стоит грамм золота 22 карата сегодня?', 'Грамм золота 22 карата сегодня стоит {p22_money}.'],
                    ['Сколько стоит грамм золота 21 и 18 карат?', 'Сегодня грамм золота 21 карат стоит {p21_money}, а 18 карат — {p18_money}.'],
                    ['Сколько граммов в унции золота?', 'Тройская унция — стандартная единица для золота — равна 31,1035 грамма.'],
                    ['Включает ли цена стоимость работы?', 'Нет. Это цены на золото без учёта стоимости изготовления, НДС и наценки продавца, рассчитанные на основе мировой цены.'],
                ],
                'updated'      => 'Последнее обновление: {time} GMT.',
                'ounce'        => 'Унция',
                'karat'        => '%d карат',
                'focus'        => 'цена золота сегодня',
            ],
            'img' => ['main' => 'Цена унции золота', 'gram' => '%d карат / г', 'kilo' => '1 кг золота 24 карата', 'updated' => 'Обновлено в %s GMT'],
            'countries' => [
                'sa' => 'Саудовская Аравия', 'ae' => 'ОАЭ', 'kw' => 'Кувейт', 'qa' => 'Катар', 'bh' => 'Бахрейн', 'om' => 'Оман',
                'eg' => 'Египет', 'ma' => 'Марокко', 'dz' => 'Алжир', 'tn' => 'Тунис', 'ly' => 'Ливия', 'jo' => 'Иордания', 'lb' => 'Ливан',
                'sy' => 'Сирия', 'iq' => 'Ирак', 'ps' => 'Палестина', 'ye' => 'Йемен', 'sd' => 'Судан', 'mr' => 'Мавритания', 'so' => 'Сомали',
                'dj' => 'Джибути', 'km' => 'Коморы',
            ],
        ];
    }

    /* ---------------------------------------------------------------- हिन्दी */

    private static function hi() {
        return [
            'code'        => 'hindi',
            'name'        => 'हिन्दी',
            'admin_label' => 'आज सोने का भाव (Hindi)',
            'headline'    => 'आज सोने का भाव',
            'category'    => 'आज सोने का भाव',
            'slug'        => 'sone-ka-bhav-aaj',
            'dec' => '.', 'thou' => ',', 'money' => '$%s',
            'weekdays'    => ['रविवार', 'सोमवार', 'मंगलवार', 'बुधवार', 'गुरुवार', 'शुक्रवार', 'शनिवार'],
            'months'      => ['जनवरी', 'फ़रवरी', 'मार्च', 'अप्रैल', 'मई', 'जून', 'जुलाई', 'अगस्त', 'सितंबर', 'अक्टूबर', 'नवंबर', 'दिसंबर'],
            'date_format' => '{day} {month} {year}',
            'full_date'   => '{weekday}, {date}',
            // مكتبة GD لا تدعم تشكيل حروف الديفاناغاري، لذلك تُكتب الصورة بالإنجليزية
            'image_lang'  => 'en',
            'defaults' => [
                'title_templates' => [
                    'आज सोने का भाव, {weekday} {date}: एक औंस {oz_money}',
                    'सोने का रेट आज {date}: डॉलर में औंस और ग्राम का भाव',
                    'आज 1 ग्राम सोने का भाव ({date}): 24 कैरेट {p24_money}',
                    'आज सोना कितने का है, {weekday} {date}',
                    'सोने के एक औंस की कीमत {date}: {oz_money}',
                    '24, 22, 21 और 18 कैरेट सोने का भाव {date}',
                    'सोना {weekday} {date}: एक औंस {oz_money} पर',
                    'डॉलर में आज सोने की कीमत - {date}',
                    'सोने का ताज़ा भाव, {weekday} {date}',
                    'अरब देशों और दुनिया भर में सोने का भाव {date}',
                ],
                'desc_templates' => [
                    'आज {weekday} {date} को सोने का भाव: एक औंस {oz_money} और 24 कैरेट सोना {p24_money} प्रति ग्राम। साथ में 22, 21 और 18 कैरेट तथा अरब देशों के दाम।',
                    '{date} को डॉलर में सोने का ताज़ा रेट देखें: {oz_money} प्रति औंस, 24 कैरेट {p24_money} प्रति ग्राम, कल से तुलना और अरब मुद्राओं में दाम।',
                    '{weekday} {date} को सोने के दाम: 24 कैरेट {p24_money}, 21 कैरेट {p21_money} और 18 कैरेट {p18_money} प्रति ग्राम, एक औंस {oz_money}।',
                ],
                'intro_templates' => [
                    'आज {weekday} {date} को अंतरराष्ट्रीय बाज़ार में सोने का भाव {oz_money} प्रति ट्रॉय औंस है, यानी 24 कैरेट सोना {p24_money} प्रति ग्राम और 21 कैरेट सोना {p21_money} प्रति ग्राम है।',
                    '{weekday} {date} के लिए सोने का ताज़ा भाव इस प्रकार है: एक औंस सोना {oz_money} पर कारोबार कर रहा है, जबकि 24 कैरेट सोने का एक ग्राम {p24_money} और 18 कैरेट का एक ग्राम {p18_money} का है।',
                    'आज {date} को सोना {oz_money} प्रति औंस पर है। इस भाव के आधार पर 24 कैरेट सोना {p24_money}, 22 कैरेट {p22_money} और 21 कैरेट {p21_money} प्रति ग्राम है।',
                    'क्या आप आज सोने का भाव ढूंढ रहे हैं? {weekday} {date} को एक औंस सोने की कीमत {oz_money} है, जो शुद्ध 24 कैरेट सोने के लिए {p24_money} प्रति ग्राम बैठती है।',
                    'आज {weekday} {date} के अपडेट में पीली धातु {oz_money} प्रति औंस पर है, जबकि 24 कैरेट सोना {p24_money} प्रति ग्राम और 18 कैरेट सोना {p18_money} प्रति ग्राम पर है।',
                ],
                'tags'        => 'आज सोने का भाव, सोने का रेट, सोने की कीमत, 24 कैरेट सोने का भाव',
                'footer_note' => 'ये भाव सांकेतिक हैं और अंतरराष्ट्रीय बाज़ार में सोने की कीमत तथा आधिकारिक विनिमय दरों पर आधारित हैं। इनमें मेकिंग चार्ज या टैक्स शामिल नहीं हैं और ज्वैलर के अनुसार थोड़ा अंतर हो सकता है।',
            ],
            's' => [
                'change_flat'  => 'पिछले दिन की तुलना में भाव लगभग स्थिर है।',
                'change_up'    => 'यह पिछले भाव %3$s की तुलना में %1$s (%2$s%%) अधिक है।',
                'change_down'  => 'यह पिछले भाव %3$s की तुलना में %1$s (%2$s%%) कम है।',
                'weekend'      => 'सप्ताहांत में अंतरराष्ट्रीय बाज़ार बंद रहते हैं, इसलिए भाव शुक्रवार के बंद स्तर के आसपास बने हुए हैं।',
                'h_table'      => ['आज कैरेट के अनुसार प्रति ग्राम सोने का भाव', 'डॉलर में सभी कैरेट के सोने का आज का रेट', '{date} की सोने के भाव की तालिका'],
                'th_karat'     => 'कैरेट', 'th_gram' => 'प्रति ग्राम भाव (USD)', 'th_purity' => 'शुद्धता',
                'h_units'      => ['वज़न के अनुसार सोने का भाव', 'तोला, औंस और किलो के हिसाब से सोने का भाव', 'वज़न के अनुसार सोने की कीमत कितनी है'],
                'th_weight'    => 'वज़न', 'th_price' => 'भाव (USD)',
                'weights'      => ['1 ग्राम (24 कैरेट)', '10 ग्राम (24 कैरेट)', '1 तोला (11.66 ग्राम)', '1 ट्रॉय औंस (31.10 ग्राम)', '1 किलो (24 कैरेट)'],
                'h_ounce'      => ['आज एक औंस सोने का भाव', 'पिछले 30 दिनों में सोने का औंस', 'इस महीने सोने के भाव का दायरा'],
                'ounce_text'   => 'ट्रॉय औंस अंतरराष्ट्रीय बाज़ार में सोने का भाव तय करने की मानक इकाई है। आज इसका भाव {oz_money} है।',
                'range'        => 'पिछले 30 दिनों में एक औंस का भाव अधिकतम %1$s और न्यूनतम %2$s रहा।',
                'range_top'    => 'फ़िलहाल सोना इस दायरे के ऊपरी स्तर के पास कारोबार कर रहा है।',
                'range_bottom' => 'फ़िलहाल सोना इस दायरे के निचले स्तर के पास कारोबार कर रहा है।',
                'range_mid'    => 'फ़िलहाल सोना इस दायरे के बीच में कारोबार कर रहा है।',
                'h_arab'       => ['आज अरब देशों में सोने का भाव', 'अरब देशों में 21 कैरेट सोने का प्रति ग्राम भाव - {date}', 'अरब मुद्राओं में आज सोने का रेट'],
                'arab_text'    => 'अंतरराष्ट्रीय भाव और आधिकारिक विनिमय दरों के आधार पर आज अरब देशों में एक ग्राम सोने की कीमत इस प्रकार है:',
                'th_country'   => 'देश', 'th_21' => '21 कैरेट / ग्राम', 'th_24' => '24 कैरेट / ग्राम',
                'h_compare'    => ['आज का सोने का भाव बनाम कल', 'पिछले अपडेट के बाद सोने के भाव में बदलाव', 'पिछले दिन की तुलना में सोने के भाव में बदलाव'],
                'th_prev'      => 'पिछला', 'th_today' => 'आज', 'th_change' => 'बदलाव',
                'h_faq'        => ['सोने के भाव से जुड़े सामान्य सवाल', 'सोने के रेट पर अक्सर पूछे जाने वाले सवाल', 'आज के सोने के भाव पर छोटे जवाब'],
                'faq' => [
                    ['आज एक औंस सोने का भाव क्या है?', '{weekday} {date} को एक ट्रॉय औंस सोने की कीमत {oz_money} है।'],
                    ['आज 24 कैरेट सोने का प्रति ग्राम भाव क्या है?', 'आज 24 कैरेट सोने का एक ग्राम {p24_money} का है।'],
                    ['आज 22 कैरेट सोने का प्रति ग्राम भाव क्या है?', 'आज 22 कैरेट सोने का एक ग्राम {p22_money} का है।'],
                    ['21 और 18 कैरेट सोने का प्रति ग्राम भाव क्या है?', 'आज 21 कैरेट सोना {p21_money} प्रति ग्राम और 18 कैरेट सोना {p18_money} प्रति ग्राम है।'],
                    ['एक औंस में कितने ग्राम सोना होता है?', 'एक ट्रॉय औंस, जो सोने की मानक इकाई है, 31.1035 ग्राम के बराबर होता है।'],
                    ['क्या इन भावों में मेकिंग चार्ज शामिल है?', 'नहीं। ये अंतरराष्ट्रीय भाव पर आधारित कच्चे सोने की कीमतें हैं, इनमें मेकिंग चार्ज, जीएसटी या ज्वैलर का मार्जिन शामिल नहीं है।'],
                ],
                'updated'      => 'अंतिम अपडेट: {time} GMT।',
                'ounce'        => 'औंस',
                'karat'        => '%d कैरेट',
                'focus'        => 'आज सोने का भाव',
            ],
            'img' => [],
            'countries' => [
                'sa' => 'सऊदी अरब', 'ae' => 'संयुक्त अरब अमीरात', 'kw' => 'कुवैत', 'qa' => 'क़तर', 'bh' => 'बहरीन', 'om' => 'ओमान',
                'eg' => 'मिस्र', 'ma' => 'मोरक्को', 'dz' => 'अल्जीरिया', 'tn' => 'ट्यूनीशिया', 'ly' => 'लीबिया', 'jo' => 'जॉर्डन', 'lb' => 'लेबनान',
                'sy' => 'सीरिया', 'iq' => 'इराक', 'ps' => 'फ़िलिस्तीन', 'ye' => 'यमन', 'sd' => 'सूडान', 'mr' => 'मॉरिटानिया', 'so' => 'सोमालिया',
                'dj' => 'जिबूती', 'km' => 'कोमोरोस',
            ],
        ];
    }
}
