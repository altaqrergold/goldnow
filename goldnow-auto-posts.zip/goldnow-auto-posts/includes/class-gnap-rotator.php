<?php
/**
 * اختيار القوالب (العناوين، الأوصاف، المقدمات...) دون تكرار
 *
 * كل مجموعة قوالب لها "رزمة" مخلوطة عشوائياً تُسحب منها القوالب واحداً تلو الآخر،
 * فلا يتكرر أي قالب قبل استخدام كل القوالب. عند انتهاء الرزمة يُعاد خلطها مع وضع
 * آخر القوالب المستخدمة (قوالب الأمس) في نهايتها حتى لا تتكرر في اليوم التالي مباشرة.
 */

if (!defined('ABSPATH')) {
    exit;
}

class GNAP_Rotator {

    const OPTION = 'gnap_rotation';

    /**
     * @param string $pool   اسم مجموعة القوالب
     * @param array  $items  القوالب
     * @param bool   $commit false للمعاينة (لا يُستهلك القالب)
     * @return int رقم القالب المختار
     */
    public static function pick($pool, array $items, $commit = true) {
        $count = count($items);
        if ($count < 2) {
            return 0;
        }

        $all = get_option(self::OPTION, []);
        if (!is_array($all)) {
            $all = [];
        }
        $hash = md5(implode("\n", $items));
        $state = (isset($all[$pool]['hash']) && $all[$pool]['hash'] === $hash)
            ? $all[$pool]
            : ['hash' => $hash, 'deck' => [], 'recent' => []];

        if (empty($state['deck'])) {
            $state['deck'] = self::new_deck($count, $state['recent']);
        }
        $index = (int) array_shift($state['deck']);

        if (!$commit) {
            return $index;
        }

        // نحتفظ بآخر القوالب المستخدمة بعدد مقالات يومين (الأمس + اليوم)، لأن الرزمة قد تنتهي
        // في منتصف اليوم، فتُستبعد قوالب الأمس كلها وما استُخدم اليوم حتى الآن من بداية الرزمة الجديدة
        $state['recent'][] = $index;
        $keep = min($count - 1, 2 * max(1, count(GNAP_Settings::get('countries'))));
        $state['recent'] = array_slice($state['recent'], -$keep);

        $all[$pool] = $state;
        update_option(self::OPTION, $all, false);
        return $index;
    }

    private static function new_deck($count, array $recent) {
        $recent = array_values(array_unique(array_filter($recent, function ($i) use ($count) {
            return $i >= 0 && $i < $count;
        })));
        $fresh = array_values(array_diff(range(0, $count - 1), $recent));
        shuffle($fresh);
        // القوالب المستخدمة مؤخراً في نهاية الرزمة الجديدة بنفس ترتيب استخدامها
        return array_merge($fresh, $recent);
    }

    public static function reset() {
        delete_option(self::OPTION);
    }
}
