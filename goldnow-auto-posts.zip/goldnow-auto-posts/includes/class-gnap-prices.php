<?php
/**
 * قراءة أسعار الذهب والعملات من جداول إضافة Goldx Manager
 */

if (!defined('ABSPATH')) {
    exit;
}

class GNAP_Prices {

    const CARATS = ['24k', '22k', '21k', '18k', '14k', '12k'];

    // أقصى عمر مقبول لآخر سعر ذهب (بالساعات) قبل اعتباره قديماً
    const MAX_GOLD_AGE_HOURS = 36;

    private static $refreshed = false;

    public static function dependency_error() {
        foreach (['infi_get_latest_gold_prices', 'infi_get_latest_currency_rates', 'infi_update_gold_prices'] as $fn) {
            if (!function_exists($fn)) {
                return 'إضافة Goldx Manager غير مفعلة، وهي المصدر الذي تُقرأ منه أسعار الذهب.';
            }
        }
        return '';
    }

    /**
     * لقطة كاملة للأسعار لدولة معينة، أو WP_Error
     */
    public static function snapshot($code) {
        $country = GNAP_Countries::get($code);
        if (!$country) {
            return new WP_Error('gnap_country', 'دولة غير معروفة: ' . $code);
        }
        $dependency = self::dependency_error();
        if ($dependency) {
            return new WP_Error('gnap_dependency', $dependency);
        }

        $gold = self::gold_usd();
        if (is_wp_error($gold)) {
            return $gold;
        }

        $rate = self::rate($country['currency']);
        if (is_wp_error($rate)) {
            return $rate;
        }

        $usd = $gold['prices'];
        $local = [];
        foreach ($usd as $carat => $price) {
            $local[$carat] = $price * $rate;
        }
        if ($country['pound']) {
            $usd['pound'] = $usd['21k'] * 8;
            $local['pound'] = $local['21k'] * 8;
        }

        $markup = function_exists('infi_get_markup_percentages')
            ? infi_get_markup_percentages($country['currency'])
            : ['buy_percentage' => 0, 'sell_percentage' => 0];
        $buy_sell = [];
        foreach (['24k', '22k', '21k', '18k'] as $carat) {
            $buy_sell[$carat] = [
                'buy'  => $local[$carat] * (1 + (float) $markup['buy_percentage'] / 100),
                'sell' => $local[$carat] * (1 - (float) $markup['sell_percentage'] / 100),
            ];
        }

        $extremes = self::cached('gnap_extremes', function () {
            return function_exists('infi_get_gold_price_extremes') ? infi_get_gold_price_extremes('24k_oz', 30) : null;
        });

        return [
            'country'    => $country,
            'rate'       => $rate,
            'usd'        => $usd,
            'local'      => $local,
            'buy_sell'   => $buy_sell,
            'extremes'   => $extremes,
            'updated_at' => $gold['updated_at'],
        ];
    }

    /**
     * سعر صرف الدولار مقابل العملة (عدد وحدات العملة لكل دولار)
     */
    private static function rate($currency, $rates = null) {
        if ($currency === 'USD') {
            return 1.0;
        }
        $rates = $rates === null ? infi_get_latest_currency_rates() : $rates;
        if (empty($rates[$currency])) {
            return new WP_Error('gnap_rate', 'سعر صرف ' . $currency . ' غير متوفر في جدول العملات.');
        }
        $usd_base = !empty($rates['USD']) ? (float) $rates['USD'] : 1.0;
        return (float) $rates[$currency] / $usd_base;
    }

    /**
     * أسعار جرام عيار 21 و24 بالعملة المحلية لعدة دول (لجدول الدول العربية في المقالات العامة)
     * @return array [code => ['country' => ..., '24k' => ..., '21k' => ...]]
     */
    public static function countries_table(array $codes) {
        if (self::dependency_error()) {
            return [];
        }
        $gold = self::gold_usd();
        if (is_wp_error($gold)) {
            return [];
        }
        $rates = infi_get_latest_currency_rates();
        $out = [];
        foreach ($codes as $code) {
            $country = GNAP_Countries::get($code);
            if (!$country || $country['global']) {
                continue;
            }
            $rate = self::rate($country['currency'], $rates);
            if (is_wp_error($rate)) {
                continue;
            }
            $out[$code] = [
                'country' => $country,
                '24k'     => $gold['prices']['24k'] * $rate,
                '21k'     => $gold['prices']['21k'] * $rate,
            ];
        }
        return $out;
    }

    /**
     * أحدث أسعار الذهب بالدولار لكل عيار + الأونصة، مع تحديثها إذا كانت قديمة
     */
    private static function gold_usd() {
        $parsed = self::read_gold();

        if (!$parsed || $parsed['age_hours'] > self::MAX_GOLD_AGE_HOURS) {
            if (!self::$refreshed) {
                self::$refreshed = true;
                infi_update_gold_prices();
                if (function_exists('infi_update_currency_rates')) {
                    infi_update_currency_rates();
                }
                $parsed = self::read_gold();
            }
        }

        if (!$parsed) {
            return new WP_Error('gnap_gold', 'لا توجد أسعار ذهب في قاعدة البيانات.');
        }
        if ($parsed['age_hours'] > self::MAX_GOLD_AGE_HOURS) {
            return new WP_Error('gnap_stale', sprintf('آخر سعر ذهب مسجل قديم (منذ %d ساعة)، تم تأجيل النشر.', $parsed['age_hours']));
        }
        return $parsed;
    }

    private static function read_gold() {
        $rows = infi_get_latest_gold_prices();
        if (empty($rows)) {
            return null;
        }

        $prices = [];
        $latest = 0;
        foreach ($rows as $row) {
            $prices[$row['carat']] = (float) $row['price_usd'];
            $latest = max($latest, strtotime($row['fetch_date'] . ' UTC'));
        }

        if (empty($prices['24k'])) {
            return null;
        }
        // حساب أي عيار ناقص من عيار 24
        foreach (self::CARATS as $carat) {
            if (empty($prices[$carat])) {
                $prices[$carat] = $prices['24k'] * ((int) $carat / 24);
            }
        }
        if (empty($prices['24k_oz'])) {
            $prices['24k_oz'] = $prices['24k'] * 31.1034768;
        }

        $ordered = [];
        foreach (array_merge(self::CARATS, ['24k_oz']) as $carat) {
            $ordered[$carat] = $prices[$carat];
        }

        return [
            'prices'     => $ordered,
            'updated_at' => $latest,
            'age_hours'  => (int) floor((time() - $latest) / HOUR_IN_SECONDS),
        ];
    }

    /**
     * تخزين مؤقت لساعة لنتائج الاستعلامات الثقيلة المشتركة بين كل الدول
     * (أعلى/أدنى سعر خلال 30 يوماً والتغير اليومي العالمي) بدلاً من تكرارها لكل مقال
     */
    public static function cached($key, callable $callback) {
        $value = get_transient($key);
        if ($value !== false) {
            return $value === 'none' ? null : $value;
        }
        $value = $callback();
        set_transient($key, $value === null || $value === false ? 'none' : $value, HOUR_IN_SECONDS);
        return $value ?: null;
    }

    /**
     * تنسيق السعر: بدون كسور للأرقام الكبيرة
     */
    public static function format($value, $decimals = null) {
        if ($value === null || $value === '') {
            return '-';
        }
        if ($decimals === null) {
            $decimals = abs($value) >= 1000 ? 0 : 2;
        }
        return number_format((float) $value, $decimals, '.', ',');
    }

    public static function carat_label($carat) {
        if ($carat === '24k_oz') {
            return 'الأونصة';
        }
        if ($carat === 'pound') {
            return '';
        }
        return 'عيار ' . (int) $carat;
    }
}
