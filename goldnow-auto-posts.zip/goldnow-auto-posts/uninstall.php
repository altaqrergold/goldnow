<?php
/**
 * حذف إعدادات الإضافة عند إزالتها (المقالات المنشورة تبقى كما هي)
 */

if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

delete_option('gnap_settings');
delete_option('gnap_log');
delete_option('gnap_status');
delete_option('gnap_next_at');
delete_option('gnap_last_tick');
delete_option('gnap_rotation');
delete_transient('gnap_tick_lock');
wp_clear_scheduled_hook('gnap_tick');
