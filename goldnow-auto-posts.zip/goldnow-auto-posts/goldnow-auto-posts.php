<?php
/**
 * Plugin Name: GoldNow Auto Posts - النشر التلقائي لأسعار الذهب
 * Description: نشر مقال يومي تلقائي لأسعار الذهب لكل دولة عربية (عنوان، وصف، صورة بارزة، ومقال كامل) اعتماداً على بيانات إضافة Goldx Manager.
 * Version: 1.2.0
 * Author: GoldNow
 * Text Domain: goldnow-auto-posts
 * Requires PHP: 7.4
 * Requires at least: 5.8
 */

if (!defined('ABSPATH')) {
    exit;
}

define('GNAP_VERSION', '1.2.0');
define('GNAP_FILE', __FILE__);
define('GNAP_PATH', plugin_dir_path(__FILE__));
define('GNAP_URL', plugin_dir_url(__FILE__));

require_once GNAP_PATH . 'includes/class-gnap-languages.php';
require_once GNAP_PATH . 'includes/class-gnap-countries.php';
require_once GNAP_PATH . 'includes/class-gnap-settings.php';
require_once GNAP_PATH . 'includes/class-gnap-log.php';
require_once GNAP_PATH . 'includes/class-gnap-arabic.php';
require_once GNAP_PATH . 'includes/class-gnap-prices.php';
require_once GNAP_PATH . 'includes/class-gnap-rotator.php';
require_once GNAP_PATH . 'includes/class-gnap-content.php';
require_once GNAP_PATH . 'includes/class-gnap-image.php';
require_once GNAP_PATH . 'includes/class-gnap-publisher.php';
require_once GNAP_PATH . 'includes/class-gnap-scheduler.php';
require_once GNAP_PATH . 'includes/class-gnap-frontend.php';

if (is_admin()) {
    require_once GNAP_PATH . 'includes/class-gnap-admin.php';
    GNAP_Admin::init();
}

GNAP_Scheduler::init();
GNAP_Frontend::init();

register_activation_hook(__FILE__, ['GNAP_Scheduler', 'activate']);
register_deactivation_hook(__FILE__, ['GNAP_Scheduler', 'deactivate']);
