<?php
function infi_gold_manager_pages_page() {


    // استرجاع إعدادات البرنامج
    $settings = get_option('infi_gold_manager_settings', []);
    
    // التحقق من قيمة user_country_detection وإذا لم تكن موجودة تعيين قيمة افتراضية
    $user_country_detection = isset($settings['user_country_detection']) ? $settings['user_country_detection'] : 'cloudflare';
    // التحقق من قيمة default_country_code وإذا لم تكن موجودة تعيين قيمة افتراضية
    $default_country_code = isset($settings['default_country_code']) ? $settings['default_country_code'] : 'sa';
    
    // تعريف مصفوفة البلدان مع العملات
    $country_to_currency = [
        'eg' => ['currency' => 'EGP', 'name' => 'مصر'],
        'sa' => ['currency' => 'SAR', 'name' => 'السعودية'],
        'ae' => ['currency' => 'AED', 'name' => 'الإمارات'],
        'kw' => ['currency' => 'KWD', 'name' => 'الكويت'],
        'qa' => ['currency' => 'QAR', 'name' => 'قطر'],
        'bh' => ['currency' => 'BHD', 'name' => 'البحرين'],
        'om' => ['currency' => 'OMR', 'name' => 'عمان'],
        'ma' => ['currency' => 'MAD', 'name' => 'المغرب'],
        'us' => ['currency' => 'USD', 'name' => 'الولايات المتحدة'],
        'gb' => ['currency' => 'GBP', 'name' => 'بريطانيا'],
        'eu' => ['currency' => 'usd', 'name' => 'أوروبا']
    ];
    
    // استخراج اسم الدولة بناءً على default_country_code
    $country_name = isset($country_to_currency[$default_country_code]) ? $country_to_currency[$default_country_code]['name'] : 'دولة غير معروفة';
    
    // طباعة اسم الدولة
  





   // في الكود الذي يخص إنشاء الصفحة (الذي يتم تنفيذه عند إرسال النموذج)
if (isset($_POST['create_page']) && isset($_POST['page_title']) && check_admin_referer('infi_gold_pages_nonce')) {
    $original_title = sanitize_text_field($_POST['original_title']);
    $page_title = sanitize_text_field($_POST['page_title']);
    $page_content = isset($_POST['page_content']) ? wp_kses_post($_POST['page_content']) : '';
    $gold_price_shortcode = isset($_POST['gold_price_shortcode']) ? sanitize_text_field($_POST['gold_price_shortcode']) : '';

    // إنشاء صفحة جديدة
    $page_id = wp_insert_post(array(
        'post_title'    => $page_title,
        'post_content'  => $page_content,
        'post_status'   => 'publish',
        'post_type'     => 'page',
    ));

    if ($page_id) {
        // حفظ الشورت كود في الميتا الخاص بالصفحة
        update_post_meta($page_id, 'gold_price_shortcode', $gold_price_shortcode);
// تحديد القالب للصفحة
if (isset($_POST['page_template'])) {
    update_post_meta($page_id, '_wp_page_template', sanitize_text_field($_POST['page_template']));
}
        // حفظ الارتباط بين العنوان الأصلي والصفحة
        $pages_links = get_option('infi_gold_pages_links', array());
        $pages_links[$original_title] = $page_id;
        update_option('infi_gold_pages_links', $pages_links);


        echo '<div class="notice notice-success is-dismissible"><p>تم إنشاء الصفحة بنجاح. <a href="' . get_permalink($page_id) . '" target="_blank">عرض الصفحة</a></p></div>';
    } else {
        echo '<div class="notice notice-error is-dismissible"><p>حدث خطأ أثناء إنشاء الصفحة.</p></div>';
    }
}

    
    // التحقق مما إذا تم الضغط على زر تحديث ارتباط الصفحة
    if (isset($_POST['update_page_link']) && isset($_POST['page_title']) && isset($_POST['page_id']) && check_admin_referer('infi_gold_pages_nonce')) {
        $page_title = sanitize_text_field($_POST['page_title']);
        $page_id = intval($_POST['page_id']);
        
        if ($page_id > 0) {
            // تحديث رابط الصفحة في الإعدادات
            $pages_links = get_option('infi_gold_pages_links', array());
            $pages_links[$page_title] = $page_id;
            update_option('infi_gold_pages_links', $pages_links);
            
            echo '<div class="notice notice-success is-dismissible"><p>تم تحديث ارتباط الصفحة بنجاح.</p></div>';
        } else {
            echo '<div class="notice notice-error is-dismissible"><p>الرجاء اختيار صفحة صالحة.</p></div>';
        }
    }
    
    // الحصول على روابط الصفحات المحفوظة
    $pages_links = get_option('infi_gold_pages_links', array());
    
    // قائمة بعناوين صفحات منتجات الذهب
    $gold_page_titles = array(
        'جنيه الذهب 8 جرام عيار 21',
        'جنيه الذهب 8 جرام عيار 22',
        'جنيه الذهب 8 جرام عيار 24',
        'سبيكة ذهب 1 جرام',
        'سبيكة الذهب 2.5 جرام',
        'سبيكة الذهب 5 جرام',
        'سبيكة الذهب 8 جرام',
        'سبيكة الذهب 10 جرام',
        'سبيكة الذهب 20 جرام',
        'سبيكة الذهب 50 جرام',
        'سبيكة الذهب 100 جرام',
        'سبيكة الذهب 500 جرام',
        'سبيكة الذهب 1000 جرام',
        'سبيكة الذهب أونصة',
        'سبيكة الذهب نصف أونصة',
        'عيار 22',
        'عيار 21',
        'عيار 18',
        'سعر جرام الذهب عيار 24',
        'سعر جرام الذهب عيار 22',
        'سعر جرام الذهب عيار 21',
        'سعر جرام الذهب عيار 18',
        'سعر جرام الذهب عيار 14',
        'سعر أونصة الذهب',
        'دولار أمريكي',
        'يورو',
        'جنيه إسترليني',
        'فرنك سويسري',
        'ين ياباني',
    );
    
    
    // الحصول على قائمة جميع الصفحات
    $all_pages = get_pages();
    ?>
    <div class="wrap">
        <h1><?php echo esc_html__('صفحات الإضافة', 'infi-gold-manager'); ?></h1>
        
        <div class="card" style="max-width: 1000px; margin-top: 20px; padding: 20px; background: #fff; border: 1px solid #ccd0d4; border-radius: 4px; box-shadow: 0 1px 1px rgba(0,0,0,.04);">
            <h2><?php echo esc_html__('إدارة صفحات منتجات الذهب', 'infi-gold-manager'); ?></h2>
            <p><?php echo esc_html__('من هنا يمكنك ربط أو إنشاء صفحات لمنتجات الذهب المختلفة.', 'infi-gold-manager'); ?></p>
            
            <table class="widefat" style="margin-top: 20px;">
                <thead>
                    <tr>
                        <th><?php echo esc_html__('عنوان المنتج', 'infi-gold-manager'); ?></th>
                        <th><?php echo esc_html__('الصفحة في الموقع', 'infi-gold-manager'); ?></th>
                        <th><?php echo esc_html__('إجراءات', 'infi-gold-manager'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($gold_page_titles as $title): ?>
                        <tr>
                            <td><?php echo esc_html($title); ?></td>
                            <td>
                                <form method="post" action="">
                                    <?php wp_nonce_field('infi_gold_pages_nonce'); ?>
                                    <input type="hidden" name="page_title" value="<?php echo esc_attr($title); ?>">
                                    
                                    <select name="page_id" style="width: 100%;">
                                        <option value=""><?php echo esc_html__('-- اختر صفحة --', 'infi-gold-manager'); ?></option>
                                        <?php 
                                        $found_exact_match = false;
                                        $linked_page_id = isset($pages_links[$title]) ? $pages_links[$title] : 0;
                                        
                                        foreach ($all_pages as $page): 
                                            $selected = '';
                                            
                                            // تحديد الصفحة إذا كانت مرتبطة مسبقاً
                                            if ($linked_page_id === $page->ID) {
                                                $selected = 'selected="selected"';
                                            }
                                            // أو إذا كان العنوان مطابقاً تماماً ولم يتم العثور على تطابق دقيق سابقاً
                                            elseif ($page->post_title === $title && !$found_exact_match && !$linked_page_id) {
                                                $selected = 'selected="selected"';
                                                $found_exact_match = true;
                                            }
                                        ?>
                                            <option value="<?php echo esc_attr($page->ID); ?>" <?php echo $selected; ?>>
                                                <?php echo esc_html($page->post_title); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                    
                                    <button type="submit" name="update_page_link" class="button button-secondary" style="margin-top: 5px;">
                                        <?php echo esc_html__('تحديث الارتباط', 'infi-gold-manager'); ?>
                                    </button>
                                </form>
                            </td>
                            <td>
                                <?php if (isset($pages_links[$title]) && $pages_links[$title] > 0): ?>
                                    <a href="<?php echo get_permalink($pages_links[$title]); ?>" target="_blank" class="button button-secondary">
                                        <?php echo esc_html__('عرض الصفحة', 'infi-gold-manager'); ?>
                                    </a>
                                    <a href="<?php echo get_edit_post_link($pages_links[$title]); ?>" target="_blank" class="button button-secondary">
                                        <?php echo esc_html__('تعديل الصفحة', 'infi-gold-manager'); ?>
                                    </a>
                                <?php else: ?>
                                    <button type="button" class="button button-primary create-page-button" data-title="<?php echo esc_attr($title); ?>">
                                        <?php echo esc_html__('إنشاء صفحة', 'infi-gold-manager'); ?>
                                    </button>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
    
    <div id="create-page-modal" class="create-page-modal" style="display: none;">
    <div class="create-page-modal-content" style="background-color: #fff; padding: 20px; border-radius: 5px; box-shadow: 0 2px 10px rgba(0,0,0,0.2); max-width: 600px; margin: 50px auto; position: relative;">
        <span class="close-modal" style="position: absolute; top: 10px; right: 10px; font-size: 20px; cursor: pointer;">&times;</span>
        <h2><?php echo esc_html__('إنشاء صفحة جديدة', 'infi-gold-manager'); ?></h2>

        <form method="post" action="">
            <?php wp_nonce_field('infi_gold_pages_nonce'); ?>
            <input type="hidden" name="original_title" id="modal-original-title" value="">
            
            <!-- حقل عنوان الصفحة -->
            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="page_title"><?php echo esc_html__('عنوان الصفحة', 'infi-gold-manager'); ?></label>
                    </th>
                    <td>
                        <input type="text" name="page_title" id="modal-page-title" style="width: 100%;">
                        <p class="description"><?php echo esc_html__('يمكنك تعديل عنوان الصفحة قبل إنشائها', 'infi-gold-manager'); ?></p>
                    </td>
                </tr>
                <!-- حقل محتوى الصفحة -->
                <tr>
                    <th scope="row">
                        <label for="page_content"><?php echo esc_html__('محتوى الصفحة', 'infi-gold-manager'); ?></label>
                    </th>
                    <td>
                        <?php 
                        $content = '[infi_gold_price_display carat="24k" show_calculator="yes"]';
                        wp_editor($content, 'page_content', array('textarea_rows' => 10));
                        ?>
                        <p class="description"><?php echo esc_html__('يمكنك تعديل محتوى الصفحة وإضافة الشورت كود المناسب.', 'infi-gold-manager'); ?></p>
                    </td>
                </tr>
                <!-- حقل الشورت كود -->
                <tr>
                    <th scope="row">
                        <label for="gold_price_shortcode"><?php echo esc_html__('شورت كود سعر الذهب', 'infi-gold-manager'); ?></label>
                    </th>
                    <td>
                        <input type="text" name="gold_price_shortcode" id="modal-gold-price-shortcode" style="width: 100%;">
                        <p class="description"><?php echo esc_html__('سيتم إدراج الشورت كود هنا بناءً على المنتج المختار.', 'infi-gold-manager'); ?></p>
                    </td>
                </tr>
                <!-- حقل القالب -->
                <input type="hidden" name="page_template" id="modal-page-template" value="">
            </table>

            <p class="submit">
                <input type="submit" name="create_page" class="button button-primary" value="<?php echo esc_attr__('إنشاء الصفحة', 'infi-gold-manager'); ?>">
            </p>
        </form>
    </div>
</div>


    
    <style>
        .create-page-modal {
            position: fixed;
            z-index: 9999;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0,0,0,0.4);
        }
    </style>
    
    <script>
    jQuery(document).ready(function($) {
        // فتح النافذة المنبثقة عند النقر على زر إنشاء صفحة
        $('.create-page-button').on('click', function() {
    // الحصول على العنوان من البيانات المخزنة في الزر الذي تم النقر عليه
    var title = $(this).data('title');

    // تعيين العنوان الأصلي في الحقل المخفي (لإعادة استخدامه عند الحفظ)
    $('#modal-original-title').val(title);

    // تعيين العنوان القابل للتعديل في الحقل الخاص بعنوان الصفحة
    $('#modal-page-title').val("سعر "+title+" ب<?php echo $country_name; ?>");

    // تخصيص الشورت كود بناءً على العنوان
    var shortcode = '';
    if (title.includes('جنيه الذهب')) {
        if (title.includes('عيار 21')) {
            shortcode = '[gold_currency_display type="gold_21k" currency="SAR"]';
        } else if (title.includes('عيار 22')) {
            shortcode = '[gold_currency_display type="gold_22k" currency="SAR"]';
        } else if (title.includes('عيار 24')) {
            shortcode = '[gold_currency_display type="gold_24k" currency="SAR"]';
        }
    }

    // تحديث حقل الشورت كود في النافذة المنبثقة
    $('#modal-gold-price-shortcode').val(shortcode);

    // تعيين القالب المناسب (Gold-Price-Display-Template.php)
    $('#modal-page-template').val('Gold-Price-Display-Template.php');

    // عرض النافذة المنبثقة
    $('#create-page-modal').show();
});


        
        // إغلاق النافذة المنبثقة
        $('.close-modal').on('click', function() {
            $('#create-page-modal').hide();
        });
        
        // إغلاق النافذة المنبثقة عند النقر خارجها
        $(window).on('click', function(event) {
            if ($(event.target).is('#create-page-modal')) {
                $('#create-page-modal').hide();
            }
        });
    });
    </script>
    <?php
}