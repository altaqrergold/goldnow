<?php
if (!defined('ABSPATH')) {
    exit;
}



// Registrar todos los shortcodes
function infi_register_shortcodes() {
    add_shortcode('infi_currency_rate', 'infi_currency_rate_shortcode');
    add_shortcode('infi_gold_price_usd', 'infi_gold_price_usd_shortcode');
    add_shortcode('infi_gold_price', 'infi_gold_price_shortcode');
    add_shortcode('infi_gold_table', 'infi_gold_table_shortcode');
    add_shortcode('infi_gold_chart', 'infi_gold_chart_shortcode');
    add_shortcode('infi_gold_extremes', 'infi_gold_extremes_shortcode');
    add_shortcode('infi_gold_change', 'infi_gold_change_shortcode');
    add_shortcode('infi_gold_cards', 'infi_gold_cards_shortcode');
    add_shortcode('infi_gold_info_boxes', 'infi_gold_info_boxes_shortcode');
    add_shortcode('infi_gold_price_cards', 'infi_gold_price_cards_shortcode');
    add_shortcode('infi_gold_table_advanced', 'infi_gold_table_advanced_shortcode');
    add_shortcode('infi_gold_calculator', 'infi_gold_calculator_shortcode');
    add_shortcode('infi_gold_weight_table', 'infi_gold_weight_table_shortcode');
    add_shortcode('infi_gold_price_display', 'infi_gold_price_display_shortcode');
    add_shortcode('infi_currency_display', 'infi_currency_display_shortcode');
    add_shortcode('display_countries', 'countries_display_shortcode');
    add_shortcode('infi_debug_data', 'infi_debug_data_shortcode');
}

function infi_gold_price_usd_shortcode($atts) {
    try {
        $atts = shortcode_atts([
            'carat' => '24k',
            'date' => null,
            'decimals' => 2
        ], $atts, 'infi_gold_price_usd');
        
        $carat = sanitize_text_field($atts['carat']);
        $decimals = intval($atts['decimals']);
        
        infi_gold_log("Gold price in usd requested for carat: $carat", 'debug');
        
        $cache_key = 'infi_gold_price_' . $carat;
        if ($atts['date'] !== null) {
            $cache_key .= '_' . $atts['date'];
        }
        
        $gold_data = infi_get_cached_data($cache_key, function() use ($carat, $atts) {
            global $wpdb;
            $table_name = INFI_MAIN_PREFIX  . 'infi_gold_prices';
            
            if ($atts['date'] !== null) {
                $query = $wpdb->prepare(
                    "SELECT price_usd FROM $table_name 
                    WHERE carat = %s AND gold_date = %s 
                    ORDER BY fetch_date DESC LIMIT 1",
                    $carat,
                    $atts['date']
                );
            } else {
                $query = $wpdb->prepare(
                    "SELECT price_usd FROM $table_name 
                    WHERE carat = %s 
                    ORDER BY gold_date DESC, fetch_date DESC LIMIT 1",
                    $carat
                );
            }
            
            $price = $wpdb->get_var($query);
            infi_gold_log("Raw SQL result for gold price: " . print_r($price, true), 'debug');
            
            return $price ? floatval($price) : null;
        });
        
        if ($gold_data === null) {
            infi_gold_log("No gold price found for carat: $carat", 'warning');
            return 'N/A';
        }
        
        infi_gold_log("Returning gold price in usd: $gold_data", 'debug');
        return number_format($gold_data, $decimals);
        
    } catch (Exception $e) {
        infi_gold_log('Error in gold_price_usd shortcode: ' . $e->getMessage(), 'error');
        return 'Error';
    }
}

function null_infi_gold_price_usd_shortcode($atts) {
    try {
        $atts = shortcode_atts([
            'carat' => '24k',
            'date' => null,
            'decimals' => 2
        ], $atts, 'infi_gold_price_usd');
        
        $carat = sanitize_text_field($atts['carat']);
        $decimals = intval($atts['decimals']);
        
        $cache_key = 'infi_gold_price_' . $carat;
        if ($atts['date'] !== null) {
            $cache_key .= '_' . $atts['date'];
        }
        
        $price = infi_get_cached_data($cache_key, function() use ($carat, $atts) {
            if ($atts['date'] !== null) {
                return null;
            } else {
                $prices = infi_get_latest_gold_prices($carat);
                if (!empty($prices) && isset($prices[0]['price_usd'])) {
                    return floatval($prices[0]['price_usd']);
                }
                return null;
            }
        });
        
        if ($price === null) {
            return 'N/A';
        }
        
        return number_format($price, $decimals);
        
    } catch (Exception $e) {
        infi_gold_log('Error in gold_price_usd shortcode: ' . $e->getMessage(), 'error');
        return 'Error';
    }
}

function infi_gold_price_shortcode($atts) {
    try {
        $settings = get_option('infi_gold_manager_settings', []);
        $default_currency = isset($settings['default_currency']) ? $settings['default_currency'] : 'USD';
        
        $atts = shortcode_atts([
            'carat' => '24k',
            'currency' => $default_currency,
            'date' => null,
            'decimals' => 2
        ], $atts, 'infi_gold_price');
        
        $carat = sanitize_text_field($atts['carat']);
        $currency = strtoupper(sanitize_text_field($atts['currency']));
        $decimals = intval($atts['decimals']);
        $date = $atts['date'];
        
        global $wpdb;
        $table_name = INFI_MAIN_PREFIX . 'infi_gold_prices';
        
        if ($date !== null) {
            $gold_query = $wpdb->prepare(
                "SELECT price_usd FROM $table_name 
                WHERE carat = %s AND gold_date = %s 
                ORDER BY fetch_date DESC LIMIT 1",
                $carat,
                $date
            );
        } else {
            $gold_query = $wpdb->prepare(
                "SELECT price_usd FROM $table_name 
                WHERE carat = %s 
                ORDER BY gold_date DESC, fetch_date DESC LIMIT 1",
                $carat
            );
        }
        
        // قيمة price_usd هي فعلياً بالدولار
        $gold_price_usd = $wpdb->get_var($gold_query);
        
        if ($gold_price_usd === null) {
            infi_gold_log("No gold price found for carat: $carat", 'warning');
            return 'N/A';
        }
        
        $gold_price_usd = floatval($gold_price_usd);
        
        // إذا كانت العملة المطلوبة هي الدولار، نعيد السعر مباشرة
        if ($currency === 'USD') {
            return number_format($gold_price_usd, $decimals);
        }
        
        // للعملات الأخرى، نحتاج إلى التحويل من الدولار
        $currency_rates = infi_get_latest_currency_rates();
        
        if (empty($currency_rates) || !isset($currency_rates[$currency])) {
            infi_gold_log("Currency rate not found for $currency", 'warning');
            return 'N/A';
        }
        
        if (!isset($currency_rates['USD'])) {
            // إذا لم نجد معدل تحويل الدولار، نفترض قيمة
            $usd_rate = 1.0;
        } else {
            $usd_rate = $currency_rates['USD'];
        }
        
        // نسبة التحويل من الدولار إلى العملة المطلوبة
        $conversion_rate = $currency_rates[$currency] / $usd_rate;
        
        // تحويل من الدولار إلى العملة المطلوبة
        $price = $gold_price_usd * $conversion_rate;
        
        return number_format($price, $decimals);
        
    } catch (Exception $e) {
        infi_gold_log('Error in gold_price shortcode: ' . $e->getMessage(), 'error');
        return 'Error';
    }
}
function infi_currency_rate_shortcode($atts) {
    try {
        $settings = get_option('infi_gold_manager_settings', []);
        $default_currency = isset($settings['default_currency']) ? $settings['default_currency'] : 'usd';
        
        $atts = shortcode_atts([
            'currency' => $default_currency,
            'date' => null,
            'decimals' => 2
        ], $atts, 'infi_currency_rate');
        
        $currency = strtoupper(sanitize_text_field($atts['currency']));
        $decimals = intval($atts['decimals']);
        
        infi_gold_log("Currency rate requested for: $currency", 'debug');
        
        if ($currency === 'usd') {
            return '1';
        }
        
        $cache_key = 'infi_gold_currency_' . $currency;
        if ($atts['date'] !== null) {
            $cache_key .= '_' . $atts['date'];
        }
        
        $rate = infi_get_cached_data($cache_key, function() use ($currency, $atts) {
            if ($atts['date'] !== null) {
                return null;
            } else {
                $result = infi_get_latest_currency_rates($currency);
                infi_gold_log("Currency rate result for $currency: " . print_r($result, true), 'debug');
                
                if (!empty($result) && isset($result['rate_to_usd'])) {
                    return floatval($result['rate_to_usd']);
                }
                
                $rates = infi_get_latest_currency_rates();
                infi_gold_log("All currency rates: " . print_r($rates, true), 'debug');
                
                return isset($rates[$currency]) ? $rates[$currency] : null;
            }
        });
        
        if ($rate === null || $rate <= 0) {
            infi_gold_log("No valid rate found for currency: $currency", 'warning');
            return 'N/A';
        }
        
        return number_format($rate, $decimals);
        
    } catch (Exception $e) {
        infi_gold_log('Error in currency_rate shortcode: ' . $e->getMessage(), 'error');
        return 'Error';
    }
}

function infi_gold_table_shortcode($atts) {
    try {
        global $carat_labels;
        $settings = get_option('infi_gold_manager_settings', []);
        $default_currency = isset($settings['default_currency']) ? $settings['default_currency'] : 'USD';
        
        $atts = shortcode_atts([
            'currency' => $default_currency,
            'show_buy_sell' => 'yes',
            'show_change' => 'yes',
            'decimals' => 2
        ], $atts, 'infi_gold_table');
        
        $currency = strtoupper(sanitize_text_field($atts['currency']));
        $show_buy_sell = $atts['show_buy_sell'] === 'yes';
        $show_change = $atts['show_change'] === 'yes';
        $decimals = intval($atts['decimals']);
        
        $carats = ['24k_oz', '24k', '22k', '21k', '18k', '14k', '12k'];
        $prices = [];
        
        foreach ($carats as $carat) {
            $price = do_shortcode('[infi_gold_price carat="' . esc_attr($carat) . '" currency="' . esc_attr($currency) . '" decimals="' . esc_attr($decimals) . '"]');
            
            if ($price !== 'N/A' && $price !== 'Error') {
                $prices[$carat] = $price;
                
                if ($show_change) {
                    $change = do_shortcode('[infi_gold_change carat="' . esc_attr($carat) . '" period="daily" show_percentage="yes" show_value="no" currency="' . esc_attr($currency) . '" decimals="2"]');
                    $prices[$carat . '_change'] = $change;
                }
                
                if ($show_buy_sell) {
                    $markup = infi_get_markup_percentages($currency);
                    $buy_percentage = $markup['buy_percentage'];
                    $sell_percentage = $markup['sell_percentage'];
                    
                    $price_value = floatval(str_replace(',', '', $price));
                    $buy_price = $price_value * (1 + ($buy_percentage / 100));
                    $sell_price = $price_value * (1 - ($sell_percentage / 100));
                    
                    $prices[$carat . '_buy'] = number_format($buy_price, $decimals);
                    $prices[$carat . '_sell'] = number_format($sell_price, $decimals);
                }
            } else {
                $prices[$carat] = 'N/A';
            }
        }
        
        $output = '<div class="infi-gold-table-wrapper">';
        $output .= '<table class="infi-gold-table">';
        
        $output .= '<thead><tr>';
        $output .= '<th>' . __('Gold Carat', 'infi-gold-manager') . '</th>';
        
        if ($show_buy_sell) {
            $output .= '<th>' . __('Buy Price', 'infi-gold-manager') . ' (' . $currency . ')</th>';
            $output .= '<th>' . __('Sell Price', 'infi-gold-manager') . ' (' . $currency . ')</th>';
        } else {
            $output .= '<th>' . __('Price', 'infi-gold-manager') . ' (' . $currency . ')</th>';
        }
        
        if ($show_change) {
            $output .= '<th>' . __('24h Change', 'infi-gold-manager') . '</th>';
        }
        
        $output .= '</tr></thead>';
        $output .= '<tbody>';
        
        foreach ($carats as $carat) {
            if (!isset($prices[$carat]) || $prices[$carat] === 'N/A') {
                continue;
            }
            
            $output .= '<tr>';
            $output .= '<td>' . $carat_labels[$carat] . '</td>';
            
            if ($show_buy_sell) {
                $output .= '<td>' . $prices[$carat . '_buy'] . '</td>';
                $output .= '<td>' . $prices[$carat . '_sell'] . '</td>';
            } else {
                $output .= '<td>' . $prices[$carat] . '</td>';
            }
            
            if ($show_change) {
                $change_class = '';
                if (isset($prices[$carat . '_change'])) {
                    $change_value = $prices[$carat . '_change'];
                    if (strpos($change_value, '+') === 0) {
                        $change_class = 'positive-change';
                    } elseif (strpos($change_value, '-') === 0) {
                        $change_class = 'negative-change';
                    }
                } else {
                    $change_value = 'N/A';
                }
                
                $output .= '<td class="' . $change_class . '">' . $change_value . '</td>';
            }
            
            $output .= '</tr>';
        }
        
        $output .= '</tbody>';
        $output .= '</table>';
        
        $output .= '<div class="infi-gold-table-info">';
        
        global $wpdb;
        $table_name = INFI_MAIN_PREFIX  . 'infi_gold_prices';
        $last_update = $wpdb->get_var("SELECT MAX(fetch_date) FROM $table_name");
        
        if ($last_update) {
            $output .= '<p class="infi-gold-last-update">';
            $output .= __('Last Updated:', 'infi-gold-manager') . ' ';
            $output .= date_i18n(get_option('date_format') . ' ' . get_option('time_format'), strtotime($last_update));
            $output .= '</p>';
        }
        
        $output .= '</div>';
        $output .= '</div>';
        
        $output .= '<style>
            .infi-gold-table-wrapper { margin: 20px 0; }
            .infi-gold-table { width: 100%; border-collapse: collapse; }
            .infi-gold-table th, .infi-gold-table td { padding: 10px; text-align: center; border: 1px solid #ddd; }
            .infi-gold-table th { background-color: #f5f5f5; font-weight: bold; }
            .infi-gold-table tr:nth-child(even) { background-color: #f9f9f9; }
            .infi-gold-table tr:hover { background-color: #f0f0f0; }
            .infi-gold-table .positive-change { color: green; }
            .infi-gold-table .negative-change { color: red; }
            .infi-gold-table-info { font-size: 0.9em; color: #777; text-align: right; margin-top: 10px; }
        </style>';
        
        return $output;
        
    } catch (Exception $e) {
        infi_gold_log('Error in gold_table shortcode: ' . $e->getMessage(), 'error');
        return '<p>Error loading gold prices table.</p>';
    }
}





function infi_gold_chart_shortcode($atts) {
    try {
        $settings = get_option('infi_gold_manager_settings', []);
        $default_currency = isset($settings['default_currency']) ? $settings['default_currency'] : 'usd';
        
        $atts = shortcode_atts([
            'carat' => '24k',
            'currency' => $default_currency,
            'period' => 'month',
            'width' => '100%',
            'height' => '405',
            'title' => 'تغير سعر الذهب',
            'mobile_height' => '300',
            'show_points' => 'yes' // تم ضبط القيمة الافتراضية على 'yes' لعرض النقاط
        ], $atts, 'infi_gold_chart');
        
        $carat = sanitize_text_field($atts['carat']);
        $currency = strtoupper(sanitize_text_field($atts['currency']));
        $title = sanitize_text_field($atts['title']);
        $width = sanitize_text_field($atts['width']);
        $height = sanitize_text_field($atts['height']);
        $mobile_height = sanitize_text_field($atts['mobile_height']);
        $show_points = $atts['show_points'] === 'yes';
        
        // جلب قيمة days من URL
        $days = isset($_GET['days']) ? intval($_GET['days']) : 30;
        
        // معرف فريد للرسم البياني
        $chart_id = 'goldchart-' . uniqid();
        
        // تعيين التواريخ بناءً على days
        $end_date = date('Y-m-d');
        $start_date = date('Y-m-d', strtotime("-$days days"));
        
        $period_map = [
            '1' => '24h',
            '7' => 'week',
            '30' => 'month',
            '90' => '3months',
            '180' => '6months'
        ];
        $period = $period_map[$days] ?? 'month';
        
        // مفتاح التخزين المؤقت
        $cache_key = 'infi_gold_historical_' . $carat . '_' . $start_date . '_' . $end_date . '_' . $days;
        
        // جلب البيانات التاريخية مع فحص
        if (!function_exists('infi_get_historical_gold_prices')) {
            infi_gold_log("Function infi_get_historical_gold_prices not found", 'error');
            return '<p>' . __('Required function is missing. Please ensure the plugin is installed correctly.', 'infi-gold-manager') . '</p>';
        }
        
        infi_gold_log("Fetching data for period: $days days, start: $start_date, end: $end_date", 'info');
        $historical_data = infi_get_cached_data($cache_key, 'infi_get_historical_gold_prices', [$carat, $start_date, $end_date]);
        
        if (empty($historical_data) || !is_array($historical_data)) {
            infi_gold_log("No valid historical data returned for period: $days days, start: $start_date, end: $end_date", 'warning');
            return '<p>' . __('No valid historical data available for the selected period.', 'infi-gold-manager') . '</p>';
        }
        
        infi_gold_log("Retrieved " . count($historical_data) . " data points for $days days period", 'info');
        
        global $wpdb;
        $currency_table = $wpdb->prefix . 'infi_currency_rates';
        $currency_rate = 1.0;
        
        if ($currency !== 'usd') {
            $latest_currency_date = $wpdb->get_var("SELECT MAX(currency_date) FROM $currency_table");
            if ($latest_currency_date === null) {
                infi_gold_log("No currency data available in table: $currency_table", 'warning');
                return '<p>' . __('No currency data available.', 'infi-gold-manager') . '</p>';
            }
            $currency_rate = $wpdb->get_var($wpdb->prepare(
                "SELECT rate_to_usd FROM $currency_table 
                 WHERE currency_code = %s AND currency_date = %s 
                 ORDER BY fetch_date DESC LIMIT 1",
                $currency,
                $latest_currency_date
            ));
            
            if (!$currency_rate) {
                infi_gold_log("No exchange rate found for currency: $currency", 'warning');
                return '<p>' . __('Exchange rate not available for the selected currency.', 'infi-gold-manager') . '</p>';
            }
            
            $currency_rate = floatval($currency_rate);
        }
        
        // تجميع متوسط السعر اليومي بناءً على التسجيلات الدقيقية
        $daily_data = [];
        foreach ($historical_data as $data_point) {
            if (!isset($data_point['gold_date']) || !isset($data_point['price_usd']) || !strtotime($data_point['gold_date'])) {
                infi_gold_log("Invalid data point: " . print_r($data_point, true), 'warning');
                continue;
            }
            $date = date('Y-m-d', strtotime($data_point['gold_date']));
            $price_usd = floatval($data_point['price_usd']);
            if (!isset($daily_data[$date])) $daily_data[$date] = ['sum' => 0, 'count' => 0];
            $daily_data[$date]['sum'] += $price_usd;
            $daily_data[$date]['count']++;
        }
        
        $labels = [];
        $prices = [];
        foreach ($daily_data as $date => $data) {
            if ($data['count'] > 0) {
                $average_price = ($data['sum'] / $data['count']) * $currency_rate;
                $labels[] = date('m-d', strtotime($date));
                $prices[] = number_format($average_price, 2, '.', '');
            }
        }
        
        if (empty($labels)) {
            infi_gold_log("No valid data points after processing for period: $days days", 'warning');
            return '<p>' . __('No valid data points available after processing.', 'infi-gold-manager') . '</p>';
        }
        
        $theme_color = get_theme_mod('infi_default_color', '#ffb301');
        $backgroundColor = "{$theme_color}88";
        $borderColor = $theme_color;
        
        // إضافة خطوط Google Fonts
        $output = '<link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;700&display=swap" rel="stylesheet">';
        
        $output .= '<div class="col-12 p-2 gold-chart-container" style="background: linear-gradient(145deg, #ffffff, #f1bb09); box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1); border-radius: 12px; padding: 20px;">';
        
        $output .= '<div class="col-12 px-0 row mx-0 mb-3">';
        $output .= '<div class="col-12 col-md-8 p-0 mb-2 mb-md-0 d-flex align-items-center" style="font-weight: normal; font-family: Tajawal, sans-serif; font-size: 18px;">';
        $output .= esc_html($title) . ' ' . esc_html($carat);
        $output .= '</div>';
        $output .= '<div class="col-12 col-md-4 p-0">';
        
        // أزرار التبويب
        $output .= '<div class="period-tabs" style="display: flex; gap: 5px; flex-wrap: wrap; justify-content: flex-end;">';
        $periods = [
            1 => '24 ساعة',
            7 => '7 أيام',
            30 => '30 يوم',
            90 => '3 أشهر',
            180 => '6 أشهر'
        ];
        foreach ($periods as $value => $label) {
            $is_active = $days == $value ? 'background: ' . esc_attr($theme_color) . '; color: #fff; border-color: ' . esc_attr($theme_color) . ';' : 'background: #f8f9fa; color: #333;';
            $output .= '<a href="' . esc_url(add_query_arg('days', $value)) . '" style="padding: 8px 12px; border-radius: 6px; text-decoration: none; font-size: 14px; font-family: Tajawal, sans-serif; border: 1px solid ' . esc_attr($theme_color) . '; ' . $is_active . ' transition: all 0.3s ease;" aria-label="عرض بيانات ' . esc_attr($label) . '">' . esc_html($label) . '</a>';
        }
        $output .= '</div>';
        $output .= '</div>';
        $output .= '</div>';
        
        $output .= '<div class="chart-wrapper" style="position: relative; background: #fff8e1; border-radius: 8px; padding: 10px; min-height: ' . esc_attr($mobile_height) . 'px; width: 100%;">';
        $output .= '<div id="loading-chart-' . esc_attr($chart_id) . '" class="text-center p-5"><div class="spinner-border" role="status" style="color: ' . esc_attr($theme_color) . '; width: 2rem; height: 2rem; border-width: 0.3em;"><span class="visually-hidden">جارٍ التحميل...</span></div></div>';
        $output .= '<canvas id="' . esc_attr($chart_id) . '" style="display: none; width: 100%;" aria-label="مخطط أسعار الذهب لـ ' . esc_attr($carat) . '"></canvas>';
        $output .= '</div>';
        
        $output .= '<div class="text-muted text-center mt-2" style="font-size: 12px; font-family: Tajawal, sans-serif;">عرض بيانات لفترة: ' . ($days == 1 ? '24 ساعة' : ($days . ' يوم')) . ' (' . esc_html($start_date) . ' إلى ' . esc_html($end_date) . ')</div>';
        
        $output .= '</div>';
        
        // إضافة الـ CSS
        $output .= '<style>
            .gold-chart-container {
                transition: all 0.3s ease;
            }
            .period-tabs a:hover {
                background: ' . esc_attr($theme_color) . ' !important;
                color: #fff !important;
                border-color: ' . esc_attr($theme_color) . ' !important;
            }
            .chart-wrapper {
                min-height: ' . esc_attr($mobile_height) . 'px;
            }
            .spinner-border {
                animation: spin 1s linear infinite;
            }
            @keyframes spin {
                0% { transform: rotate(0deg); }
                100% { transform: rotate(360deg); }
            }
            @media (max-width: 768px) {
                .gold-chart-container .chart-wrapper {
                    min-height: ' . esc_attr($mobile_height) . 'px !important;
                }
                .period-tabs a {
                    font-size: 12px;
                    padding: 6px 10px;
                }
            }
            @media (min-width: 769px) {
                .gold-chart-container .chart-wrapper {
                    min-height: ' . esc_attr($height) . 'px !important;
                }
            }
        </style>';
        
        // إضافة مكتبة Chart.js و jQuery
        if (!wp_script_is('chartjs', 'registered')) {
            wp_register_script('chartjs', 'https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.7.0/chart.min.js', [], '3.7.0', true);
        }
        if (!wp_script_is('chartjs', 'enqueued')) {
            wp_enqueue_script('chartjs');
        }
        if (!wp_script_is('jquery', 'enqueued')) {
            wp_enqueue_script('jquery');
        }
        
        // إضافة JavaScript للرسم البياني
        $output .= '<script>
            document.addEventListener("DOMContentLoaded", function() {
                console.log("Loading chart with ' . count($labels) . ' data points for ' . $days . ' days period");
                console.log("Chart period: ' . $start_date . ' to ' . $end_date . '");
                
                var loadingElement = document.getElementById("loading-chart-' . esc_js($chart_id) . '");
                var canvasElement = document.getElementById("' . esc_js($chart_id) . '");
                
                setTimeout(function() {
                    if (loadingElement) loadingElement.style.display = "none";
                    if (canvasElement) canvasElement.style.display = "block";
                    
                    var ctx = canvasElement.getContext("2d");
                    var isMobile = window.innerWidth < 768;
                    
                    var gradientFill = ctx.createLinearGradient(0, 0, 0, isMobile ? ' . esc_js($mobile_height) . ' : ' . esc_js($height) . ');
                    gradientFill.addColorStop(0, "' . esc_js($theme_color) . '33");
                    gradientFill.addColorStop(1, "rgba(0, 0, 0, 0)");
                    
                    var chart = new Chart(ctx, {
                        type: "line",
                        data: {
                            labels: ' . json_encode($labels) . ',
                            datasets: [{
                                label: "' . esc_js($carat . ' ' . __('سعر الذهب', 'infi-gold-manager') . ' (' . $currency . ')') . '",
                                data: ' . json_encode($prices) . ',
                                backgroundColor: gradientFill,
                                borderColor: "' . esc_js($borderColor) . '",
                                pointRadius: ' . ($show_points ? 5 : 0) . ', // إضافة نقاط إذا كان show_points صحيح
                                pointHoverRadius: ' . ($show_points ? 7 : 0) . ', // تكبير النقاط عند التعليق
                                pointBackgroundColor: "' . esc_js($theme_color) . '",
                                pointBorderColor: "#fff",
                                pointBorderWidth: 2,
                                borderWidth: isMobile ? 1.5 : 2,
                                tension: 0.3, // خط سلس
                                fill: true,
                                spanGaps: true // ربط النقاط إذا كانت هناك فجوات
                            }]
                        },
                        options: {
                            responsive: true,
                            maintainAspectRatio: false,
                            animation: {
                                duration: 1000,
                                easing: "easeOutQuart"
                            },
                            plugins: {
                                legend: {
                                    display: false
                                },
                                tooltip: {
                                    backgroundColor: "rgba(0,0,0,0.8)",
                                    titleFont: { family: "Tajawal", size: 14 },
                                    bodyFont: { family: "Tajawal", size: 12 },
                                    callbacks: {
                                        label: function(context) {
                                            return context.dataset.label + ": " + new Intl.NumberFormat("ar-AE", {
                                                style: "currency",
                                                currency: "' . esc_js($currency) . '"
                                            }).format(context.parsed.y);
                                        }
                                    }
                                }
                            },
                            scales: {
                                y: {
                                    grid: {
                                        color: "rgba(0,0,0,0.05)",
                                        lineWidth: 1
                                    },
                                    ticks: {
                                        font: { family: "Tajawal", size: 12 }
                                    }
                                },
                                x: {
                                    grid: {
                                        display: false
                                    },
                                    ticks: {
                                        maxTicksLimit: isMobile ? 10 : 15,
                                        font: { family: "Tajawal", size: 10 }
                                    }
                                }
                            },
                            hover: {
                                mode: "index",
                                intersect: false
                            }
                        }
                    });
                    
                    window.addEventListener("resize", function() {
                        var isMobile = window.innerWidth < 768;
                        chart.data.datasets[0].borderWidth = isMobile ? 1.5 : 2;
                        chart.options.scales.x.ticks.maxTicksLimit = isMobile ? 10 : 15;
                        chart.update();
                    });
                }, 300);
            });
        </script>';
        
        return $output;
        
    } catch (Exception $e) {
        infi_gold_log('Error in gold_chart_shortcode: ' . $e->getMessage(), 'error');
        return '<p>Error loading gold price chart: ' . esc_html($e->getMessage()) . '</p>';
    }
}

// دالة للتحقق من وجود دالة جلب البيانات التاريخية
function check_infi_get_historical_gold_prices_function() {
    if (!function_exists('infi_get_historical_gold_prices')) {
        add_action('admin_notices', function() {
            echo '<div class="notice notice-error is-dismissible"><p>تنبيه: الدالة infi_get_historical_gold_prices غير موجودة، وهي مطلوبة لعرض الرسم البياني للذهب. يرجى التحقق من تثبيت الإضافة بشكل صحيح.</p></div>';
        });
        return false;
    }
    return true;
}
add_action('init', 'check_infi_get_historical_gold_prices_function');

// دالة تسجيل التصحيح
if (!function_exists('infi_gold_log')) {
    function infi_gold_log($message, $level = 'debug') {
        $upload_dir = wp_upload_dir();
        $log_dir = $upload_dir['basedir'] . '/infi-logs';
        
        if (!file_exists($log_dir)) {
            wp_mkdir_p($log_dir);
        }
        
        $log_file = $log_dir . '/gold-chart-debug.log';
        $timestamp = date('Y-m-d H:i:s');
        $log_message = "[$timestamp] [$level] $message" . PHP_EOL;
        
        error_log($log_message, 3, $log_file);
    }
}

// دالة الحصول على البيانات المخزنة مؤقتًا
if (!function_exists('infi_get_cached_data')) {
    function infi_get_cached_data($cache_key, $function_name, $args = []) {
        $cached_data = get_transient($cache_key);
        
        if (false === $cached_data) {
            if (function_exists($function_name)) {
                $cached_data = call_user_func_array($function_name, $args);
                if ($cached_data && is_array($cached_data)) {
                    set_transient($cache_key, $cached_data, 12 * HOUR_IN_SECONDS);
                } else {
                    infi_gold_log("Invalid data returned by $function_name: " . print_r($cached_data, true), 'warning');
                    $cached_data = [];
                }
            } else {
                infi_gold_log("Function $function_name not found", 'error');
                return [];
            }
        }
        
        return $cached_data;
    }
}

function infi_gold_extremes_shortcode($atts) {
    try {
        $settings = get_option('infi_gold_manager_settings', []);
        $default_currency = isset($settings['default_currency']) ? $settings['default_currency'] : 'USD';
        
        $atts = shortcode_atts([
            'carat' => '24k',
            'currency' => $default_currency,
            'days' => 30,
            'show_dates' => 'yes',
            'show' => 'both',
            'decimals' => 2
        ], $atts, 'infi_gold_extremes');
        
        $carat = sanitize_text_field($atts['carat']);
        $currency = strtoupper(sanitize_text_field($atts['currency']));
        $days = intval($atts['days']);
        $show_dates = $atts['show_dates'] === 'yes';
        $show = sanitize_text_field($atts['show']);
        $decimals = intval($atts['decimals']);
        
        $cache_key = 'infi_gold_extremes_' . $carat . '_' . $days;
        $extremes = infi_get_cached_data($cache_key, 'infi_get_gold_price_extremes', [$carat, $days]);
        
        if (empty($extremes)) {
            return '<p>' . __('No price data available for the selected period.', 'infi-gold-manager') . '</p>';
        }
        
        if ($currency !== 'USD') {
            $currency_rate = floatval(do_shortcode('[infi_currency_rate currency="' . esc_attr($currency) . '" decimals="6"]'));
            $extremes['highest_price'] *= $currency_rate;
            $extremes['lowest_price'] *= $currency_rate;
        }
        
        $highest_price = number_format($extremes['highest_price'], $decimals);
        $lowest_price = number_format($extremes['lowest_price'], $decimals);
        
        $highest_date = date_i18n(get_option('date_format'), strtotime($extremes['highest_date']));
        $lowest_date = date_i18n(get_option('date_format'), strtotime($extremes['lowest_date']));
        
        $output = '';
        
        if ($show === 'both' || $show === 'highest') {
            $output .= '<span class="infi-gold-highest">';
            $output .= __('Highest:', 'infi-gold-manager') . ' ' . $highest_price . ' ' . $currency;
            if ($show_dates) {
                $output .= ' (' . $highest_date . ')';
            }
            $output .= '</span>';
            
            if ($show === 'both') {
                $output .= ' | ';
            }
        }
        
        if ($show === 'both' || $show === 'lowest') {
            $output .= '<span class="infi-gold-lowest">';
            $output .= __('Lowest:', 'infi-gold-manager') . ' ' . $lowest_price . ' ' . $currency;
            if ($show_dates) {
                $output .= ' (' . $lowest_date . ')';
            }
            $output .= '</span>';
        }
        
        return $output;
        
    } catch (Exception $e) {
        infi_gold_log('Error in gold_extremes shortcode: ' . $e->getMessage(), 'error');
        return 'Error';
    }
}

function infi_gold_change_shortcode($atts) {
    try {
        $atts = shortcode_atts([
            'carat' => '24k',
            'period' => 'daily',
            'show_percentage' => 'yes',
            'show_value' => 'yes',
            'currency' => 'USD',
            'decimals' => 2
        ], $atts, 'infi_gold_change');
        
        $carat = sanitize_text_field($atts['carat']);
        $period = sanitize_text_field($atts['period']);
        $show_percentage = $atts['show_percentage'] === 'yes';
        $show_value = $atts['show_value'] === 'yes';
        $currency = strtoupper(sanitize_text_field($atts['currency']));
        $decimals = intval($atts['decimals']);
        
        $cache_key = 'infi_gold_change_' . $carat . '_' . $period;
        $change_data = infi_get_cached_data($cache_key, 'infi_get_gold_price_change', [$carat, $period]);
        
        if (empty($change_data) || $change_data['previous_price'] === null) {
            return 'N/A';
        }
        
        if ($currency !== 'USD') {
            $currency_rate = floatval(do_shortcode('[infi_currency_rate currency="' . esc_attr($currency) . '" decimals="6"]'));
            $change_data['current_price'] *= $currency_rate;
            $change_data['previous_price'] *= $currency_rate;
            $change_data['change_value'] *= $currency_rate;
        }
        
        $output = '';
        $change_class = $change_data['change_value'] >= 0 ? 'positive-change' : 'negative-change';
        $change_sign = $change_data['change_value'] >= 0 ? '+' : '';
        
        if ($show_value && $show_percentage) {
            $output .= '<span class="' . $change_class . '">';
            $output .= $change_sign . number_format($change_data['change_value'], $decimals) . ' ' . $currency;
            $output .= ' (' . $change_sign . number_format($change_data['change_percentage'], 2) . '%)';
            $output .= '</span>';
        } elseif ($show_value) {
            $output .= '<span class="' . $change_class . '">';
            $output .= $change_sign . number_format($change_data['change_value'], $decimals) . ' ' . $currency;
            $output .= '</span>';
        } elseif ($show_percentage) {
            $output .= '<span class="' . $change_class . '">';
            $output .= $change_sign . number_format($change_data['change_percentage'], 2) . '%';
            $output .= '</span>';
        } else {
            return 'N/A';
        }
        
        $output .= '<style>
            .positive-change { color: green; }
            .negative-change { color: red; }
        </style>';
        
        return $output;
        
    } catch (Exception $e) {
        infi_gold_log('Error in gold_change shortcode: ' . $e->getMessage(), 'error');
        return 'Error';
    }
}






function infi_debug_data() {
    global $wpdb;
    
    $gold_table = INFI_MAIN_PREFIX  . 'infi_gold_prices';
    $latest_gold_date = $wpdb->get_var("SELECT MAX(gold_date) FROM $gold_table");
    
    echo "<h3>آخر تاريخ محدث للذهب: $latest_gold_date</h3>";
    
    $gold_data = $wpdb->get_results($wpdb->prepare(
        "SELECT carat, price_usd FROM $gold_table WHERE gold_date = %s ORDER BY carat",
        $latest_gold_date
    ), ARRAY_A);
    
    echo "<h4>بيانات الذهب:</h4>";
    echo "<pre>";
    print_r($gold_data);
    echo "</pre>";
    
    $currency_table = INFI_MAIN_PREFIX  . 'infi_currency_rates';
    $latest_currency_date = $wpdb->get_var("SELECT MAX(currency_date) FROM $currency_table");
    
    echo "<h3>آخر تاريخ محدث للعملات: $latest_currency_date</h3>";
    
    $aed_rate = $wpdb->get_var($wpdb->prepare(
        "SELECT rate_to_usd FROM $currency_table WHERE currency_date = %s AND currency_code = 'AED'",
        $latest_currency_date
    ));
    
    echo "<h4>سعر الدرهم الإماراتي (AED): " . ($aed_rate ? $aed_rate : 'غير موجود') . "</h4>";
    
    $currencies = $wpdb->get_results($wpdb->prepare(
        "SELECT currency_code, rate_to_usd FROM $currency_table 
         WHERE currency_date = %s AND currency_code IN ('USD', 'usd', 'AED', 'MAD', 'SAR')
         ORDER BY currency_code",
        $latest_currency_date
    ), ARRAY_A);
    
    echo "<h4>بيانات بعض العملات:</h4>";
    echo "<pre>";
    print_r($currencies);
    echo "</pre>";
    
    echo "<h3>اختبار الشورت كود:</h3>";
    echo "<p>سعر الذهب عيار 24 باليورو: " . do_shortcode('[infi_gold_price carat="24k" currency="usd"]') . "</p>";
    echo "<p>سعر الذهب عيار 24 بالدولار: " . do_shortcode('[infi_gold_price carat="24k" currency="USD"]') . "</p>";
    echo "<p>سعر الذهب عيار 24 بالدرهم الإماراتي: " . do_shortcode('[infi_gold_price carat="24k" currency="AED"]') . "</p>";
    
    echo "<h3>تتبع خطوات الحساب للدرهم الإماراتي:</h3>";
    
    $gold_price_usd = $wpdb->get_var($wpdb->prepare(
        "SELECT price_usd FROM $gold_table WHERE gold_date = %s AND carat = '24k' ORDER BY fetch_date DESC LIMIT 1",
        $latest_gold_date
    ));
    
    echo "<p>سعر الذهب عيار 24 باليورو: $gold_price_usd</p>";
    
    if ($aed_rate) {
        echo "<p>سعر الدرهم الإماراتي مقابل اليورو: $aed_rate</p>";
        echo "<p>حساب سعر الذهب بالدرهم الإماراتي: $gold_price_usd × $aed_rate = " . ($gold_price_usd * $aed_rate) . "</p>";
    }
}

function infi_debug_data_shortcode() {
    ob_start();
    infi_debug_data();
    return ob_get_clean();
}

function infi_gold_info_boxes_shortcode($atts) {
    try {
        global $country_to_currency, $currency_names;
        $settings = get_option('infi_gold_manager_settings', []);
        $default_currency = isset($settings['default_currency']) ? $settings['default_currency'] : 'usd';
        
        $atts = shortcode_atts([
            'currency' => $default_currency,
            'box_type' => 'all',
            'pound_url' => site_url('/'),
            'ounce_usd_url' => site_url('/'),
            'ounce_url' => site_url('/'),
            'dollar_url' => site_url('/'),
        ], $atts, 'infi_gold_info_boxes');
        
        $currency = strtoupper(sanitize_text_field($atts['currency']));
        $box_type = sanitize_text_field($atts['box_type']);
        
        $pound_url = esc_url($atts['pound_url']);
        $ounce_usd_url = esc_url($atts['ounce_usd_url']);
        $ounce_url = esc_url($atts['ounce_url']);
        $dollar_url = esc_url($atts['dollar_url']);
        
        $image_path = INFI_GOLD_MANAGER_URL . 'images/';
        
        global $wpdb;
        $currency_table = INFI_MAIN_PREFIX  . 'infi_currency_rates';
        $currency_rate = 1.0;
        $currency_name = $currency;
        
        if (isset($currency_names[$currency])) {
            $currency_name = $currency_names[$currency];
        }
        
        if ($currency !== 'usd') {
            $latest_currency_date = $wpdb->get_var("SELECT MAX(currency_date) FROM $currency_table");
            $currency_query = $wpdb->prepare(
                "SELECT rate_to_usd FROM $currency_table 
                 WHERE currency_code = %s AND currency_date = %s 
                 ORDER BY fetch_date DESC LIMIT 1",
                $currency,
                $latest_currency_date
            );
            
            $rate_result = $wpdb->get_var($currency_query);
            
            if ($rate_result) {
                $currency_rate = floatval($rate_result);
            }
        }
        
        $usd_rate = 1.0;
        if ($currency !== 'USD') {
            $usd_query = $wpdb->prepare(
                "SELECT rate_to_usd FROM $currency_table 
                 WHERE currency_code = %s AND currency_date = %s 
                 ORDER BY fetch_date DESC LIMIT 1",
                'USD',
                $latest_currency_date
            );
            
            $usd_result = $wpdb->get_var($usd_query);
            
            if ($usd_result) {
                $usd_rate = floatval($usd_result);
            }
        }
        
        $gold_table = INFI_MAIN_PREFIX  . 'infi_gold_prices';
        $latest_gold_date = $wpdb->get_var("SELECT MAX(gold_date) FROM $gold_table");
        
        $ounce_query = $wpdb->prepare(
            "SELECT price_usd FROM $gold_table 
             WHERE carat = %s AND gold_date = %s 
             ORDER BY fetch_date DESC LIMIT 1",
            '24k_oz',
            $latest_gold_date
        );
        
        $ounce_price_usd = $wpdb->get_var($ounce_query);
        $ounce_price_usd = $ounce_price_usd ? floatval($ounce_price_usd) : 0;
        $ounce_price = $ounce_price_usd * $currency_rate;
        
        $ounce_price_usd = $ounce_price_usd * $usd_rate;
        
        $gold_pound_query = $wpdb->prepare(
            "SELECT price_usd FROM $gold_table 
             WHERE carat = %s AND gold_date = %s 
             ORDER BY fetch_date DESC LIMIT 1",
            '21k',
            $latest_gold_date
        );
        
        $gold_price_usd_gram = $wpdb->get_var($gold_pound_query);
        $gold_price_usd_gram = $gold_price_usd_gram ? floatval($gold_price_usd_gram) : 0;
        $gold_pound_price = $gold_price_usd_gram * 8 * $currency_rate;
        
        $dollar_price = $currency_rate / $usd_rate;        
        $images = [
            'pound' => $image_path . 'dollar-coin.png',
            'ounce_usd' => $image_path . 'dollar-sign.png',
            'ounce' => $image_path . 'gold-bars.png',
            'dollar' => $image_path . 'dollar-symbol.png'
        ];
        
        $show_boxes = [];
        if ($box_type === 'all' || $box_type === 'ounce_usd') {
            $show_boxes[] = 'ounce_usd';
        }
        if ($box_type === 'all' || $box_type === 'ounce') {
            $show_boxes[] = 'ounce';
        }
		if ($box_type === 'all' || $box_type === 'pound') {
            $show_boxes[] = 'pound';
        }
        if ($box_type === 'all' || $box_type === 'dollar') {
            $show_boxes[] = 'dollar';
        }
        
        $output = '';
        
        $box_info = [
            'ounce_usd' => [
                'title' => 'الأونصة العالمية',
                'value' => $ounce_price_usd,
                'currency' => 'دولار أمريكي',
                'image' => $images['ounce_usd'],
                'url' => $ounce_usd_url
            ],
            'ounce' => [
                'title' => 'الأونصة بالعملة المحلية',
                'value' => $ounce_price,
                'currency' => $currency_name,
                'image' => $images['ounce'],
                'url' => $ounce_url
            ],
			            'pound' => [
                'title' => 'جنيه الذهب',
                'value' => $gold_pound_price,
                'currency' => $currency_name,
                'image' => $images['pound'],
                'url' => $pound_url
            ],
            'dollar' => [
                'title' => 'سعر الدولار',
                'value' => $dollar_price,
                'currency' => $currency_name,
                'image' => $images['dollar'],
                'url' => $dollar_url
            ]
        ];
        
        foreach ($show_boxes as $box) {
            $info = $box_info[$box];
            
            $output .= '
        <div class="col-12 p-2 hover-me-box cls86" style="background:#fff;border-radius: 50px;margin-bottom: 12px;box-shadow: 0 8px 16px 0 rgb(10 14 29 / 2%), 0 8px 64px 0 rgb(119 119 119 / 8%);">

                <div class="col-12 p-0 row d-flex align-items-center">
                    <div style="width:60px;padding:0px">
                        <img src="' . esc_url($info['image']) . '" style="width:50px;height:50px;border-radius: 50%;" alt="' . esc_html($info['title']) . '">
                    </div>
                    <div class="col-12 p-0 row" style="width: calc(100% - 60px);">
                        <div class="col-12 p-0 text-truncate" style="font-size:15px;opacity:0.8;color:inherit;font-weight:bold">
                            ' . esc_html($info['title']) . '
                        </div>
                        <div class="col-12 p-0 cls87" style="font-size:19px;color:' . get_theme_mod('infi_default_color', '#247b23') . ';">
                            <span style="font-weight: bold;">' . number_format($info['value'], 2) . '</span> <span style="font-size:14px;opacity:0.8">' . esc_html($info['currency']) . '</span>
                        </div>
                    </div>
                </div>
            </a>
        </div>';
    }
        
        return $output;
        
    } catch (Exception $e) {
        infi_gold_log('Error in gold_info_boxes shortcode: ' . $e->getMessage(), 'error');
        return '<p>Error loading gold info boxes.</p>';
    }
}

function infi_gold_price_cards_shortcode($atts) {
    try {
        global $currency_names;
        $settings = get_option('infi_gold_manager_settings', []);
        $default_currency = isset($settings['default_currency']) ? $settings['default_currency'] : 'USD';
        
        $atts = shortcode_atts([
            'currency' => $default_currency,
            'layout' => 'horizontal',
            'show_cards' => 'both',
        ], $atts, 'infi_gold_price_cards');
        
        $currency = strtoupper(sanitize_text_field($atts['currency']));
        $layout = sanitize_text_field($atts['layout']);
        $show_cards = sanitize_text_field($atts['show_cards']);
        
        $currency_name = isset($currency_names[$currency]) ? $currency_names[$currency] : $currency;
        
        global $wpdb;
        $currency_table = INFI_MAIN_PREFIX  . 'infi_currency_rates';
        $currency_rate = 1.0;
        
        if ($currency !== 'usd') {
            $latest_currency_date = $wpdb->get_var("SELECT MAX(currency_date) FROM $currency_table");
            $currency_query = $wpdb->prepare(
                "SELECT rate_to_usd FROM $currency_table 
                 WHERE currency_code = %s AND currency_date = %s 
                 ORDER BY fetch_date DESC LIMIT 1",
                $currency,
                $latest_currency_date
            );
            
            $rate_result = $wpdb->get_var($currency_query);
            
            if ($rate_result) {
                $currency_rate = floatval($rate_result);
            }
        }
        
        $gold_table = INFI_MAIN_PREFIX  . 'infi_gold_prices';
        $latest_gold_date = $wpdb->get_var("SELECT MAX(gold_date) FROM $gold_table");
        
        $ounce_query = $wpdb->prepare(
            "SELECT price_usd FROM $gold_table 
             WHERE carat = %s AND gold_date = %s 
             ORDER BY fetch_date DESC LIMIT 1",
            '24k_oz',
            $latest_gold_date
        );
        
        $ounce_price_usd = $wpdb->get_var($ounce_query);
        $ounce_price_usd = $ounce_price_usd ? floatval($ounce_price_usd) : 0;
        $ounce_price = $ounce_price_usd * $currency_rate;
        
        $gram21_query = $wpdb->prepare(
            "SELECT price_usd FROM $gold_table 
             WHERE carat = %s AND gold_date = %s 
             ORDER BY fetch_date DESC LIMIT 1",
            '21k',
            $latest_gold_date
        );
        
        $gram21_price_usd = $wpdb->get_var($gram21_query);
        $gram21_price_usd = $gram21_price_usd ? floatval($gram21_price_usd) : 0;
        $gram21_price = $gram21_price_usd * $currency_rate;
        
        $ounce_change = infi_get_gold_price_change('24k_oz', 'daily');
        $gram21_change = infi_get_gold_price_change('21k', 'daily');
        
        $ounce_change_value = 0;
        $ounce_change_percentage = 0;
        
        if ($ounce_change && isset($ounce_change['change_value']) && isset($ounce_change['change_percentage'])) {
            $change_value = $ounce_change['change_value'] * $currency_rate;
            $change_percentage = $ounce_change['change_percentage'];
            
            if (abs($change_value) > ($ounce_price * 0.1)) {
                $change_value = $ounce_price * 0.005 * ($change_value > 0 ? 1 : -1);
                $change_percentage = 0.5 * ($change_value > 0 ? 1 : -1);
            }
            
            if (abs($change_percentage) > 10 || !is_numeric($change_percentage)) {
                $change_percentage = 0.5 * ($change_value > 0 ? 1 : -1);
            }
            
            $ounce_change_value = $change_value;
            $ounce_change_percentage = $change_percentage;
        } else {
            $ounce_change_value = $ounce_price * 0.005;
            $ounce_change_percentage = 0.5;
        }
        
        $gram21_change_value = 0;
        $gram21_change_percentage = 0;
        
        if ($gram21_change && isset($gram21_change['change_value']) && isset($gram21_change['change_percentage'])) {
            $change_value = $gram21_change['change_value'] * $currency_rate;
            $change_percentage = $gram21_change['change_percentage'];
            
            if (abs($change_value) > ($gram21_price * 0.1)) {
                $change_value = $gram21_price * 0.005 * ($change_value > 0 ? 1 : -1);
                $change_percentage = 0.5 * ($change_value > 0 ? 1 : -1);
            }
            
            if (abs($change_percentage) > 10 || !is_numeric($change_percentage)) {
                $change_percentage = 0.5 * ($change_value > 0 ? 1 : -1);
            }
            
            $gram21_change_value = $change_value;
            $gram21_change_percentage = $change_percentage;
        } else {
            $gram21_change_value = $gram21_price * 0.005;
            $gram21_change_percentage = 0.5;
        }
        
        $ounce_direction = $ounce_change_value >= 0 ? '▲' : '▼';
        $ounce_color_class = $ounce_change_value >= 0 ? 'text-success' : 'text-danger';
        
        $gram21_direction = $gram21_change_value >= 0 ? '▲' : '▼';
        $gram21_color_class = $gram21_change_value >= 0 ? 'text-success' : 'text-danger';
        
        $ounce_price_formatted = number_format($ounce_price, 2);
        $ounce_change_value_formatted = number_format(abs($ounce_change_value), 2);
        $ounce_change_percentage_formatted = number_format(abs($ounce_change_percentage), 2);
        
        $gram21_price_formatted = number_format($gram21_price, 2);
        $gram21_change_value_formatted = number_format(abs($gram21_change_value), 2);
        $gram21_change_percentage_formatted = number_format(abs($gram21_change_percentage), 2);
        
        $row_class = $layout === 'horizontal' ? 'row' : 'row g-3';
        $col_class = $layout === 'horizontal' ? 'col-md-6' : 'col-12';
        
        $output = '<div class="' . $row_class . ' text-end" dir="rtl">';
        
        if ($show_cards === 'both' || $show_cards === 'ounce') {
            $output .= '<div class="' . $col_class . ' mb-3">';
            $output .= '<div class="card shadow-sm">';
            $output .= '<div class="card-body">';
            $output .= '<p class="card-text text-muted mb-1">سعر الأونصة</p>';
            $output .= '<h3 class="card-title mb-1"><strong>' . $ounce_price_formatted . '</strong> <small class="text-muted">' . $currency_name . '</small></h3>';
            $output .= '<p class="card-text ' . $ounce_color_class . '">';
            $output .= $ounce_direction . ' ' . $ounce_change_value_formatted . ' ' . $currency_name . ' (' . $ounce_change_percentage_formatted . '%)';
            $output .= '</p>';
            $output .= '</div>';
            $output .= '</div>';
            $output .= '</div>';
        }
        
        if ($show_cards === 'both' || $show_cards === 'gram21') {
            $output .= '<div class="' . $col_class . ' mb-3">';
            $output .= '<div class="card shadow-sm">';
            $output .= '<div class="card-body">';
            $output .= '<p class="card-text text-muted mb-1">سعر جرام الذهب عيار 21</p>';
            $output .= '<h3 class="card-title mb-1"><strong>' . $gram21_price_formatted . '</strong> <small class="text-muted">' . $currency_name . '</small></h3>';
            $output .= '<p class="card-text ' . $gram21_color_class . '">';
            $output .= $gram21_direction . ' ' . $gram21_change_value_formatted . ' ' . $currency_name . ' (' . $gram21_change_percentage_formatted . '%)';
            $output .= '</p>';
            $output .= '</div>';
            $output .= '</div>';
            $output .= '</div>';
        }
        
        $output .= '</div>';
        
        return $output;
        
    } catch (Exception $e) {
        infi_gold_log('Error in gold_price_cards shortcode: ' . $e->getMessage(), 'error');
        return '<p>Error loading gold price cards.</p>';
    }
}



function infi_gold_calculator_shortcode($atts) {
    try {
        $settings = get_option('infi_gold_manager_settings', []);
        $default_currency = isset($settings['default_currency']) ? $settings['default_currency'] : 'EUR';
        
        $atts = shortcode_atts([
            'currency' => $default_currency,
        ], $atts, 'infi_gold_calculator');
        
        $currency = strtoupper(sanitize_text_field($atts['currency']));
        
        global $wpdb;
        $gold_table = $wpdb->prefix . 'infi_gold_prices';
        $latest_gold_date = $wpdb->get_var("SELECT MAX(gold_date) FROM $gold_table");
        $currency_table = $wpdb->prefix . 'infi_currency_rates';
        $currency_rate = 1.0;
        
        if ($currency !== 'EUR') {
            $latest_currency_date = $wpdb->get_var("SELECT MAX(currency_date) FROM $currency_table");
            $currency_query = $wpdb->prepare(
                "SELECT rate_to_eur FROM $currency_table 
                 WHERE currency_code = %s AND currency_date = %s 
                 ORDER BY fetch_date DESC LIMIT 1",
                $currency,
                $latest_currency_date
            );
            
            $rate_result = $wpdb->get_var($currency_query);
            
            if ($rate_result) {
                $currency_rate = floatval($rate_result);
            }
        }
        
        $carats = ['24k', '22k', '21k', '18k', '12k', '24k_oz', '21k'];
        $prices = [];
        
        foreach ($carats as $carat) {
            if ($carat === '21k' && count($prices) > 0) {
                continue;
            }
            
            $query = $wpdb->prepare(
                "SELECT price_eur FROM $gold_table 
                 WHERE carat = %s AND gold_date = %s 
                 ORDER BY fetch_date DESC LIMIT 1",
                $carat,
                $latest_gold_date
            );
            
            $price_eur = $wpdb->get_var($query);
            if ($price_eur) {
                if ($carat === '21k' && !isset($prices['gold_pound'])) {
                    $gold_pound_price = floatval($price_eur) * 8 * $currency_rate;
                    $prices['gold_pound'] = round($gold_pound_price);
                } else {
                    $price = floatval($price_eur) * $currency_rate;
                    $prices[$carat] = round($price);
                }
            }
        }
        
 
        
        $options = '';
        foreach ($prices as $carat => $price) {
            if (isset(carat_labels[$carat])) {
                $options .= '<option value="' . esc_attr($price) . '">' . esc_html(carat_labels[$carat]) . '</option>';
            }
        }
        
        $output = '
        <div class="col-12 p-2 font-4 mb-5 d-flex justify-content-between align-items-center rounded" >
            حاسبة الذهب
            <div class="font-1 font-lg-5 spinner-grow text-light" role="status" style="width: 19px;height: 19px;"></div>
        </div>

        <div class="col-12 p-0">
            <div class="col-12 p-2 font-1" >
                حدد عدد الجرامات
            </div>
            <div class="col-12 p-2">
                <input type="number" name="" id="currency-amount" class="form-control"  value="1">
            </div>
        </div>

        <div class="col-12 p-0">
            <div class="col-12 p-2 font-1" >
                اختر النوع
            </div>
            <div class="col-12 p-2">
                <select class="form-control" s id="currency-select">
                    ' . $options . '
                </select>
            </div>
        </div>
        <div class="col-12 px-0" style="padding-bottom: 60px;">
            <div style="font-size:120px;line-height:1.1;color: #fff;font-size: 4.3vw;text-align: justify;padding: 10px;box-sizing: border-box;width: 100%;" class="mt-5 text-center cls91" id="currency-result">0</div>
        </div>

        <script>
        document.addEventListener("DOMContentLoaded", function() {
            const amountInput = document.getElementById("currency-amount");
            const currencySelect = document.getElementById("currency-select");
            const resultDisplay = document.getElementById("currency-result");
            
            function calculateResult() {
                const amount = parseFloat(amountInput.value) || 0;
                const rate = parseFloat(currencySelect.value) || 0;
                const result = amount * rate;
                resultDisplay.textContent = result.toFixed(2);
            }
            
            calculateResult();
            
            amountInput.addEventListener("input", calculateResult);
            currencySelect.addEventListener("change", calculateResult);
        });
        </script>
        ';
        
        return $output;
        
    } catch (Exception $e) {
        infi_gold_log('Error in gold_calculator shortcode: ' . $e->getMessage(), 'error');
        return '<p>Error loading gold calculator.</p>';
    }
}

function infi_gold_weight_table_shortcode($atts) {
    try {
        global $carat_labels, $currency_names;
        $settings = get_option('infi_gold_manager_settings', []);
        $default_currency = isset($settings['default_currency']) ? $settings['default_currency'] : 'usd';
        
        $atts = shortcode_atts([
            'carat' => '24k',
            'currency' => $default_currency,
            'weights' => '1,5,10,15,20,25,50,100,250,500,1000',
        ], $atts, 'infi_gold_weight_table');
        
        $carat = sanitize_text_field($atts['carat']);
        $currency = strtoupper(sanitize_text_field($atts['currency']));
        $weights = explode(',', sanitize_text_field($atts['weights']));
        
        $price = do_shortcode('[infi_gold_price carat="' . $carat . '" currency="' . $currency . '"]');
        
        if ($price === 'N/A' || $price === 'Error') {
            return '<p>سعر الذهب غير متوفر حاليًا.</p>';
        }
        
        $carat_label = isset($carat_labels[$carat]) ? $carat_labels[$carat] : $carat;
        $currency_name = isset($currency_names[$currency]) ? $currency_names[$currency] : $currency;
        
        $price_value = floatval(str_replace(',', '', $price));
        $price_table = [];
        
        foreach ($weights as $weight) {
            $weight = intval($weight);
            if ($weight > 0) {
                $weight_price = $price_value * $weight;
                $price_table[] = [
                    'weight' => $weight,
                    'price' => round($weight_price)
                ];
            }
        }
        
        $output = '<table class="table table-hover local-cur table-bordered">
            <tbody>
                <tr>
                    <td>العيار</td>
                    <td>السعر</td>
                </tr>';
        
        foreach ($price_table as $item) {
            $output .= '<tr>
                <td>' . $item['weight'] . ' جرام ' . $carat_label . '</td>
                <td>' . number_format($item['price']) . ' ' . $currency_name . '</td>
            </tr>';
        }
        
        $output .= '</tbody>
        </table>';
        
        return $output;
        
    } catch (Exception $e) {
        infi_gold_log('Error in gold_weight_table shortcode: ' . $e->getMessage(), 'error');
        return '<p>Error loading gold weight table.</p>';
    }
}


function infi_gold_price_display_shortcode($atts) {
    try {
        $country_to_currency = [
    // الدول العربية
    'dz' => ['currency' => 'DZD', 'name' => 'الجزائر'],
    'bh' => ['currency' => 'BHD', 'name' => 'البحرين'],
    'eg' => ['currency' => 'EGP', 'name' => 'مصر'],
    'iq' => ['currency' => 'IQD', 'name' => 'العراق'],
    'jo' => ['currency' => 'JOD', 'name' => 'الأردن'],
    'kw' => ['currency' => 'KWD', 'name' => 'الكويت'],
    'lb' => ['currency' => 'LBP', 'name' => 'لبنان'],
    'ly' => ['currency' => 'LYD', 'name' => 'ليبيا'],
    'mr' => ['currency' => 'MRU', 'name' => 'موريتانيا'],
    'ma' => ['currency' => 'MAD', 'name' => 'المغرب'],
    'om' => ['currency' => 'OMR', 'name' => 'عمان'],
    'ps' => ['currency' => 'ILS', 'name' => 'فلسطين'],
    'qa' => ['currency' => 'QAR', 'name' => 'قطر'],
    'sa' => ['currency' => 'SAR', 'name' => 'السعودية'],
    'so' => ['currency' => 'SOS', 'name' => 'الصومال'],
    'sd' => ['currency' => 'SDG', 'name' => 'السودان'],
    'sy' => ['currency' => 'SYP', 'name' => 'سوريا'],
    'tn' => ['currency' => 'TND', 'name' => 'تونس'],
    'ae' => ['currency' => 'AED', 'name' => 'الإمارات'],
    'ye' => ['currency' => 'YER', 'name' => 'اليمن'],
    'km' => ['currency' => 'KMF', 'name' => 'جزر القمر'],
    'dj' => ['currency' => 'DJF', 'name' => 'جيبوتي'],
    // باقي دول العالم
    'us' => ['currency' => 'USD', 'name' => 'الولايات المتحدة'],
    'gb' => ['currency' => 'GBP', 'name' => 'بريطانيا'],
    'ca' => ['currency' => 'CAD', 'name' => 'كندا'],
    'au' => ['currency' => 'AUD', 'name' => 'أستراليا'],
    'nz' => ['currency' => 'NZD', 'name' => 'نيوزيلندا'],
    'eu' => ['currency' => 'EUR', 'name' => 'أوروبا'],
    'ch' => ['currency' => 'CHF', 'name' => 'سويسرا'],
    'no' => ['currency' => 'NOK', 'name' => 'النرويج'],
    'se' => ['currency' => 'SEK', 'name' => 'السويد'],
    'dk' => ['currency' => 'DKK', 'name' => 'الدنمارك'],
    'is' => ['currency' => 'ISK', 'name' => 'آيسلندا'],
    'pl' => ['currency' => 'PLN', 'name' => 'بولندا'],
    'cz' => ['currency' => 'CZK', 'name' => 'التشيك'],
    'hu' => ['currency' => 'HUF', 'name' => 'المجر'],
    'ro' => ['currency' => 'RON', 'name' => 'رومانيا'],
    'bg' => ['currency' => 'BGN', 'name' => 'بلغاريا'],
    'hr' => ['currency' => 'HRK', 'name' => 'كرواتيا'],
    'rs' => ['currency' => 'RSD', 'name' => 'صربيا'],
    'al' => ['currency' => 'ALL', 'name' => 'ألبانيا'],
    'mk' => ['currency' => 'MKD', 'name' => 'مقدونيا الشمالية'],
    'ba' => ['currency' => 'BAM', 'name' => 'البوسنة والهرسك'],
    'ge' => ['currency' => 'GEL', 'name' => 'جورجيا'],
    'ua' => ['currency' => 'UAH', 'name' => 'أوكرانيا'],
    'by' => ['currency' => 'BYN', 'name' => 'بيلاروسيا'],
    'md' => ['currency' => 'MDL', 'name' => 'مولدوفا'],
    'ru' => ['currency' => 'RUB', 'name' => 'روسيا'],
    'cn' => ['currency' => 'CNY', 'name' => 'الصين'],
    'jp' => ['currency' => 'JPY', 'name' => 'اليابان'],
    'in' => ['currency' => 'INR', 'name' => 'الهند'],
    'kr' => ['currency' => 'KRW', 'name' => 'كوريا الجنوبية'],
    'sg' => ['currency' => 'SGD', 'name' => 'سنغافورة'],
    'my' => ['currency' => 'MYR', 'name' => 'ماليزيا'],
    'th' => ['currency' => 'THB', 'name' => 'تايلاند'],
    'id' => ['currency' => 'IDR', 'name' => 'إندونيسيا'],
    'ph' => ['currency' => 'PHP', 'name' => 'الفلبين'],
    'vn' => ['currency' => 'VND', 'name' => 'فيتنام'],
    'mm' => ['currency' => 'MMK', 'name' => 'ميانمار'],
    'kz' => ['currency' => 'KZT', 'name' => 'كازاخستان'],
    'uz' => ['currency' => 'UZS', 'name' => 'أوزبكستان'],
    'tj' => ['currency' => 'TJS', 'name' => 'طاجيكستان'],
    'tm' => ['currency' => 'TMT', 'name' => 'تركمانستان'],
    'la' => ['currency' => 'LAK', 'name' => 'لاوس'],
    'kh' => ['currency' => 'KHR', 'name' => 'كمبوديا'],
    'mn' => ['currency' => 'MNT', 'name' => 'منغوليا'],
    'bd' => ['currency' => 'BDT', 'name' => 'بنغلاديش'],
    'pk' => ['currency' => 'PKR', 'name' => 'باكستان'],
    'lk' => ['currency' => 'LKR', 'name' => 'سريلانكا'],
    'np' => ['currency' => 'NPR', 'name' => 'نيبال'],
    'bt' => ['currency' => 'BTN', 'name' => 'بوتان'],
    'mv' => ['currency' => 'MVR', 'name' => 'جزر المالديف'],
    'ir' => ['currency' => 'IRR', 'name' => 'إيران'],
    'af' => ['currency' => 'AFN', 'name' => 'أفغانستان'],
    'za' => ['currency' => 'ZAR', 'name' => 'جنوب أفريقيا'],
    'ng' => ['currency' => 'NGN', 'name' => 'نيجيريا'],
    'ke' => ['currency' => 'KES', 'name' => 'كينيا'],
    'et' => ['currency' => 'ETB', 'name' => 'إثيوبيا'],
    'gh' => ['currency' => 'GHS', 'name' => 'غانا'],
    'ci' => ['currency' => 'XOF', 'name' => 'ساحل العاج'],
    'sn' => ['currency' => 'XOF', 'name' => 'السنغال'],
    'tz' => ['currency' => 'TZS', 'name' => 'تنزانيا'],
    'ug' => ['currency' => 'UGX', 'name' => 'أوغندا'],
    'cm' => ['currency' => 'XAF', 'name' => 'الكاميرون'],
    'cd' => ['currency' => 'CDF', 'name' => 'الكونغو الديمقراطية'],
    'ao' => ['currency' => 'AOA', 'name' => 'أنغولا'],
    'mz' => ['currency' => 'MZN', 'name' => 'موزمبيق'],
    'zw' => ['currency' => 'ZWL', 'name' => 'زيمبابوي'],
    'mg' => ['currency' => 'MGA', 'name' => 'مدغشقر'],
    'mu' => ['currency' => 'MUR', 'name' => 'موريشيوس'],
    'mx' => ['currency' => 'MXN', 'name' => 'المكسيك'],
    'br' => ['currency' => 'BRL', 'name' => 'البرازيل'],
    'ar' => ['currency' => 'ARS', 'name' => 'الأرجنتين'],
    'cl' => ['currency' => 'CLP', 'name' => 'تشيلي'],
    'co' => ['currency' => 'COP', 'name' => 'كولومبيا'],
    'pe' => ['currency' => 'PEN', 'name' => 'بيرو'],
    've' => ['currency' => 'VES', 'name' => 'فنزويلا'],
    'py' => ['currency' => 'PYG', 'name' => 'باراغواي'],
    'uy' => ['currency' => 'UYU', 'name' => 'أوروغواي'],
    'bo' => ['currency' => 'BOB', 'name' => 'بوليفيا'],
    'gt' => ['currency' => 'GTQ', 'name' => 'غواتيمالا'],
    'hn' => ['currency' => 'HNL', 'name' => 'هندوراس'],
    'ni' => ['currency' => 'NIO', 'name' => 'نيكاراغوا'],
    'cr' => ['currency' => 'CRC', 'name' => 'كوستاريكا'],
    'pa' => ['currency' => 'PAB', 'name' => 'بنما'],
    'bs' => ['currency' => 'BSD', 'name' => 'جزر البهاما'],
    'jm' => ['currency' => 'JMD', 'name' => 'جامايكا'],
    'ht' => ['currency' => 'HTG', 'name' => 'هايتي'],
    'do' => ['currency' => 'DOP', 'name' => 'جمهورية الدومينيكان'],
    'tt' => ['currency' => 'TTD', 'name' => 'ترينيداد وتوباغو'],
    'gy' => ['currency' => 'GYD', 'name' => 'غيانا'],
    'sr' => ['currency' => 'SRD', 'name' => 'سورينام'],
    'bz' => ['currency' => 'BZD', 'name' => 'بليز'],
    'fj' => ['currency' => 'FJD', 'name' => 'فيجي'],
    'pg' => ['currency' => 'PGK', 'name' => 'بابوا غينيا الجديدة'],
    'sb' => ['currency' => 'SBD', 'name' => 'جزر سليمان'],
    'vu' => ['currency' => 'VUV', 'name' => 'فانواتو'],
    'ws' => ['currency' => 'WST', 'name' => 'ساموا'],
    'to' => ['currency' => 'TOP', 'name' => 'تونغا'],
    'ki' => ['currency' => 'AUD', 'name' => 'كيريباتي'],
    'nr' => ['currency' => 'AUD', 'name' => 'ناورو'],
    'tv' => ['currency' => 'AUD', 'name' => 'توفالو'],
    'pw' => ['currency' => 'USD', 'name' => 'بالاو'],
    'fm' => ['currency' => 'USD', 'name' => 'ميكرونيسيا'],
    'mh' => ['currency' => 'USD', 'name' => 'جزر مارشال']
];

        global $country_to_currency2, $currency_names, $carat_labels;
        $settings = get_option('infi_gold_manager_settings', []);
        $default_currency = isset($settings['default_currency']) ? $settings['default_currency'] : 'USD';
        $default_country_code = isset($settings['default_country_code']) ? $settings['default_country_code'] : 'sa';
        
        // تحديد طريقة كشف الدولة
        $detection_method = isset($settings['user_country_detection']) ? $settings['user_country_detection'] : 'cloudflare';
        
        // القيم الافتراضية
        $auto_currency = '';
        $auto_country = '';
        $country_code = '';
        
        // تحقق مما إذا كنا في صفحة تصنيف للدول
        $current_term = get_queried_object();
        if (is_tax('countries') && $current_term) {
            // استخدام معلومات الدولة من التصنيف المختار
            $country_code = get_term_meta($current_term->term_id, 'country_code', true);
            $auto_country = $current_term->name;
            $country_currency = get_term_meta($current_term->term_id, 'country_currency', true);
            if (!empty($country_currency)) {
                $auto_currency = $country_currency;
            } elseif (!empty($country_code) && isset($country_to_currency2[$country_code])) {
                $auto_currency = $country_to_currency2[$country_code]['currency'];
            }
        } 
        // إذا لم نكن في صفحة تصنيف للدول أو لم يتم العثور على معلومات
        elseif ($detection_method == 'cloudflare' && isset($_SERVER["HTTP_CF_IPCOUNTRY"]) && !empty($_SERVER["HTTP_CF_IPCOUNTRY"])) {
            // استخدام معلومات الدولة من Cloudflare
            $cf_country_code = strtolower($_SERVER["HTTP_CF_IPCOUNTRY"]);
            
            $usdo_countries = ['de', 'fr', 'it', 'es', 'pt', 'nl', 'be', 'at', 'ie', 'fi', 'lu', 'si', 'mt', 'cy', 'sk', 'ee', 'lv', 'lt', 'gr'];
            if (in_array($cf_country_code, $usdo_countries)) {
                $cf_country_code = 'eu';
            }
            
            if (isset($country_to_currency2[$cf_country_code])) {
                $country_code = $cf_country_code;
                $auto_currency = $country_to_currency2[$cf_country_code]['currency'];
                $auto_country = $country_to_currency2[$cf_country_code]['name'];
            }
        } else {
            // استخدام الدولة الافتراضية من الإعدادات
            $country = get_user_country_info($default_country_code);
            $country_code = $country['code'];
            $auto_country = $country['name'];
            if (isset($country_to_currency2[$country_code])) {
                $auto_currency = $country_to_currency2[$country_code]['currency'];
            }
        }
        
        // إذا لم يتم تحديد دولة بعد، استخدم القيمة الافتراضية
        if (empty($auto_country)) {
            $auto_country = 'مصر'; // أو أي قيمة افتراضية أخرى
        }
        
        // تطبيق الخيارات وتحديد الأولويات
        $atts = shortcode_atts([
            'country' => $auto_country, // الدولة المكتشفة تلقائيًا
            'currency' => $auto_currency ?: $default_currency, // العملة المكتشفة أو الافتراضية
            'carat' => '24k',
            'show_calculator' => 'yes',
            'weights' => '1,5,10,15,20,25,50,100,250,500,1000',
            'theme_color' => get_theme_mod('infi_default_color', '#ffb301')
        ], $atts, 'infi_gold_price_display');
        
        $country = sanitize_text_field($atts['country']);
        $currency = strtoupper(sanitize_text_field($atts['currency']));
        $carat = sanitize_text_field($atts['carat']);
        $show_calculator = sanitize_text_field($atts['show_calculator']) === 'yes';
        $weights = explode(',', sanitize_text_field($atts['weights']));
        $theme_color = sanitize_hex_color($atts['theme_color']);
        
        $carat_label = isset($carat_labels[$carat]) ? $carat_labels[$carat] : $carat;
        $currency_name = isset($currency_names[$currency]) ? $currency_names[$currency] : $currency;
        
        if ($carat === 'gold_pound') {
            $gold_21k_price = do_shortcode('[infi_gold_price carat="21k" currency="' . esc_attr($currency) . '"]');
            
            if ($gold_21k_price !== 'N/A' && $gold_21k_price !== 'Error') {
                // حساب سعر الجنيه الذهبي (8 جرام من عيار 21)
                $price_value = floatval(str_replace(',', '', $gold_21k_price)) * 8;
                $price = number_format($price_value);
                $carat_label = 'جنيه الذهب';
            } else {
                return '<p class="text-red-500 text-center py-4">سعر الذهب غير متوفر حاليًا.</p>';
            }
        } else if ($carat === 'gold_ounce' || $carat === '24k_oz') {
            $gold_oz_price = do_shortcode('[infi_gold_price carat="24k_oz" currency="' . esc_attr($currency) . '"]');
            
            if ($gold_oz_price !== 'N/A' && $gold_oz_price !== 'Error') {
                $price = $gold_oz_price;
                $carat_label = 'أونصة الذهب';
            } else {
                return '<p class="text-red-500 text-center py-4">سعر الذهب غير متوفر حاليًا.</p>';
            }
        } else {
            // جلب أسعار الذهب وتحويلها للعملة المطلوبة
            $price = do_shortcode('[infi_gold_price carat="' . esc_attr($carat) . '" currency="' . esc_attr($currency) . '"]');

            if ($price === 'N/A' || $price === 'Error') {
                return '<p class="text-red-500 text-center py-4">سعر الذهب غير متوفر حاليًا.</p>';
            }
        }
        
        $carats = ['24k', '22k', '21k', '18k', '12k', '24k_oz'];
        $calculator_options = [];
        
        foreach ($carats as $c) {
            $carat_price = do_shortcode('[infi_gold_price carat="' . esc_attr($c) . '" currency="' . esc_attr($currency) . '"]');
            if ($carat_price !== 'N/A' && $carat_price !== 'Error') {
                $carat_label_text = isset($carat_labels[$c]) ? $carat_labels[$c] : $c;
                $calculator_options[$c] = [
                    'label' => $carat_label_text,
                    'price' => str_replace(',', '', $carat_price)
                ];
            }
        }
        
        $gold_pound_price = do_shortcode('[infi_gold_price carat="21k" currency="' . esc_attr($currency) . '"]');
        if ($gold_pound_price !== 'N/A' && $gold_pound_price !== 'Error') {
            $gold_pound_price_value = floatval(str_replace(',', '', $gold_pound_price)) * 8;
            $calculator_options['gold_pound'] = [
                'label' => 'جنيه الذهب',
                'price' => $gold_pound_price_value
            ];
        }
        
        $price_value = floatval(str_replace(',', '', $price));
        $price_table = [];
        
        foreach ($weights as $weight) {
            $weight = intval($weight);
            if ($weight > 0) {
                $weight_price = $price_value * $weight;
                $price_table[] = [
                    'weight' => $weight,
                    'price' => round($weight_price)
                ];
            }
        }

    
        $main_column_class = $show_calculator ? 'col-12 col-lg-8 p-2' : 'col-12 p-2';
        
        $output = '<div class="col-12 p-0 row">';
        
        $output .= '<div class="' . esc_attr($main_column_class) . '">';
        $output .= '<div class="col-12">';
        
        $output .= '<div class="col-12 p-0 font-4 cls92" style="color:#343f52;font-weight: bold;">';
        $output .= esc_html($carat_label) . ' / ' . esc_html($currency_name);
        $output .= '<div class="font-1 font-lg-5 spinner-grow text-secondary" role="status" style="color:#fff;width: 19px;height: 19px;"></div>';
        $output .= '</div>';
        
        $output .= '<h1 class="col-12 p-0 font-1 mt-1 cls93" style="color:#60697b;font-weight:normal;">';
        $output .= 'تعرف على سعر ' . esc_html($carat_label) . ' اليوم في ' . esc_html($country);
        $output .= '</h1>';
        
        $output .= '<div style="" class="mb-5 cls200">' . esc_html($price) . '</div>';
        
        $output .= '<div class="cur-convert-data mt-5">';
        $output .= '<table class="table table-hover local-cur table-bordered">';
        $output .= '<tbody>';
        
        $output .= '<tr>';
        $output .= '<td>العيار</td>';
        $output .= '<td>السعر</td>';
        $output .= '</tr>';
        
        foreach ($price_table as $item) {
            $output .= '<tr>';
            $output .= '<td>' . esc_html($item['weight']) . ' جرام ' . esc_html($carat_label) . '</td>';
            $output .= '<td>' . number_format($item['price']) . ' ' . esc_html($currency_name) . '</td>';
            $output .= '</tr>';
        }
        
        $output .= '</tbody>';
        $output .= '</table>';
        $output .= '</div>';
        
        $output .= '</div>';
        
        // جزء الحاسبة (إذا كان معروضًا)
        if ($show_calculator) {
            $output .= '<div class="col-12 col-lg-4">';
            $output .= '<div class="col-12 px-3 rounded cls95" style="background: #18293c;">';
            
            $output .= '<div class="col-12 p-2 font-4 mb-5 d-flex justify-content-between align-items-center rounded cls96" style="color: #eee;">';
            $output .= 'حاسبة الذهب';
            $output .= '<div class="font-1 font-lg-5 spinner-grow text-light" role="status" style="width: 19px;height: 19px;"></div>';
            $output .= '</div>';
            
            $output .= '<div class="col-12 p-0">';
            $output .= '<div class="col-12 p-2 font-1" style="">';
            $output .= 'حدد عدد الجرامات';
            $output .= '</div>';
            $output .= '<div class="col-12 p-2">';
            $output .= '<input type="number" name="" id="currency-amount-' . esc_attr(uniqid()) . '" class="form-control currency-amount cls97" style="background: transparent;" value="1">';
            $output .= '</div>';
            $output .= '</div>';
            
            $output .= '<div class="col-12 p-0">';
            $output .= '<div class="col-12 p-2 font-1" style="">';
            $output .= 'اختر النوع';
            $output .= '</div>';
            $output .= '<div class="col-12 p-2">';
            $output .= '<select class="form-control currency-select cls98" style="background: transparent;" id="currency-select-' . esc_attr(uniqid()) . '">';
            
            foreach ($calculator_options as $code => $option) {
                $output .= '<option value="' . esc_attr($option['price']) . '">' . esc_html($option['label']) . '</option>';
            }
            
            $output .= '</select>';
            $output .= '</div>';
            $output .= '</div>';
            
            $unique_id = uniqid();
            $output .= '<div class="col-12 px-0 cls99" style="padding-bottom: 60px;">';
            $output .= '<div style="font-size:120px;line-height:1.1;color: #fff;font-size: 4.3vw;text-align: justify;padding: 10px;box-sizing: border-box;width: 100%;" class="mt-5 text-center currency-result cls100" id="currency-result-' . esc_attr($unique_id) . '">' . esc_html($price) . '</div>';
            $output .= '</div>';
            
            $output .= '</div>';
            $output .= '</div>';
        }
        
        $output .= '</div>';
        
        $output .= '<script>
        document.addEventListener("DOMContentLoaded", function() {
            const calculators = document.querySelectorAll(".currency-amount, .currency-select");
            
            calculators.forEach(function(element) {
                element.addEventListener("input", function() {
                    const parentRow = this.closest(".row");
                    const amountInput = parentRow.querySelector(".currency-amount");
                    const currencySelect = parentRow.querySelector(".currency-select");
                    const resultDisplay = parentRow.querySelector(".currency-result");
                    
                    if (amountInput && currencySelect && resultDisplay) {
                        const amount = parseFloat(amountInput.value) || 0;
                        const rate = parseFloat(currencySelect.value) || 0;
                        const result = amount * rate;
                        resultDisplay.textContent = result.toLocaleString("ar-US", {maximumFractionDigits: 2});
                    }
                });
            });
            
            document.querySelectorAll(".currency-amount").forEach(function(input) {
                const event = new Event("input");
                input.dispatchEvent(event);
            });
        });
        </script>';
        
        return $output;
        
    } catch (Exception $e) {
        infi_gold_log('Error in gold_price_display shortcode: ' . $e->getMessage(), 'error');
        return '<p>حدث خطأ أثناء عرض أسعار الذهب.</p>';
    }
}


function infi_currency_display_shortcode($atts) {
    try {
        // الحصول على الإعدادات من لوحة الإدارة
        $settings = get_option('infi_gold_manager_settings', []);
        $default_country_code = isset($settings['default_country_code']) ? $settings['default_country_code'] : 'sa';
        $default_currency = isset($settings['default_currency']) ? $settings['default_currency'] : 'USD';
        
        // تحديد العملة والدولة الافتراضية بناءً على الإعدادات
        $country_currency_map = [
            'eg' => ['currency' => 'EGP', 'name' => 'مصر'],
            'sa' => ['currency' => 'SAR', 'name' => 'السعودية'],
            'ae' => ['currency' => 'AED', 'name' => 'الإمارات'],
            'kw' => ['currency' => 'KWD', 'name' => 'الكويت'],
            'qa' => ['currency' => 'QAR', 'name' => 'قطر'],
            'bh' => ['currency' => 'BHD', 'name' => 'البحرين'],
            'om' => ['currency' => 'OMR', 'name' => 'عمان'],
            'ma' => ['currency' => 'MAD', 'name' => 'المغرب'],
            'us' => ['currency' => 'USD', 'name' => 'الولايات المتحدة'],
            'gb' => ['currency' => 'GBP', 'name' => 'بريطانيا'],
            'eu' => ['currency' => 'EUR', 'name' => 'أوروبا']
        ];
        
        // استخدام رمز الدولة الافتراضي من الإعدادات لتحديد العملة واسم الدولة
        if (isset($country_currency_map[$default_country_code])) {
            $auto_to_currency = $country_currency_map[$default_country_code]['currency'];
            $auto_country_name = $country_currency_map[$default_country_code]['name'];
        } else {
            // إذا لم يكن رمز الدولة موجوداً في المصفوفة، استخدم القيمة الافتراضية من الإعدادات
            $auto_to_currency = $default_currency;
            $auto_country_name = 'السعودية'; // يمكن تغييرها إلى قيمة مناسبة
        }
        
        // معلمات الشورت كود
        $atts = shortcode_atts([
            'from_currency' => 'USD',
            'to_currency' => $auto_to_currency,
            'country' => $auto_country_name,
            'decimals' => 2,
            'show_calculator' => 'yes',
            'weights' => '1,5,10,20,50,100,500,1000',
            'calculator_title' => 'حاسبة تحويل الدولار',
        ], $atts, 'infi_currency_display');
        
        // تنظيف المعلمات
        $from_currency = strtoupper(sanitize_text_field($atts['from_currency']));
        $to_currency = strtoupper(sanitize_text_field($atts['to_currency']));
        $country = sanitize_text_field($atts['country']);
        $decimals = intval($atts['decimals']);
        $show_calculator = sanitize_text_field($atts['show_calculator']) === 'yes';
        $weights = explode(',', sanitize_text_field($atts['weights']));
        $calculator_title = sanitize_text_field($atts['calculator_title']);
        
        $currency_names = [
            'USD' => 'دولار أمريكي',

            'DZD' => 'دينار جزائري',          // الجزائر
            'BHD' => 'دينار بحريني',          // البحرين
            'KMF' => 'فرنك قمري',             // جزر القمر
            'DJF' => 'فرنك جيبوتي',          // جيبوتي
            'EGP' => 'جنيه مصري',            // مصر
            'IQD' => 'دينار عراقي',          // العراق
            'JOD' => 'دينار أردني',          // الأردن
            'KWD' => 'دينار كويتي',          // الكويت
            'LBP' => 'ليرة لبنانية',         // لبنان
            'LYD' => 'دينار ليبي',           // ليبيا
            'MAD' => 'درهم مغربي',           // المغرب
            'MRU' => 'أوقية موريتانية',      // موريتانيا
            'OMR' => 'ريال عماني',           // عمان
            'QAR' => 'ريال قطري',            // قطر
            'SAR' => 'ريال سعودي',           // السعودية
            'SOS' => 'شلن صومالي',          // الصومال
            'SDG' => 'جنيه سوداني',          // السودان
            'SYP' => 'ليرة سورية',           // سوريا
            'TND' => 'دينار تونسي',          // تونس
            'AED' => 'درهم إماراتي',         // الإمارات
            'YER' => 'ريال يمني',            // اليمن
            'PSE' => 'شيكل فلسطيني',         // فلسطين
                'EUR' => 'يورو',                 // (مشترك بين 19 دولة أوروبية)
                'GBP' => 'جنيه إسترليني',        // المملكة المتحدة
                'CHF' => 'فرنك سويسري',         // سويسرا
                'NOK' => 'كرونة نرويجية',       // النرويج
                'SEK' => 'كرونة سويدية',        // السويد
                'DKK' => 'كرونة دنماركية',      // الدنمارك
                'ISK' => 'كرونة آيسلندية',      // آيسلندا
                'PLN' => 'زلوتي بولندي',        // بولندا
                'CZK' => 'كرونة تشيكية',        // التشيك
                'HUF' => 'فورنت مجري',          // المجر
                'RON' => 'ليو روماني',          // رومانيا
                'BGN' => 'ليف بلغاري',          // بلغاريا
                'HRK' => 'كونا كرواتية',        // كرواتيا
                'RSD' => 'دينار صربي',          // صربيا
                'ALL' => 'ليك ألباني',          // ألبانيا
                'MKD' => 'دينار مقدوني',        // مقدونيا الشمالية
                'BAM' => 'مارك بوسني',          // البوسنة والهرسك
                'GEL' => 'لاري جورجي',          // جورجيا
                'UAH' => 'هريفنيا أوكرانية',    // أوكرانيا
                'BYN' => 'روبل بيلاروسي',       // بيلاروسيا
                'MDL' => 'ليو مولدوفي',         // مولدوفا
                'RUB' => 'روبل روسي',           // روسيا (جزء منها في أوروبا)
            ];
        
        $from_currency_name = isset($currency_names[$from_currency]) ? $currency_names[$from_currency] : $from_currency;
        $to_currency_name = isset($currency_names[$to_currency]) ? $currency_names[$to_currency] : $to_currency;
        
        // الحصول على سعر الصرف
        $exchange_rate = 1.0;
        
        // أسعار صرف افتراضية في حالة فشل الحصول على السعر
        $default_rates = [
            'USD_EGP' => 50.65,
            'USD_SAR' => 3.75,
            'USD_AED' => 3.67,
            'USD_KWD' => 0.31,
            'USD_BHD' => 0.38,
            'USD_QAR' => 3.64,
            'USD_OMR' => 0.38,
            'USD_MAD' => 10.03,
            'USD_EUR' => 0.92,
            'USD_GBP' => 0.78
        ];
        
   // محاولة الحصول على السعر من الشورت كود infi_currency_rate
if (function_exists('infi_currency_rate_shortcode')) {
    // الحصول على سعر العملة المطلوبة مقابل اليورو
    $to_currency_rate = do_shortcode('[infi_currency_rate currency="' . esc_attr($to_currency) . '" decimals="6"]');
    $to_currency_rate = ($to_currency_rate !== 'N/A' && $to_currency_rate !== 'Error') ? 
        floatval(str_replace(',', '', $to_currency_rate)) : 1.0;
    
    // الحصول على سعر الدولار مقابل اليورو
    $from_currency_rate = 1.0;
    if ($from_currency !== 'EUR') {
        $from_rate_output = do_shortcode('[infi_currency_rate currency="' . esc_attr($from_currency) . '" decimals="6"]');
        $from_currency_rate = ($from_rate_output !== 'N/A' && $from_rate_output !== 'Error') ? 
            floatval(str_replace(',', '', $from_rate_output)) : 1.0;
    }
    
    // حساب سعر الصرف بين العملتين
    // من العملة المصدر إلى اليورو ثم من اليورو إلى العملة الهدف
    if ($from_currency_rate > 0) {
        $exchange_rate = $to_currency_rate / $from_currency_rate;
    } else {
        $rate_key = $from_currency . '_' . $to_currency;
        $exchange_rate = isset($default_rates[$rate_key]) ? $default_rates[$rate_key] : 1.0;
    }
} else {
    $rate_key = $from_currency . '_' . $to_currency;
    $exchange_rate = isset($default_rates[$rate_key]) ? $default_rates[$rate_key] : 1.0;
}
        
        // إنشاء جدول التحويلات
        $price_table = [];
        foreach ($weights as $weight) {
            $weight = intval($weight);
            if ($weight > 0) {
                $converted_price = $weight * $exchange_rate;
                $price_table[] = [
                    'amount' => $weight,
                    'price' => round($converted_price, $decimals)
                ];
            }
        }
        
        // تحديد تخطيط العرض
        $main_column_class = $show_calculator ? 'col-12 col-lg-8 p-2' : 'col-12 p-2';
        
        // بناء الإخراج HTML
        $output = '<div class="col-12 p-0 row">';
        
        // العمود الرئيسي (السعر والجدول)
        $output .= '<div class="' . esc_attr($main_column_class) . '">';
        $output .= '<div class="col-12">';
        
        // عنوان العملات
        $output .= '<div class="col-12 p-0 font-4 cls102" style="color:#343f52;font-weight: bold;">';
        $output .= esc_html($from_currency_name) . ' / ' . esc_html($to_currency_name);
        $output .= '<div class="font-1 font-lg-5 spinner-grow text-secondary cls104" role="status" style="color:#fff;width: 19px;height: 19px;"></div>';
        $output .= '</div>';
        
        // عنوان الصفحة
        $output .= '<h1 class="col-12 p-0 font-1 mt-1" style="color:#60697b;font-weight:normal;">';
        $output .= 'سعر ' . esc_html($from_currency_name) . ' في ' . esc_html($country) . ' اليوم';
        $output .= '</h1>';
        
        // سعر الصرف الرئيسي
        $output .= '<div class="mb-5 cls200">' . number_format($exchange_rate, $decimals) . '</div>';
        
        // جدول التحويلات
        $output .= '<div class="cur-convert-data mt-5">';
        $output .= '<table class="table table-hover local-cur table-bordered">';
        $output .= '<tbody>';
        
        $output .= '<tr>';
        $output .= '<td>المبلغ بالدولار</td>';
        $output .= '<td>المبلغ بالعملة المحلية</td>';
        $output .= '</tr>';
        
        foreach ($price_table as $item) {
            $output .= '<tr>';
            $output .= '<td>' . esc_html($item['amount']) . ' ' . esc_html($from_currency_name) . '</td>';
            $output .= '<td>' . number_format($item['price'], $decimals) . ' ' . esc_html($to_currency_name) . '</td>';
            $output .= '</tr>';
        }
        
        $output .= '</tbody>';
        $output .= '</table>';
        $output .= '</div>';
        
        $output .= '</div>';
        $output .= '</div>';
        
        // عمود الحاسبة (إذا كانت معروضة)
        if ($show_calculator) {
            $output .= '<div class="col-12 col-lg-4">';
            $output .= '<div class="col-12 px-3 rounded cls105" style="background: #18293c;">';
            
            // عنوان الحاسبة
            $output .= '<div class="col-12 p-2 font-4 mb-5 d-flex justify-content-between align-items-center rounded cls106" style="color: #eee;">';
            $output .= esc_html($calculator_title);
            $output .= '<div class="font-1 font-lg-5 spinner-grow text-light cls107" role="status" style="color:#eee!important;width: 19px;height: 19px;"></div>';
            $output .= '</div>';
            
            // حقل إدخال المبلغ
            $output .= '<div class="col-12 p-0">';
            $output .= '<div class="col-12 p-2 font-1" style="color:#eee">';
            $output .= 'أدخل المبلغ بالدولار';
            $output .= '</div>';
            $output .= '<div class="col-12 p-2">';
            $output .= '<input type="number" name="" id="currency-amount-' . esc_attr(uniqid()) . '" class="form-control currency-amount cls108" style="background: transparent;color:#eee" value="1">';
            $output .= '</div>';
            $output .= '</div>';
            
            // عرض النتيجة
            $unique_id = uniqid();
            $output .= '<div class="col-12 px-0 cls110" style="padding-bottom: 60px;">';
            $output .= '<div style="font-size:120px;line-height:1.1;color: #fff;font-size: 4.3vw;text-align: justify;padding: 10px;box-sizing: border-box;width: 100%;" class="mt-5 text-center currency-result cls11" id="currency-result-' . esc_attr($unique_id) . '">' . number_format($exchange_rate, $decimals) . '</div>';
            $output .= '</div>';
            
            $output .= '</div>';
            $output .= '</div>';
        }
        
        $output .= '</div>';
        
        // سكريبت الحاسبة
        $output .= '<script>
        document.addEventListener("DOMContentLoaded", function() {
            const calculators = document.querySelectorAll(".currency-amount");
            
            calculators.forEach(function(element) {
                element.addEventListener("input", function() {
                    const parentRow = this.closest(".row");
                    const amountInput = this;
                    const resultDisplay = parentRow.querySelector(".currency-result");
                    
                    if (amountInput && resultDisplay) {
                        const amount = parseFloat(amountInput.value) || 0;
                        const rate = ' . esc_js($exchange_rate) . ';
                        const result = amount * rate;
                        resultDisplay.textContent = result.toLocaleString("ar-US", {maximumFractionDigits: ' . esc_js($decimals) . '});
                    }
                });
            });
            
            document.querySelectorAll(".currency-amount").forEach(function(input) {
                const event = new Event("input");
                input.dispatchEvent(event);
            });
        });
        </script>';
        
        return $output;
        
    } catch (Exception $e) {
        return '<p>حدث خطأ أثناء عرض سعر الدولار.</p>';
    }
}




 function countries_display_shortcode($atts) {
    $arab_countries = ['sa', 'kw', 'bh', 'qa', 'ae', 'om', 'eg', 'sy', 'ps', 'iq', 'lb', 'jo', 'ye', 'dz', 'ma', 'tn', 'ly', 'sd'];
    
    $countries = get_terms(array(
        'taxonomy' => 'countries',
        'hide_empty' => false,
    ));
    
    $sorted_countries = [];
    
    foreach ($countries as $country) {
        $country_code = get_term_meta($country->term_id, 'country_code', true);
        if (in_array($country_code, $arab_countries)) {
            $sorted_countries[] = $country;
        }
    }
    
    foreach ($countries as $country) {
        $country_code = get_term_meta($country->term_id, 'country_code', true);
        if (!in_array($country_code, $arab_countries)) {
            $sorted_countries[] = $country;
        }
    }
    
    ob_start();
    ?>
    <div class="countries-container">
        <div class="col-12 px-0 py-5 mt-5">
            <h2 class="col-12 p-0 font-3 mb-0">
            <span class="start-head cls112" style="background: <?php echo get_theme_mod('infi_default_color', '#ffb301'); ?>;"></span> الدول المدعومة            </h2>
            <h3 class="col-12 p-0 mt-1" style="opacity: .7;font-size: 15px;">
                تابع آخر أسعار الذهب في دولتك
            </h3>
        </div>
        
        <div class="col-12 p-0">
            <div class="col-12 p-0 d-flex align-items-center justify-content-center row">
                <?php foreach ($sorted_countries as $country): 
                    $country_code = get_term_meta($country->term_id, 'country_code', true);
                    $country_flag = get_term_meta($country->term_id, 'country_flag', true);
                    $home_url = home_url();
                ?>
                    <div class="py-2 px-1 d-flex align-items-center justify-content-center row m-0" style="width:80px">
                        <a href="<?php echo esc_url($home_url."/country/{$country_code}"); ?>" class="col-12 p-0" style="color:inherit;">
                            <div class="col-12 px-0 py-2 d-flex align-items-center justify-content-center row cls113" style="border:1px solid #f7f7f7;border-radius:15px;">
                                <img alt="<?php echo esc_html($country->name); ?>" src="<?php echo esc_url($country_flag); ?>" style="width:40px" class="p-0">
                                <div class="col-12 p-0 text-center font-1 text-truncate">
                                    <?php echo esc_html($country->name); ?>
                                </div>
                            </div>
                        </a>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>

    

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        // عناصر DOM
        const filterInput = document.getElementById('country-filter');
        const countryItems = document.querySelectorAll('.country-item');
        const noResults = document.getElementById('no-results');
        
        // دالة الفلترة
        function filterCountries() {
            const searchTerm = filterInput.value.trim().toLowerCase();
            let visibleCount = 0;
            
            countryItems.forEach(item => {
                const countryName = item.dataset.name;
                
                if (countryName.includes(searchTerm)) {
                    item.style.display = 'block';
                    visibleCount++;
                } else {
                    item.style.display = 'none';
                }
            });
            
            // إظهار أو إخفاء رسالة عدم وجود نتائج
            if (visibleCount === 0) {
                noResults.classList.remove('hidden');
            } else {
                noResults.classList.add('hidden');
            }
        }
        
        // تطبيق الفلترة عند الكتابة
        filterInput.addEventListener('input', filterCountries);
        
        // مسح حقل البحث عند الضغط على زر Escape
        filterInput.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') {
                filterInput.value = '';
                filterCountries();
            }
        });
    });
    </script>
    <?php
    
    return ob_get_clean();
}







/**
 * شورت كود لعرض جدول متوسط سعر بيع الذهب في الأيام السابقة
 * متجاوب مع الهواتف المحمولة باستخدام Bootstrap (بدون تثبيت العناوين)
 */
function infi_historical_gold_prices_table_shortcode($atts) {
    try {
        global $wpdb, $currency_names;
        $settings = get_option('infi_gold_manager_settings', []);
        $default_currency = isset($settings['default_currency']) ? $settings['default_currency'] : 'USD';
        $default_country = isset($settings['default_country_code']) ? $settings['default_country_code'] : 'sa';
        
        // الإعدادات الافتراضية
        $atts = shortcode_atts([
            'days' => 10,  // عدد الأيام التي سيتم عرضها
            'currency' => $default_currency,  // العملة
            'country' => 'السعودية',  // اسم الدولة للعرض
            'title' => '',  // عنوان الجدول
            'class' => 'table-gold-history',  // كلاس CSS
            'show_indicator' => 'yes',  // إظهار مؤشر السعر
            'include_ounce' => 'yes',  // إضافة سعر الأونصة
            'footer_text' => '* سيتم توفير اسعار الذهب : البيع و الشراء قريبا',  // نص التذييل
            'theme_color' => '',  // لون الثيم
            'date_link_pattern' => '/goldday?date=%s', // نمط الرابط للتواريخ
            'link_target' => '_self', // هدف الرابط (_self, _blank)
        ], $atts, 'infi_historical_gold_prices_table');
        
        // تنظيف المتغيرات
        $days = intval($atts['days']);
        $currency = strtoupper(sanitize_text_field($atts['currency']));
        $country = sanitize_text_field($atts['country']);
        $title = sanitize_text_field($atts['title']);
        $table_class = sanitize_text_field($atts['class']);
        $show_indicator = $atts['show_indicator'] === 'yes';
        $include_ounce = $atts['include_ounce'] === 'yes';
        $footer_text = sanitize_text_field($atts['footer_text']);
        $theme_color = !empty($atts['theme_color']) ? sanitize_hex_color($atts['theme_color']) : get_theme_mod('infi_default_color', '#ffb301');
        $date_link_pattern = sanitize_text_field($atts['date_link_pattern']);
        $link_target = sanitize_text_field($atts['link_target']);
        
        // إذا لم يتم تحديد عنوان، سنستخدم عنوانًا افتراضيًا
        if (empty($title)) {
            $currency_name = isset($currency_names[$currency]) ? $currency_names[$currency] : $currency;
            $title = "متوسط سعر بيع الذهب في الأيام السابقة في {$country} بال{$currency_name}";
        }
        
        // الحصول على العيارات المطلوبة
        $carats = ['24k', '22k', '21k', '18k'];
        if ($include_ounce) {
            $carats[] = '24k_oz';
        }
        
        // الحصول على تاريخ اليوم وحساب التواريخ السابقة
        $end_date = date('Y-m-d');
        $start_date = date('Y-m-d', strtotime("-{$days} days"));
        
        // الحصول على بيانات أسعار الذهب التاريخية من قاعدة البيانات
        $gold_prices_table = INFI_MAIN_PREFIX . 'infi_gold_prices';
        $historical_data = [];
        
        // جلب البيانات لكل عيار
        foreach ($carats as $carat) {
            $query = $wpdb->prepare(
                "SELECT gold_date, price_usd 
                 FROM $gold_prices_table 
                 WHERE carat = %s 
                 AND gold_date BETWEEN %s AND %s 
                 GROUP BY gold_date 
                 ORDER BY gold_date DESC
                 LIMIT %d",
                $carat,
                $start_date,
                $end_date,
                $days
            );
            
            $results = $wpdb->get_results($query, ARRAY_A);
            
            foreach ($results as $result) {
                $date = $result['gold_date'];
                if (!isset($historical_data[$date])) {
                    $historical_data[$date] = [];
                }
                $historical_data[$date][$carat] = floatval($result['price_usd']);
            }
        }
        
        // إذا لم يتم العثور على بيانات
        if (empty($historical_data)) {
            return '<div class="alert alert-info">لا توجد بيانات تاريخية متاحة للفترة المحددة.</div>';
        }
        
        // الحصول على سعر الصرف
        $currency_table = INFI_MAIN_PREFIX . 'infi_currency_rates';
        $exchange_rate = 1.0;
        
        if ($currency !== 'usd') {
            $currency_query = $wpdb->prepare(
                "SELECT rate_to_usd 
                 FROM $currency_table 
                 WHERE currency_code = %s 
                 ORDER BY currency_date DESC, fetch_date DESC 
                 LIMIT 1",
                $currency
            );
            
            $rate_result = $wpdb->get_var($currency_query);
            
            if ($rate_result) {
                $exchange_rate = floatval($rate_result);
            }
        }
        
        // معالجة البيانات وتطبيق سعر الصرف
        $processed_data = [];
        $dates = array_keys($historical_data);
        
        foreach ($dates as $index => $date) {
            $day_data = [
                'date' => $date,
                'formatted_date' => infi_format_arabic_date($date),
                'prices' => []
            ];
            
            // حساب أسعار العيارات المختلفة بالعملة المطلوبة
            foreach ($carats as $carat) {
                if (isset($historical_data[$date][$carat])) {
                    $price_usd = floatval($historical_data[$date][$carat]);
                    $price_currency = round($price_usd * $exchange_rate);
                    $day_data['prices'][$carat] = $price_currency;
                } else {
                    $day_data['prices'][$carat] = 'N/A';
                }
            }
            
            // حساب المؤشر (مقارنة بالسعر السابق)
            if ($show_indicator && $index < count($dates) - 1) {
                $next_date = $dates[$index + 1];
                
                if (isset($historical_data[$date]['24k']) && isset($historical_data[$next_date]['24k'])) {
                    $current_price = $historical_data[$date]['24k'];
                    $previous_price = $historical_data[$next_date]['24k'];
                    
                    if ($current_price > $previous_price) {
                        $day_data['indicator'] = '⬆️';
                    } elseif ($current_price < $previous_price) {
                        $day_data['indicator'] = '⬇️';
                    } else {
                        $day_data['indicator'] = '➡️';
                    }
                } else {
                    $day_data['indicator'] = '—';
                }
            } else {
                $day_data['indicator'] = '—';
            }
            
            $processed_data[] = $day_data;
        }
        
        // بناء الجدول
        $output = '<div class="table-responsive p-0">';
        
        // إضافة العنوان
        if (!empty($title)) {
            // يمكن إضافة العنوان هنا إذا احتجت له
        }
        
        $output .= '<table class="table table-striped table-bordered ' . esc_attr($table_class) . '" dir="rtl">';
        
        // إضافة رأس الجدول
        $output .= '<thead style="background-color:' . esc_attr($theme_color) . '; color: white;"><tr>';
        $output .= '<th>اليوم</th>';
        $output .= '<th>ذهب 24</th>';
        $output .= '<th>ذهب 22</th>';
        $output .= '<th>ذهب 21</th>';
        $output .= '<th>ذهب 18</th>';
        
        if ($include_ounce) {
            $output .= '<th>الاوقية</th>';
        }
        
        if ($show_indicator) {
            $output .= '<th>المؤشر</th>';
        }
        
        $output .= '</tr></thead>';
        
        // إضافة بيانات الجدول
        $output .= '<tbody>';
        
        foreach ($processed_data as $data) {
            $output .= '<tr>';
            
            // إنشاء رابط للتاريخ
            $date_url = sprintf($date_link_pattern, $data['date']);
            $output .= '<th class="text-end">';
            $output .= '<a href="' . esc_url($date_url) . '" target="' . esc_attr($link_target) . '">';
            $output .= esc_html($data['formatted_date']);
            $output .= '</a>';
            $output .= '</th>';
            
            // العيارات القياسية
            foreach (['24k', '22k', '21k', '18k'] as $carat) {
                $price = isset($data['prices'][$carat]) ? $data['prices'][$carat] : 'N/A';
                $output .= '<td class="text-center">' . esc_html($price) . '</td>';
            }
            
            // الأونصة (اختياري)
            if ($include_ounce) {
                $ounce_price = isset($data['prices']['24k_oz']) ? $data['prices']['24k_oz'] : 'N/A';
                $output .= '<td class="text-center">' . esc_html($ounce_price) . '</td>';
            }
            
            // مؤشر السعر (اختياري)
            if ($show_indicator) {
                $output .= '<td class="text-center">' . esc_html($data['indicator']) . '</td>';
            }
            
            $output .= '</tr>';
        }
        
        $output .= '</tbody>';
        
        // إضافة تذييل الجدول
        if (!empty($footer_text)) {
            $output .= '<tfoot><tr>';
            $output .= '<td colspan="' . ($include_ounce ? ($show_indicator ? '7' : '6') : ($show_indicator ? '6' : '5')) . '" class="text-center small fst-italic text-muted">' . esc_html($footer_text) . '</td>';
            $output .= '</tr></tfoot>';
        }
        
        $output .= '</table>';
        $output .= '</div>'; // نهاية table-responsive
        
        // إضافة CSS إضافي
        $output .= '
        <style>
            .table-responsive {
                max-width: 100%;
                overflow-x: auto;
                -webkit-overflow-scrolling: touch;
            }
            .' . esc_attr($table_class) . ' {
                width: 100%;
                margin-bottom: 1rem;
            }
            @media (max-width: 767px) {
                .' . esc_attr($table_class) . ' {
                    min-width: 650px;
                }
            }
        </style>';
        
        return $output;
        
    } catch (Exception $e) {
        // تسجيل الأخطاء إن وجدت
        return '<div class="alert alert-danger">حدث خطأ أثناء استرجاع أسعار الذهب التاريخية.</div>';
    }
}
add_shortcode('infi_historical_gold_table', 'infi_historical_gold_prices_table_shortcode');


/**
 * دالة مساعدة لتنسيق التاريخ بالعربية
 */
function infi_format_arabic_date($date_string) {
    // تحويل التاريخ إلى كائن DateTime
    $date = new DateTime($date_string);
    
    // الحصول على اليوم والشهر والسنة
    $day = $date->format('j');  // اليوم بدون أصفار
    $month = $date->format('n'); // الشهر بدون أصفار
    $year = $date->format('Y'); // السنة
    
    // مصفوفة أسماء أيام الأسبوع بالعربية
    $arabic_days = [
        'Sunday' => 'الأحد',
        'Monday' => 'الإثنين',
        'Tuesday' => 'الثلاثاء',
        'Wednesday' => 'الأربعاء',
        'Thursday' => 'الخميس',
        'Friday' => 'الجمعة',
        'Saturday' => 'السبت'
    ];
    
    // مصفوفة أسماء الشهور بالعربية
    $arabic_months = [
        1 => 'يناير',
        2 => 'فبراير',
        3 => 'مارس',
        4 => 'أبريل',
        5 => 'مايو',
        6 => 'يونيو',
        7 => 'يوليو',
        8 => 'أغسطس',
        9 => 'سبتمبر',
        10 => 'أكتوبر',
        11 => 'نوفمبر',
        12 => 'ديسمبر'
    ];
    
    // الحصول على اسم اليوم بالإنجليزية ثم ترجمته
    $day_name = $arabic_days[$date->format('l')];
    
    // الحصول على اسم الشهر بالعربية
    $month_name = $arabic_months[$month];
    
    // تنسيق التاريخ النهائي
    return $day_name . '، ' . $day . ' ' . $month_name;
}













/**
 * شورت كود مخصص لعرض سعر الدولار مقابل العملة المحلية بتنسيق HTML محدد
 * 
 * الاستخدام: [custom_currency_display currency="SAR" color="#058723"]
 */
function custom_currency_display_shortcode($atts) {
    // إعدادات افتراضية
    $atts = shortcode_atts(array(
        'currency' => 'SAR',      // العملة المحلية
        'from_currency' => 'USD', // العملة المصدر (دولار)
        'color' => '#058723',     // لون السعر
        'title' => '',            // عنوان مخصص
        'decimals' => 2           // الأرقام العشرية
    ), $atts, 'custom_currency_display');
    
    // تنظيف المدخلات
    $currency = strtoupper(sanitize_text_field($atts['currency']));
    $from_currency = strtoupper(sanitize_text_field($atts['from_currency']));
    $color = sanitize_hex_color($atts['color']);
    $decimals = intval($atts['decimals']);
    
    // قائمة أسماء العملات العربية
    $currency_names = [
        'SAR' => 'ريال سعودي',
        'AED' => 'درهم إماراتي',
        'KWD' => 'دينار كويتي',
        'BHD' => 'دينار بحريني',
        'QAR' => 'ريال قطري',
        'OMR' => 'ريال عماني',
        'EGP' => 'جنيه مصري',
        'JOD' => 'دينار أردني',
        'IQD' => 'دينار عراقي',
        'USD' => 'دولار أمريكي',
        'EUR' => 'يورو',
        'GBP' => 'جنيه إسترليني'
    ];
    
    // استخدام اسم العملة من القائمة أو استخدام الرمز
    $currency_name = isset($currency_names[$currency]) ? $currency_names[$currency] : $currency;
    
    // الحصول على سعر الصرف باستخدام شورت كود موجود
    $exchange_rate = do_shortcode('[infi_currency_rate currency="' . esc_attr($currency) . '" decimals="' . esc_attr($decimals) . '"]');
    
    // التحقق من صحة القيمة العائدة
    if ($exchange_rate === 'N/A' || $exchange_rate === 'Error') {
        return '<div class="error">عذراً، سعر الصرف غير متوفر حالياً.</div>';
    }
    
    // العنوان المخصص أو الافتراضي
    $title = !empty($atts['title']) ? sanitize_text_field($atts['title']) : 
        'سعر ' . (isset($currency_names[$from_currency]) ? $currency_names[$from_currency] : $from_currency);
    
    // الحصول على التاريخ والوقت الحاليين
    $date_format = get_option('date_format');
    $time_format = get_option('time_format');
    $current_date = date_i18n($date_format, current_time('timestamp'));
    $current_time = date_i18n($time_format, current_time('timestamp'));
    $current_time = str_replace(['AM', 'PM'], ['صباحًا', 'مساءً'], $current_time);
    
    // إنشاء الإخراج HTML
    $output = '<div class="gold-price-container w-full max-w-4xl mx-auto bg-white shadow-lg rounded-lg overflow-hidden">';
    $output .= '<div class="py-8 px-4 text-center">';
    $output .= '<div class="text-5xl font-bold mb-4" style="color: ' . esc_attr($color) . '">' . esc_html($exchange_rate) . '</div>';
    $output .= '<div class="text-lg text-gray-600">' . esc_html($currency_name) . '</div>';
    $output .= '<div class="text-sm text-gray-500 mt-3">آخر تحديث:' . $current_date . ' ' . $current_time . '</div>';
    $output .= '</div></div>';
    
    return $output;
}
add_shortcode('custom_currency_display', 'custom_currency_display_shortcode');













function infi_gold_table_advanced_shortcode($atts) {
    try {
        global $currency_names, $carat_labels;
        $settings = get_option('infi_gold_manager_settings', []);
        $default_currency = isset($settings['default_currency']) ? $settings['default_currency'] : 'usd';
        
        $atts = shortcode_atts([
            'currency' => $default_currency,
            'country' => 'مصر',
            'header_bg' => '#ffb301',
            'header_color' => '#fff',
            'table_class' => 'table table-bordered table-hover',
            'currency_label' => ''
        ], $atts, 'infi_gold_table_advanced');
        
        $currency = strtoupper(sanitize_text_field($atts['currency']));
        $country = sanitize_text_field($atts['country']);
        $header_bg = sanitize_text_field($atts['header_bg']);
        $header_color = sanitize_text_field($atts['header_color']);
        $table_class = sanitize_text_field($atts['table_class']);
        $currency_label = sanitize_text_field($atts['currency_label']);
        
        if (!empty($currency_label)) {
            $currency_name = $currency_label;
        } else {
            $currency_name = isset($currency_names[$currency]) ? $currency_names[$currency] : $currency;
        }
        
        global $wpdb;
        $currency_table = INFI_MAIN_PREFIX  . 'infi_currency_rates';
        $currency_rate = 1.0;
        
        if ($currency !== 'usd') {
            $latest_currency_date = $wpdb->get_var("SELECT MAX(currency_date) FROM $currency_table");
            $currency_query = $wpdb->prepare(
                "SELECT rate_to_usd FROM $currency_table 
                 WHERE currency_code = %s AND currency_date = %s 
                 ORDER BY fetch_date DESC LIMIT 1",
                $currency,
                $latest_currency_date
            );
            
            $rate_result = $wpdb->get_var($currency_query);
            
            if ($rate_result) {
                $currency_rate = floatval($rate_result);
            }
        }
        
        $gold_table = INFI_MAIN_PREFIX  . 'infi_gold_prices';
        $latest_gold_date = $wpdb->get_var("SELECT MAX(gold_date) FROM $gold_table");
        
        $markup = infi_get_markup_percentages($currency);
        $buy_percentage = $markup['buy_percentage'] / 100;
        $sell_percentage = $markup['sell_percentage'] / 100;
        
        $carats = [
            '24k' => 'ذهب عيار 24',
            '22k' => 'ذهب عيار 22',
            '21k' => 'ذهب عيار 21',
            '18k' => 'ذهب عيار 18',
            '12k' => 'ذهب عيار 12',
            '24k_oz' => 'أونصة الذهب',
            'gold_pound' => 'جنيه الذهب'
        ];
        
        $gold_prices = [];
        
        foreach ($carats as $carat_code => $carat_name) {
            if ($carat_code === 'gold_pound') {
                $query = $wpdb->prepare(
                    "SELECT price_usd FROM $gold_table 
                     WHERE carat = %s AND gold_date = %s 
                     ORDER BY fetch_date DESC LIMIT 1",
                    '21k',
                    $latest_gold_date
                );
                // ملاحظة: على الرغم من تسمية الحقل price_usd، إلا أن القيمة المخزنة هي سعر الذهب بالدولار

                $price_usd = $wpdb->get_var($query);
                if ($price_usd) {
                    $base_price = floatval($price_usd) * 8 * $currency_rate;
                } else {
                    $base_price = 0;
                }
            } else {
                $query = $wpdb->prepare(
                    "SELECT price_usd FROM $gold_table 
                     WHERE carat = %s AND gold_date = %s 
                     ORDER BY fetch_date DESC LIMIT 1",
                    $carat_code,
                    $latest_gold_date
                );
                // ملاحظة: على الرغم من تسمية الحقل price_usd، إلا أن القيمة المخزنة هي سعر الذهب بالدولار

                $price_usd = $wpdb->get_var($query);
                if ($price_usd) {
                    $base_price = floatval($price_usd) * $currency_rate;
                } else {
                    $base_price = 0;
                }
            }
            
            $buy_price = $base_price * (1 + $buy_percentage);
            $sell_price = $base_price * (1 - $sell_percentage);
            
            $gold_prices[$carat_code] = [
                'name' => $carat_name,
                'buy' => round($buy_price),
                'sell' => round($sell_price)
            ];
        }
        
        $header_bg = get_theme_mod('infi_default_color', '#ffb301');

        $output = '<div class="col-12 p-0">
            <table class="' . esc_attr($table_class) . ' cls90" style="border-radius:5px;overflow:hidden;">
                <thead>
                    <tr>
                        <th style="background:' . esc_attr($header_bg) . ';color:' . esc_attr($header_color) . ';border-color:' . esc_attr($header_bg) . '">العيار</th>
                        <th style="background:' . esc_attr($header_bg) . ';color:' . esc_attr($header_color) . ';border-color:' . esc_attr($header_bg) . '">الشراء</th>
                        <th style="background:' . esc_attr($header_bg) . ';color:' . esc_attr($header_color) . ';border-color:' . esc_attr($header_bg) . '">البيع</th>
                    </tr>
                </thead>
                <tbody>';
        
        foreach ($carats as $carat_code => $carat_name) {
            if (isset($gold_prices[$carat_code])) {
                $price = $gold_prices[$carat_code];
                $output .= '<tr>
                    <td>' . esc_html($price['name']) . '</td>
                    <td style="font-weight:bold">' . number_format($price['buy']) . ' <span class="d-none d-lg-inline-block">' . esc_html($currency_name) . '</span></td>
                    <td style="font-weight:bold">' . number_format($price['sell']) . ' <span class="d-none d-lg-inline-block">' . esc_html($currency_name) . '</span></td>
                </tr>';
            }
        }
        
        $output .= '</tbody>
            </table>
        </div>';
        
        return $output;
        
    } catch (Exception $e) {
        infi_gold_log('Error in gold_table_advanced shortcode: ' . $e->getMessage(), 'error');
        return '<p>Error loading gold prices table.</p>';
    }
}
















function infi_gold_cards_shortcode($atts) {
    try {
        $settings = get_option('infi_gold_manager_settings', []);
        $default_currency = $settings['default_currency'] ?? 'USD';
        $site_url = site_url();

        $atts = shortcode_atts([
            'currency' => $default_currency,
            'featured_carat' => '21k',
            'decimals' => 2,
            'currency_label' => '',
            'base_url' => '/kerat-',
        ], $atts, 'infi_gold_cards');

        $currency = strtoupper(sanitize_text_field($atts['currency']));
        $featured_carat = sanitize_text_field($atts['featured_carat']);
        $decimals = intval($atts['decimals']);
        $currency_label = sanitize_text_field($atts['currency_label']);
        $base_url = esc_url_raw($atts['base_url']);

        if (empty($currency_label)) $currency_label = $currency;

        $carats = ['24k', '22k', '21k', '18k', '14k', '12k'];
        $prices = [];

        foreach ($carats as $carat) {
            $price = do_shortcode('[infi_gold_price carat="' . esc_attr($carat) . '" currency="' . esc_attr($currency) . '" decimals="' . esc_attr($decimals) . '"]');
            $prices[$carat] = ($price !== 'N/A' && $price !== 'Error') ? $price : '0.00';
        }

        $output = '<div class="infi-gold-cards-container">';
        
        // ✅ Featured card (21k) - البطاقة المميزة العلوية
        $featured_price = $prices[$featured_carat] ?? '0.00';
        $featured_number = str_replace('k', '', $featured_carat);
        $output .= '
        <div class="gold-featured-card">
            <div class="featured-header">الأكثر تداولاً</div>
            <div class="gold-featured-inner">
                <div class="gold-featured-label">عيار ' . $featured_number . '</div>
                <div class="price-container">
                    <span class="gold-featured-price">' . $featured_price . '</span>
                    <span class="gold-featured-currency">' . $currency_label . '</span>
                </div>
            </div>
        </div>';

        // ✅ Other cards vertical list - القائمة العمودية
        $output .= '<div class="infi-gold-list">';
        foreach ($carats as $carat) {
            if ($carat === $featured_carat) continue;
            $num = str_replace('k', '', $carat);
            $output .= '
            <div class="gold-list-item">
                <div class="gold-item-carat">
                    <span class="icon-gold"></span>
                    عيار ' . $num . '
                </div>
                <div class="gold-item-price">
                    <span class="value">' . $prices[$carat] . '</span>
                    <span class="currency">' . $currency_label . '</span>
                </div>
            </div>';
        }
        $output .= '</div></div>';

        // ✅ CSS Styles
        $output .= '
        <style>
        .infi-gold-cards-container {
            direction: rtl;
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
            max-width: 600px;
            margin: 0 auto;
            padding: 20px 10px;
        }

        /* --- البطاقة المميزة --- */
        .gold-featured-card {
            background: linear-gradient(135deg, #d4af37 0%, #b8860b 100%);
            color: #fff;
            border-radius: 12px;
            box-shadow: 0 10px 25px rgba(184, 134, 11, 0.3);
            margin-bottom: 25px;
            overflow: hidden;
            position: relative;
            text-align: center;
        }
        .featured-header {
            background: rgba(0,0,0,0.1);
            font-size: 0.9em;
            padding: 5px 0;
            letter-spacing: 0.5px;
        }
        .gold-featured-inner {
            padding: 20px;
        }
        .gold-featured-label {
            font-size: 1.8em;
            font-weight: bold;
            margin-bottom: 5px;
            text-shadow: 1px 1px 3px rgba(0,0,0,0.2);
        }
        .price-container {
            display: flex;
            align-items: baseline;
            justify-content: center;
            gap: 5px;
        }
        .gold-featured-price {
            font-size: 2.8em;
            font-weight: 800;
            line-height: 1;
        }
        .gold-featured-currency {
            font-size: 1.1em;
            opacity: 0.9;
        }

        /* --- القائمة العمودية --- */
        .infi-gold-list {
            display: flex;
            flex-direction: column;
            gap: 12px; /* المسافة بين كل بلوك وآخر */
        }

        .gold-list-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: #fff;
            border: 1px solid #e0c080;
            border-right: 5px solid #d4af37; /* زخرفة ذهبية يمين الكارت */
            padding: 15px 20px;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.05);
            transition: transform 0.2s ease, box-shadow 0.2s ease;
        }

        .gold-list-item:hover {
            transform: translateY(-3px);
            box-shadow: 0 6px 12px rgba(212, 175, 55, 0.2);
            border-color: #d4af37;
        }

        .gold-item-carat {
            font-size: 1.2em;
            font-weight: bold;
            color: #333;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        /* دائرة صغيرة ذهبية بجانب الاسم */
        .icon-gold {
            width: 10px;
            height: 10px;
            background: #d4af37;
            border-radius: 50%;
            display: inline-block;
        }

        .gold-item-price {
            text-align: left;
        }

        .gold-item-price .value {
            display: block;
            font-size: 1.4em;
            font-weight: 700;
            color: #247b23; /* لون السعر أخضر */
        }
        
        .gold-item-price .currency {
            display: block;
            font-size: 0.8em;
            color: #777;
            margin-top: -2px;
        }

        /* التوافق مع الجوال */
        @media (max-width: 480px) {
            .gold-featured-price { font-size: 2.2em; }
            .gold-list-item { padding: 12px 15px; }
            .gold-item-carat { font-size: 1.1em; }
            .gold-item-price .value { font-size: 1.2em; }
        }
        </style>';

        return $output;
    } catch (Exception $e) {
        return '<p style="text-align:center;color:red;font-weight:bold;">حدث خطأ أثناء تحميل بطاقات أسعار الذهب.</p>';
    }
}