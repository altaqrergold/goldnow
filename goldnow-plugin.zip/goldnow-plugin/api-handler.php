<?php
/**
 * التعامل مع واجهات API وجلب البيانات
 * Path: /api-handler.php
 */

if (!defined('ABSPATH')) {
    exit;
}
/**
 * الدالة الرئيسية لجلب أسعار الذهب
 */
function infi_fetch_gold_prices() {
    try {
        $settings = get_option('infi_gold_manager_settings', []);
        $api_provider = isset($settings['api_provider']) ? $settings['api_provider'] : 'metalprice';
        
        switch ($api_provider) {
            case 'metals-api':
                return infi_fetch_gold_prices_metals_api();
            case 'swissquote':
                return infi_fetch_gold_prices_swissquote();
            case 'metalprice':
            default:
                return infi_fetch_gold_prices_metalprice();
        }
    } catch (Exception $e) {
        infi_gold_log('Error in fetch_gold_prices: ' . $e->getMessage(), 'error');
        return false;
    }
}


/**
 * جلب أسعار الذهب من Swissquote API
 */
function infi_fetch_gold_prices_swissquote() {
    try {
        infi_gold_log('Starting to fetch gold prices from Swissquote API');
        
        $endpoint = "https://forex-data-feed.swissquote.com/public-quotes/bboquotes/instrument/XAU/USD";
        
        $response = wp_remote_get($endpoint, [
            'timeout' => 30,
            'headers' => [
                'Accept' => 'application/json'
            ]
        ]);
        
        if (is_wp_error($response)) {
            throw new Exception('API request failed: ' . $response->get_error_message());
        }
        
        $status_code = wp_remote_retrieve_response_code($response);
        if ($status_code !== 200) {
            throw new Exception("API returned error status code: $status_code");
        }
        
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        
        infi_gold_log('Swissquote API Response: ' . print_r($data, true), 'debug');
        
        // تحقق من وجود البيانات المطلوبة في الإستجابة
        if (!is_array($data) || empty($data)) {
            throw new Exception('Gold price data not found in API response');
        }
        
        // الحصول على سعر الذهب (XAU/USD)
        $gold_price_usd = null;
        foreach ($data as $item) {
            if (isset($item['topo']['platform']) && isset($item['spreadProfilePrices'])) {
                // نختار أول سعر متاح
                if (!empty($item['spreadProfilePrices'][0]['bid']) && !empty($item['spreadProfilePrices'][0]['ask'])) {
                    $bid = floatval($item['spreadProfilePrices'][0]['bid']);
                    $ask = floatval($item['spreadProfilePrices'][0]['ask']);
                    // حساب متوسط سعر البيع والشراء
                    $gold_price_usd = ($bid + $ask) / 2;
                    break;
                }
            }
        }
        
        if ($gold_price_usd === null) {
            throw new Exception('Could not extract gold price from API response');
        }
        
      /*
        $usd_usd_rate = infi_get_usd_usd_rate();
        if ($usd_usd_rate <= 0) {
            $usd_usd_rate = 1.1; // قيمة افتراضية إذا فشل الحصول على سعر الصرف
        }
        
        $gold_price_usd = $gold_price_usd / $usd_usd_rate;
        
        // حساب السعر للأونصة بالجرام واليورو
        */
        // نستخدم سعر الذهب بالدولار مباشرة دون تحويل

// على الرغم من أن اسم المتغير هو price_usd، سنخزن فيه القيمة بالدولار
$gold_price_base = $gold_price_usd; // نستبدل usd بـ usd في الاسم لاحقاً

// إضافة تعليق للتوضيح
// ملاحظة: على الرغم من اسم المتغير، القيمة تُخزن بالدولار وليس باليورو

        $gold_oz_gram_price_usd = $gold_price_base / 31.1034768;



        // إنشاء مصفوفة النتائج لمختلف العيارات
        $carats = [24, 22, 21, 18, 14, 12];
        $prices = [];
        
        // إضافة سعر الذهب للأونصة (عيار 24)
        $prices[] = [
            'metal' => 'gold',
            'carat' => '24k_oz',
            'price_usd' => $gold_price_base
        ];
        
        // إضافة سعر الذهب للجرام (عيار 24)
        $prices[] = [
            'metal' => 'gold',
            'carat' => '24k',
            'price_usd' => $gold_oz_gram_price_usd
        ];
        
        // حساب أسعار العيارات الأخرى
        foreach ($carats as $carat) {
            if ($carat == 24) {
                continue; // تم إضافته بالفعل
            }
            
            $purity = $carat / 24;
            $price = $gold_oz_gram_price_usd * $purity;
            
            $prices[] = [
                'metal' => 'gold',
                'carat' => $carat . 'k',
                'price_usd' => $price
            ];
        }
        
        infi_gold_log('Successfully fetched gold prices for ' . count($prices) . ' carats from Swissquote API');
        return $prices;
        
    } catch (Exception $e) {
        infi_gold_log('Failed to fetch gold prices from Swissquote API: ' . $e->getMessage(), 'error');
        infi_update_last_update_status('metals_api', 'error', $e->getMessage());
        return false;
    }
}

/**
 * التحقق من صلاحية API الخاص بـ Swissquote
 */
function infi_verify_swissquote_api() {
    try {
        $endpoint = "https://forex-data-feed.swissquote.com/public-quotes/bboquotes/instrument/XAU/USD";
        
        $response = wp_remote_get($endpoint, [
            'timeout' => 30,
            'headers' => [
                'Accept' => 'application/json'
            ]
        ]);
        
        if (is_wp_error($response)) {
            throw new Exception('API request failed: ' . $response->get_error_message());
        }
        
        $status_code = wp_remote_retrieve_response_code($response);
        if ($status_code !== 200) {
            throw new Exception("API returned error status code: $status_code");
        }
        
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        
        if (!is_array($data) || empty($data)) {
            throw new Exception('Invalid response format');
        }
        
        // تحقق من وجود البيانات المطلوبة في الإستجابة
        $valid_data = false;
        foreach ($data as $item) {
            if (isset($item['spreadProfilePrices']) && !empty($item['spreadProfilePrices'])) {
                $valid_data = true;
                break;
            }
        }
        
        if (!$valid_data) {
            throw new Exception('Gold price data not found in API response');
        }
        
        return [
            'status' => 'success',
            'message' => 'Swissquote API connection is valid'
        ];
        
    } catch (Exception $e) {
        infi_gold_log('Swissquote API verification failed: ' . $e->getMessage(), 'error');
        return [
            'status' => 'error',
            'message' => $e->getMessage()
        ];
    }
}

function infi_fetch_gold_prices_metalprice() {
    try {
        $settings = get_option('infi_gold_manager_settings', []);
        $api_key = isset($settings['metalprice_api_key']) ? $settings['metalprice_api_key'] : '';
        
        if (empty($api_key)) {
            throw new Exception('MetalPriceAPI key is missing');
        }
        
        infi_gold_log('Starting to fetch gold prices from MetalPriceAPI');
        
        $carats = [24, 22, 21, 18, 14, 12];
        $prices = [];
        
        $endpoint = "https://api.metalpriceapi.com/v1/latest?api_key={$api_key}&base=USD&currencies=XAU";
        
        $response = wp_remote_get($endpoint, [
            'timeout' => 30,
            'headers' => [
                'Accept' => 'application/json'
            ]
        ]);
        
        if (is_wp_error($response)) {
            throw new Exception('API request failed: ' . $response->get_error_message());
        }
        
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        
        infi_gold_log('MetalPriceAPI Response: ' . print_r($data, true), 'debug');
        
        if (!isset($data['success']) || $data['success'] !== true) {
            $error_message = isset($data['error']['message']) ? $data['error']['message'] : 'Unknown error';
            throw new Exception("API error: $error_message");
        }
        
        if (!isset($data['rates']['XAU'])) {
            throw new Exception('Gold price data not found in API response');
        }
        
        $xau_value = $data['rates']['XAU']; 
       /* 
        $xau_oz_price = 1 / $xau_value;
        
        $usd_usd_rate = infi_get_usd_usd_rate();
        
        $xau_oz_price_usd = $xau_oz_price / $usd_usd_rate;
        
        $xau_gram_price_usd = $xau_oz_price_usd / 31.1034768;
        
        $prices[] = [
            'metal' => 'gold',
            'carat' => '24k_oz',
            'price_usd' => $xau_oz_price_usd 
        ];
        
        $prices[] = [
            'metal' => 'gold',
            'carat' => '24k',
            'price_usd' => $xau_gram_price_usd 
        ];
       */
      $xau_oz_price = 1 / $xau_value; // هذا السعر بالدولار
$xau_gram_price = $xau_oz_price / 31.1034768; // سعر الجرام بالدولار

$prices[] = [
    'metal' => 'gold',
    'carat' => '24k_oz',
    'price_usd' => $xau_oz_price // نستخدم نفس الحقل لكن القيمة الآن بالدولار
];

$prices[] = [
    'metal' => 'gold',
    'carat' => '24k',
    'price_usd' => $xau_gram_price 
]; 
        foreach ($carats as $carat) {
            if ($carat == 24) {
                continue; 
            }
            
            $purity = $carat / 24;
            $price = $xau_gram_price_usd * $purity;
            
            $prices[] = [
                'metal' => 'gold',
                'carat' => $carat . 'k',
                'price_usd' => $price 
            ];
        }
        
        infi_gold_log('Successfully fetched gold prices for ' . count($prices) . ' carats from MetalPriceAPI');
        return $prices;
        
    } catch (Exception $e) {
        infi_gold_log('Failed to fetch gold prices from MetalPriceAPI: ' . $e->getMessage(), 'error');
        infi_update_last_update_status('metals_api', 'error', $e->getMessage());
        return false;
    }
}


function infi_fetch_gold_prices_metals_api() {
    try {
        $settings = get_option('infi_gold_manager_settings', []);
        $api_key = isset($settings['metals_api_key']) ? $settings['metals_api_key'] : '';
        
        if (empty($api_key)) {
            throw new Exception('Metals-API key is missing');
        }
        
        infi_gold_log('Starting to fetch gold prices from Metals-API');
        
        $carats = [24, 22, 21, 18, 14, 12];
        $prices = [];
        
      //  $endpoint = "https://metals-api.com/api/latest?access_key={$api_key}&base=usd&symbols=XAU";
      $endpoint = "https://metals-api.com/api/latest?access_key={$api_key}&base=USD&symbols=XAU";
        $response = wp_remote_get($endpoint, [
            'timeout' => 30,
            'headers' => [
                'Accept' => 'application/json'
            ]
        ]);
        
        if (is_wp_error($response)) {
            throw new Exception('API request failed: ' . $response->get_error_message());
        }
        
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        
        infi_gold_log('Metals API Response: ' . print_r($data, true), 'debug');
        
        if (!isset($data['success']) || $data['success'] !== true) {
            $error_message = isset($data['error']['message']) ? $data['error']['message'] : 'Unknown error';
            throw new Exception("API error: $error_message");
        }
        
        if (!isset($data['rates']['XAU'])) {
            throw new Exception('Gold price data not found in API response');
        }
        
     
        $xau_oz_price = $data['rates']['XAU'];
        
        $xau_gram_price = $xau_oz_price / 31.1034768;
        
        $prices[] = [
            'metal' => 'gold',
            'carat' => '24k_oz',
            'price_usd' => $xau_oz_price 
        ];
        
        $prices[] = [
            'metal' => 'gold',
            'carat' => '24k',
            'price_usd' => $xau_gram_price 
        ];
        
        foreach ($carats as $carat) {
            if ($carat == 24) {
                continue; 
            }
            
            $purity = $carat / 24;
            $price = $xau_gram_price * $purity;
            
            $prices[] = [
                'metal' => 'gold',
                'carat' => $carat . 'k',
                'price_usd' => $price 
            ];
        }
        
        infi_gold_log('Successfully fetched gold prices for ' . count($prices) . ' carats from Metals-API');
        return $prices;
        
    } catch (Exception $e) {
        infi_gold_log('Failed to fetch gold prices from Metals-API: ' . $e->getMessage(), 'error');
        infi_update_last_update_status('metals_api', 'error', $e->getMessage());
        return false;
    }
}


function xxxxxinfi_get_usd_usd_rate() {
    $settings = get_option('infi_gold_manager_settings', []);
    $api_key = isset($settings['exchange_rates_api_key']) ? $settings['exchange_rates_api_key'] : '';
    
    if (empty($api_key)) {
        return 1.1; 
    }
    
    $endpoint = "https://api.exchangeratesapi.io/v1/latest?access_key={$api_key}&base=usd&symbols=USD";
    
    $response = wp_remote_get($endpoint, [
        'timeout' => 30,
        'headers' => [
            'Accept' => 'application/json'
        ]
    ]);
    
    if (is_wp_error($response)) {
        infi_gold_log('Failed to get usd/USD rate: ' . $response->get_error_message(), 'error');
        return 1.1; 
    }
    
    $body = wp_remote_retrieve_body($response);
    $data = json_decode($body, true);
    
    if (!isset($data['success']) || $data['success'] !== true || !isset($data['rates']['USD'])) {
        infi_gold_log('Invalid response for usd/USD rate', 'error');
        return 1.1; 
    }
    
    return $data['rates']['USD'];
}
 function infi_fetch_gold_prices2() {
    try {
        $settings = get_option('infi_gold_manager_settings', []);
        $api_key = isset($settings['metals_api_key']) ? $settings['metals_api_key'] : '';
        
        if (empty($api_key)) {
            throw new Exception('Metals API key is missing');
        }
        
        infi_gold_log('Starting to fetch gold prices from Metals-API');
        
        $carats = [24, 22, 21, 18, 14, 12];
        $prices = [];
        
        $endpoint = "https://metals-api.com/api/latest?access_key={$api_key}&base=usd&symbols=XAU";
        
        $response = wp_remote_get($endpoint, [
            'timeout' => 30,
            'headers' => [
                'Accept' => 'application/json'
            ]
        ]);
        
        if (is_wp_error($response)) {
            throw new Exception('API request failed: ' . $response->get_error_message());
        }
        
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        
        infi_gold_log('Metals API Response: ' . print_r($data, true), 'debug');
        
        if (!isset($data['success']) || $data['success'] !== true) {
            $error_message = isset($data['error']['message']) ? $data['error']['message'] : 'Unknown error';
            throw new Exception("API error: $error_message");
        }
        
        if (!isset($data['rates']['XAU'])) {
            throw new Exception('Gold price data not found in API response');
        }
       
        $xau_oz_price = $data['rates']['XAU'];
        
        $xau_gram_price = $xau_oz_price / 31.1034768;
        
        $prices[] = [
            'metal' => 'gold',
            'carat' => '24k_oz',
            'price_usd' => $xau_oz_price 
        ];
        
        $prices[] = [
            'metal' => 'gold',
            'carat' => '24k',
            'price_usd' => $xau_gram_price 
        ];
        
        foreach ($carats as $carat) {
            if ($carat == 24) {
                continue; 
            }
            
            $purity = $carat / 24;
            $price = $xau_gram_price * $purity;
            
            $prices[] = [
                'metal' => 'gold',
                'carat' => $carat . 'k',
                'price_usd' => $price 
            ];
        }
        
        infi_gold_log('Successfully fetched gold prices for ' . count($prices) . ' carats');
        return $prices;
        
    } catch (Exception $e) {
        infi_gold_log('Failed to fetch gold prices: ' . $e->getMessage(), 'error');
        infi_update_last_update_status('metals_api', 'error', $e->getMessage());
        return false;
    }
}

function infi_fetch_currency_ratess() {
    try {
        $settings = get_option('infi_gold_manager_settings', []);
        $api_key = isset($settings['exchange_rates_api_key']) ? $settings['exchange_rates_api_key'] : '';
        
        if (empty($api_key)) {
            throw new Exception('Exchange Rates API key is missing');
        }
        
        infi_gold_log('Starting to fetch currency rates from ExchangeRatesAPI');
        
        $endpoint = "https://api.exchangeratesapi.io/v1/latest?access_key={$api_key}&base=usd";
        
        $response = wp_remote_get($endpoint, [
            'timeout' => 30,
            'headers' => [
                'Accept' => 'application/json'
            ]
        ]);
        
        if (is_wp_error($response)) {
            throw new Exception('API request failed: ' . $response->get_error_message());
        }
        
        $status_code = wp_remote_retrieve_response_code($response);
        if ($status_code !== 200) {
            throw new Exception("API returned error status code: $status_code");
        }
        
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        
        infi_gold_log('Exchange Rates API Response: ' . print_r($data, true), 'debug');
        
        if (!isset($data['success']) || $data['success'] !== true) {
            $error_message = isset($data['error']['message']) ? $data['error']['message'] : 'Unknown error';
            throw new Exception("API error: $error_message");
        }
        
        if (!isset($data['rates']) || !is_array($data['rates'])) {
            throw new Exception('Currency rates data not found in API response');
        }
        
        $data['rates']['usd'] = 1.0;
        
        infi_gold_log('Successfully fetched currency rates for ' . count($data['rates']) . ' currencies');
        return $data['rates'];
        
    } catch (Exception $e) {
        infi_gold_log('Failed to fetch currency rates: ' . $e->getMessage(), 'error');
        infi_update_last_update_status('exchange_rates_api', 'error', $e->getMessage());
        return false;
    }
}


function infi_verify_metals_api_key2($api_key) {
    try {
        if (empty($api_key)) {
            throw new Exception('API key is empty');
        }
        
        $endpoint = "https://metals-api.com/api/latest?access_key={$api_key}&base=USD&symbols=XAU";
        
        $response = wp_remote_get($endpoint, [
            'timeout' => 30,
            'headers' => [
                'Accept' => 'application/json'
            ]
        ]);
        
        if (is_wp_error($response)) {
            throw new Exception('API request failed: ' . $response->get_error_message());
        }
        
        $status_code = wp_remote_retrieve_response_code($response);
        if ($status_code !== 200) {
            throw new Exception("API returned error status code: $status_code");
        }
        
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        
        if (!isset($data['success']) || $data['success'] !== true) {
            $error_message = isset($data['error']['message']) ? $data['error']['message'] : 'Unknown error';
            throw new Exception("API error: $error_message");
        }
        
        return [
            'status' => 'success',
            'message' => 'API key is valid'
        ];
        
    } catch (Exception $e) {
        infi_gold_log('Metals API key verification failed: ' . $e->getMessage(), 'error');
        return [
            'status' => 'error',
            'message' => $e->getMessage()
        ];
    }
}

function infi_verify_metals_api_key($api_key) {
    try {
        if (empty($api_key)) {
            throw new Exception('API key is empty');
        }
        
        $endpoint = "https://api.metalpriceapi.com/v1/latest?api_key={$api_key}&base=USD&currencies=XAU";
        
        $response = wp_remote_get($endpoint, [
            'timeout' => 30,
            'headers' => [
                'Accept' => 'application/json'
            ]
        ]);
        
        if (is_wp_error($response)) {
            throw new Exception('API request failed: ' . $response->get_error_message());
        }
        
        $status_code = wp_remote_retrieve_response_code($response);
        if ($status_code !== 200) {
            throw new Exception("API returned error status code: $status_code");
        }
        
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        
        if (!isset($data['success']) || $data['success'] !== true) {
            $error_message = isset($data['error']['message']) ? $data['error']['message'] : 'Unknown error';
            throw new Exception("API error: $error_message");
        }
        
        return [
            'status' => 'success',
            'message' => 'API key is valid'
        ];
        
    } catch (Exception $e) {
        infi_gold_log('MetalPriceAPI key verification failed: ' . $e->getMessage(), 'error');
        return [
            'status' => 'error',
            'message' => $e->getMessage()
        ];
    }
}

function infi_verify_exchange_rates_api_key($api_key) {
    try {
        if (empty($api_key)) {
            throw new Exception('API key is empty');
        }
        
        $endpoint = "https://api.exchangeratesapi.io/v1/latest?access_key={$api_key}";
        
        $response = wp_remote_get($endpoint, [
            'timeout' => 30,
            'headers' => [
                'Accept' => 'application/json'
            ]
        ]);
        
        if (is_wp_error($response)) {
            throw new Exception('API request failed: ' . $response->get_error_message());
        }
        
        $status_code = wp_remote_retrieve_response_code($response);
        if ($status_code !== 200) {
            throw new Exception("API returned error status code: $status_code");
        }
        
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        
        if (!isset($data['success']) || $data['success'] !== true) {
            $error_message = isset($data['error']['message']) ? $data['error']['message'] : 'Unknown error';
            throw new Exception("API error: $error_message");
        }
        
        return [
            'status' => 'success',
            'message' => 'API key is valid'
        ];
        
    } catch (Exception $e) {
        infi_gold_log('Exchange Rates API key verification failed: ' . $e->getMessage(), 'error');
        return [
            'status' => 'error',
            'message' => $e->getMessage()
        ];
    }
}


// في دالة infi_update_gold_prices
function infi_update_gold_prices() {
    try {
        infi_gold_log('Starting gold prices update process');
        
        // إضافة تأخير قبل الطلب
        sleep(2); // انتظار ثانيتين
        
        $prices = infi_fetch_gold_prices();
        
        if ($prices === false || empty($prices)) {
            throw new Exception('Failed to fetch gold prices or no data received');
        }
        
        $result = infi_save_gold_prices($prices);
        
        if ($result === false) {
            throw new Exception('Failed to save gold prices to database');
        }
        
        infi_clear_cache();
        
        infi_gold_log('Gold prices updated successfully');
        return true;
        
    } catch (Exception $e) {
        infi_gold_log('Error updating gold prices: ' . $e->getMessage(), 'error');
        return false;
    }
}


function infi_update_currency_rates() {
    try {
        infi_gold_log('Starting currency rates update process');
        
        $rates = infi_fetch_currency_rates();
        
        if ($rates === false || empty($rates)) {
            throw new Exception('Failed to fetch currency rates or no data received');
        }
        
        $result = infi_save_currency_rates($rates);
        
        if ($result === false) {
            throw new Exception('Failed to save currency rates to database');
        }
        
        infi_clear_cache();
        
        infi_gold_log('Currency rates updated successfully');
        return true;
        
    } catch (Exception $e) {
        infi_gold_log('Error updating currency rates: ' . $e->getMessage(), 'error');
        return false;
    }
}
function infi_convert_gold_price_to_currency($price_usd, $currency_code) {
    try {
        // قيمة price_usd (المخزنة في price_usd) هي فعلياً بالدولار
        if ($currency_code === 'USD') {
            return $price_usd;
        }
        
        $cache_key = 'infi_gold_currency_rates';
        $currency_rates = infi_get_cached_data($cache_key, 'infi_get_latest_currency_rates');
        
        if (empty($currency_rates) || !isset($currency_rates[$currency_code])) {
            infi_gold_log("Currency rate not found for $currency_code", 'warning');
            return null;
        }
        
        // الحصول على معدل تحويل الدولار وتحويله بشكل مناسب
        $usd_rate = isset($currency_rates['USD']) ? $currency_rates['USD'] : 1.0;
        $target_currency_rate = $currency_rates[$currency_code];
        
        // حساب نسبة التحويل من الدولار إلى العملة المطلوبة
        $conversion_rate = $target_currency_rate / $usd_rate;
        
        return $price_usd * $conversion_rate;
        
    } catch (Exception $e) {
        infi_gold_log('Error converting gold price: ' . $e->getMessage(), 'error');
        return null;
    }
}