<?php
/**
 * لوحة التحكم الإدارية للإضافة
 * Path: /admin.php
 */

// منع الوصول المباشر
if (!defined('ABSPATH')) {
    exit;
}

/**
 * إضافة قائمة الإدارة
 */
function infi_gold_manager_admin_menu() {
    add_menu_page(
        __('Gold Manager', 'infi-gold-manager'),
        __('Gold Manager', 'infi-gold-manager'),
        'edit_posts', // تغيير من 'manage_options' إلى 'edit_posts'
        'infi-gold-manager', // هذا هو مُعرف القائمة
        'infi_gold_manager_settings_page',
        'dashicons-money-alt',
        30
    );
    add_submenu_page(
        'infi-gold-manager',
        __('صفحات الإضافة', 'infi-gold-manager'),
        __('صفحات الإضافة', 'infi-gold-manager'),
        'edit_posts',
        'infi-gold-pages',
        'infi_gold_manager_pages_page'
    );

    add_submenu_page(
        'infi-gold-manager',
        __('تقرير البيانات', 'infi-gold-manager'),
        __('تقرير البيانات', 'infi-gold-manager'),
        'edit_posts',
        'infi-gold-data-report',
        'infi_gold_manager_data_report_page'
    );
    add_submenu_page(
        'infi-gold-manager',
        __('Settings', 'infi-gold-manager'),
        __('Settings', 'infi-gold-manager'),
        'edit_posts', // تغيير من 'manage_options' إلى 'edit_posts'
        'infi-gold-manager',
        'infi_gold_manager_settings_page'
    );
    
    add_submenu_page(
        'infi-gold-manager',
        __('Markup Settings', 'infi-gold-manager'),
        __('Markup Settings', 'infi-gold-manager'),
        'edit_posts', // تغيير من 'manage_options' إلى 'edit_posts'
        'infi-gold-markup',
        'infi_gold_manager_markup_page'
    );
    
    add_submenu_page(
        'infi-gold-manager',
        __('Gold Prices', 'infi-gold-manager'),
        __('Gold Prices', 'infi-gold-manager'),
        'edit_posts', // تغيير من 'manage_options' إلى 'edit_posts'
        'infi-gold-prices',
        'infi_gold_manager_prices_page'
    );
    add_submenu_page(
        'infi-gold-manager',
        __('Historical Data', 'infi-gold-manager'),
        __('Historical Data', 'infi-gold-manager'),
        'edit_posts', // تغيير من 'manage_options' إلى 'edit_posts'
        'infi-gold-historical',
        'infi_gold_manager_historical_page'
    );
    add_submenu_page(
        'infi-gold-manager',
        __('Logs', 'infi-gold-manager'),
        __('Logs', 'infi-gold-manager'),
        'edit_posts', // تغيير من 'manage_options' إلى 'edit_posts'
        'infi-gold-logs',
        'infi_gold_manager_logs_page'
    );
    
    add_submenu_page(
        'infi-gold-manager',
        __('Shortcodes', 'infi-gold-manager'),
        __('Shortcodes', 'infi-gold-manager'),
        'edit_posts', // تغيير من 'manage_options' إلى 'edit_posts'
        'infi-gold-shortcodes',
        'infi_gold_manager_shortcodes_page'
    );

    add_submenu_page(
        'infi-gold-manager',
        __('Technical Support', 'infi-gold-manager'),
        __('Technical Support', 'infi-gold-manager'),
        'edit_posts', // صلاحيات الوصول
        'infi-gold-support',
        'infi_gold_manager_support_page'
    );
    
}

function infi_gold_manager_support_page() {
    ?>
    <div class="wrap">
        <h1><?php _e('Technical Support', 'infi-gold-manager'); ?></h1>
        <p><?php _e('If you need help, please contact our support team.', 'infi-gold-manager'); ?></p>

        <h2><?php _e('Contact Support', 'infi-gold-manager'); ?></h2>
        <p><?php _e('For technical support or to develop this plugin, please contact us on our website or via WhatsApp.', 'infi-gold-manager'); ?></p>
        <p>
            🔗 <a href="https://www.infinyteam.com/" target="_blank">www.infinyteam.com</a>
        </p>

       

        <hr>
        <p style="font-size: 14px; color: gray;">
            <?php _e('This plugin is developed and maintained by InfinyTeam.', 'infi-gold-manager'); ?>
        </p>
    </div>
    <?php
}


/**
 * صفحة إعدادات Gold Manager الرئيسية
 */
function infi_gold_manager_settings_page() {
    // التحقق من وجود رسالة تأكيد أو خطأ
    $message = '';
    $error = '';

    // معالجة طلب حفظ الإعدادات
    if (isset($_POST['infi_gold_manager_save_settings']) && check_admin_referer('infi_gold_manager_settings_nonce')) {
        try {
            // جمع البيانات من النموذج
            $settings = [
                'metals_api_key' => sanitize_text_field($_POST['metals_api_key']),
                'metalprice_api_key' => sanitize_text_field($_POST['metalprice_api_key']),
                'exchange_rates_api_key' => sanitize_text_field($_POST['exchange_rates_api_key']),
                'gold_update_interval' => absint($_POST['gold_update_interval']),
                'currency_update_interval' => absint($_POST['currency_update_interval']),
                'cron_type' => sanitize_text_field($_POST['cron_type']),
                'default_buy_percentage' => floatval($_POST['default_buy_percentage']),
                'default_sell_percentage' => floatval($_POST['default_sell_percentage']),
                'cache_duration' => absint($_POST['cache_duration']),
                'default_currency' => sanitize_text_field($_POST['default_currency']),
                'user_country_detection' => sanitize_text_field($_POST['user_country_detection']),
                'default_country_code' => sanitize_text_field(strtolower($_POST['default_country_code'])),
                'api_provider' => sanitize_text_field($_POST['api_provider']),
                'currency_api_provider' => sanitize_text_field($_POST['currency_api_provider'])
            ];
            
            // التحقق من صحة البيانات
            if ($settings['gold_update_interval'] < 5) {
                $settings['gold_update_interval'] = 5;
            }
            
            if ($settings['currency_update_interval'] < 5) {
                $settings['currency_update_interval'] = 5;
            }
            
            if ($settings['cache_duration'] < 1) {
                $settings['cache_duration'] = 1;
            }
            
            // حفظ الإعدادات المحدّثة
            update_option('infi_gold_manager_settings', $settings);
            
            // إعادة إعداد جدولة Cron
            infi_clear_cron_schedules();
            infi_setup_cron_schedules();
            
            // مسح التخزين المؤقت
            infi_clear_cache();
            
            infi_gold_log('Settings saved successfully');
            
            $message = __('تم حفظ الإعدادات بنجاح.', 'infi-gold-manager');
        } catch (Exception $e) {
            infi_gold_log('Error saving settings: ' . $e->getMessage(), 'error');
            $error = __('حدث خطأ أثناء حفظ الإعدادات:', 'infi-gold-manager') . ' ' . $e->getMessage();
        }
    }
    
    // التحقق من صلاحية مفاتيح API
    $metals_api_result = null;
    $metalprice_api_result = null;
    $exchange_rates_api_result = null;
    $swissquote_api_result = null;
    
    if (isset($_POST['verify_metals_api']) && check_admin_referer('infi_gold_manager_settings_nonce')) {
        $api_key = sanitize_text_field($_POST['metals_api_key']);
        $metals_api_result = infi_verify_metals_api_key2($api_key);
    }
    
    if (isset($_POST['verify_metalprice_api']) && check_admin_referer('infi_gold_manager_settings_nonce')) {
        $api_key = sanitize_text_field($_POST['metalprice_api_key']);
        $metalprice_api_result = infi_verify_metals_api_key($api_key);
    }
    
    if (isset($_POST['verify_exchange_rates_api']) && check_admin_referer('infi_gold_manager_settings_nonce')) {
        $api_key = sanitize_text_field($_POST['exchange_rates_api_key']);
        $exchange_rates_api_result = infi_verify_exchange_rates_api_key($api_key);
    }

    if (isset($_POST['verify_swissquote_api']) && check_admin_referer('infi_gold_manager_settings_nonce')) {
        $swissquote_api_result = infi_verify_swissquote_api();
    }
    
    if (isset($_POST['verify_open_er_api']) && check_admin_referer('infi_gold_manager_settings_nonce')) {
        $open_er_api_result = infi_verify_open_er_api();
    }
    
    // تحديث البيانات يدوياً
    if (isset($_POST['update_gold_prices']) && check_admin_referer('infi_gold_manager_settings_nonce')) {
        $result = infi_update_gold_prices();
        if ($result) {
            $message = __('تم تحديث أسعار الذهب بنجاح.', 'infi-gold-manager');
        } else {
            $error = __('فشل تحديث أسعار الذهب. تحقق من سجلات الأخطاء للتفاصيل.', 'infi-gold-manager');
        }
    }
    
    if (isset($_POST['update_currency_rates']) && check_admin_referer('infi_gold_manager_settings_nonce')) {
        $result = infi_update_currency_rates();
        if ($result) {
            $message = __('تم تحديث أسعار العملات بنجاح.', 'infi-gold-manager');
        } else {
            $error = __('فشل تحديث أسعار العملات. تحقق من سجلات الأخطاء للتفاصيل.', 'infi-gold-manager');
        }
    }
    
    // الحصول على الإعدادات الحالية
    $settings = get_option('infi_gold_manager_settings', []);
    $metals_api_key = isset($settings['metals_api_key']) ? $settings['metals_api_key'] : '';
    $metalprice_api_key = isset($settings['metalprice_api_key']) ? $settings['metalprice_api_key'] : '';
    $exchange_rates_api_key = isset($settings['exchange_rates_api_key']) ? $settings['exchange_rates_api_key'] : '';
    $gold_update_interval = isset($settings['gold_update_interval']) ? $settings['gold_update_interval'] : 60;
    $currency_update_interval = isset($settings['currency_update_interval']) ? $settings['currency_update_interval'] : 60;
    $cron_type = isset($settings['cron_type']) ? $settings['cron_type'] : 'wp_cron';
    $default_buy_percentage = isset($settings['default_buy_percentage']) ? $settings['default_buy_percentage'] : 1.5;
    $default_sell_percentage = isset($settings['default_sell_percentage']) ? $settings['default_sell_percentage'] : 2.5;
    $cache_duration = isset($settings['cache_duration']) ? $settings['cache_duration'] : 30;
    $default_currency = isset($settings['default_currency']) ? $settings['default_currency'] : 'USD';
    $api_provider = isset($settings['api_provider']) ? $settings['api_provider'] : 'metalprice';
    $user_country_detection = isset($settings['user_country_detection']) ? $settings['user_country_detection'] : 'cloudflare';
    $default_country_code = isset($settings['default_country_code']) ? $settings['default_country_code'] : 'eg';
    $currency_api_provider = isset($settings['currency_api_provider']) ? $settings['currency_api_provider'] : 'exchangeratesapi';

    // الحصول على آخر تحديث للبيانات
    $metals_api_status = infi_get_api_status('metals_api');
    $exchange_rates_api_status = infi_get_api_status('exchange_rates_api');

    // عرض الرسائل
    if (!empty($message)) {
        echo '<div class="notice notice-success is-dismissible"><p>' . esc_html($message) . '</p></div>';
    }
    
    if (!empty($error)) {
        echo '<div class="notice notice-error is-dismissible"><p>' . esc_html($error) . '</p></div>';
    }

    // عرض النموذج
    ?>
    <div class="wrap">
        <h1><?php echo esc_html__('Gold Manager Settings', 'infi-gold-manager'); ?></h1>
        
        <form method="post" action="">
            <?php wp_nonce_field('infi_gold_manager_settings_nonce'); ?>
            
            <div class="card" style="max-width: 800px; margin-top: 20px; padding: 20px; background: #fff; border: 1px solid #ccd0d4; border-radius: 4px; box-shadow: 0 1px 1px rgba(0,0,0,.04);">
                <h2><?php echo esc_html__('API Providers Settings', 'infi-gold-manager'); ?></h2>
                
                <!-- إعدادات كشف الدولة -->
                <h3><?php echo esc_html__('Country Detection Settings', 'infi-gold-manager'); ?></h3>
                <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label for="user_country_detection"><?php echo esc_html__('User Country Detection Method', 'infi-gold-manager'); ?></label>
                        </th>
                        <td>
                            <select name="user_country_detection" id="user_country_detection">
                                <option value="cloudflare" <?php selected($user_country_detection, 'cloudflare'); ?>><?php echo esc_html__('Automatic (Cloudflare)', 'infi-gold-manager'); ?></option>
                                <option value="manual" <?php selected($user_country_detection, 'manual'); ?>><?php echo esc_html__('Manual (Default Country)', 'infi-gold-manager'); ?></option>
                            </select>
                            <p class="description"><?php echo esc_html__('Choose how to detect user\'s country. Automatic requires Cloudflare integration.', 'infi-gold-manager'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="default_country_code"><?php echo esc_html__('Default Country Code', 'infi-gold-manager'); ?></label>
                        </th>
                        <td>
                            <input type="text" name="default_country_code" id="default_country_code" value="<?php echo esc_attr($default_country_code); ?>" class="regular-text" placeholder="eg">
                            <p class="description"><?php echo esc_html__('Enter the 2-letter country code (e.g. sa for Saudi Arabia, ae for UAE, eg for Egypt)', 'infi-gold-manager'); ?></p>
                            <p class="description"><?php echo esc_html__('Common codes: sa, ae, kw, qa, bh, om, eg, ma, dz, tn, ly, jo, lb, iq, tr', 'infi-gold-manager'); ?></p>
                        </td>
                    </tr>
                </table>

                <!-- إعدادات مزود API للذهب -->
                <h3><?php echo esc_html__('Gold API Provider', 'infi-gold-manager'); ?></h3>
                <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label for="api_provider"><?php echo esc_html__('Gold Data Source', 'infi-gold-manager'); ?></label>
                        </th>
                        <td>
                            <select name="api_provider" id="api_provider" class="api-provider-select">
                                <option value="metalprice" <?php selected($api_provider, 'metalprice'); ?>><?php echo esc_html__('MetalPriceAPI (requires API key)', 'infi-gold-manager'); ?></option>
                                <option value="metals-api" <?php selected($api_provider, 'metals-api'); ?>><?php echo esc_html__('Metals-API (requires API key)', 'infi-gold-manager'); ?></option>
                                <option value="swissquote" <?php selected($api_provider, 'swissquote'); ?>><?php echo esc_html__('Swissquote (free, no API key needed)', 'infi-gold-manager'); ?></option>
                            </select>
                            <p class="description"><?php echo esc_html__('Select which API provider to use for gold prices.', 'infi-gold-manager'); ?></p>
                        </td>
                    </tr>
                </table>

                <!-- إعدادات خاصة بمزود MetalPriceAPI -->
                <div class="api-settings metalprice-api-settings" <?php echo $api_provider !== 'metalprice' ? 'style="display:none;"' : ''; ?>>
                    <table class="form-table">
                        <tr>
                            <th scope="row">
                                <label for="metalprice_api_key"><?php echo esc_html__('MetalPriceAPI Key', 'infi-gold-manager'); ?></label>
                            </th>
                            <td>
                                <input type="text" name="metalprice_api_key" id="metalprice_api_key" value="<?php echo esc_attr($metalprice_api_key); ?>" class="regular-text">
                                <p class="description">
                                    <a href="https://metalpriceapi.com/signup" target="_blank"><?php echo esc_html__('Get MetalPriceAPI Key', 'infi-gold-manager'); ?></a>
                                </p>
                                <button type="submit" name="verify_metalprice_api" class="button button-secondary"><?php echo esc_html__('Verify Key', 'infi-gold-manager'); ?></button>
                                <?php if ($metalprice_api_result): ?>
                                    <p class="<?php echo $metalprice_api_result['status'] === 'success' ? 'notice-success' : 'notice-error'; ?>" style="padding: 10px; margin-top: 10px;">
                                        <?php echo esc_html($metalprice_api_result['message']); ?>
                                    </p>
                                <?php endif; ?>
                            </td>
                        </tr>
                    </table>
                </div>
                
                <!-- إعدادات خاصة بمزود Metals-API -->
                <div class="api-settings metals-api-settings" <?php echo $api_provider !== 'metals-api' ? 'style="display:none;"' : ''; ?>>
                    <table class="form-table">
                        <tr>
                            <th scope="row">
                                <label for="metals_api_key"><?php echo esc_html__('Metals-API Key', 'infi-gold-manager'); ?></label>
                            </th>
                            <td>
                                <input type="text" name="metals_api_key" id="metals_api_key" value="<?php echo esc_attr($metals_api_key); ?>" class="regular-text">
                                <p class="description">
                                    <a href="https://metals-api.com/signup" target="_blank"><?php echo esc_html__('Get Metals-API Key', 'infi-gold-manager'); ?></a>
                                </p>
                                <button type="submit" name="verify_metals_api" class="button button-secondary"><?php echo esc_html__('Verify Key', 'infi-gold-manager'); ?></button>
                                <?php if ($metals_api_result): ?>
                                    <p class="<?php echo $metals_api_result['status'] === 'success' ? 'notice-success' : 'notice-error'; ?>" style="padding: 10px; margin-top: 10px;">
                                        <?php echo esc_html($metals_api_result['message']); ?>
                                    </p>
                                <?php endif; ?>
                            </td>
                        </tr>
                    </table>
                </div>

                <!-- إعدادات خاصة بمزود Swissquote -->
                <div class="api-settings swissquote-api-settings" <?php echo $api_provider !== 'swissquote' ? 'style="display:none;"' : ''; ?>>
                    <table class="form-table">
                        <tr>
                            <th scope="row">
                                <label><?php echo esc_html__('Swissquote API', 'infi-gold-manager'); ?></label>
                            </th>
                            <td>
                                <p class="description">
                                    <?php echo esc_html__('Swissquote API does not require an API key.', 'infi-gold-manager'); ?>
                                </p>
                                <button type="submit" name="verify_swissquote_api" class="button button-secondary"><?php echo esc_html__('Verify Connection', 'infi-gold-manager'); ?></button>
                                <?php if ($swissquote_api_result): ?>
                                    <p class="<?php echo $swissquote_api_result['status'] === 'success' ? 'notice-success' : 'notice-error'; ?>" style="padding: 10px; margin-top: 10px;">
                                        <?php echo esc_html($swissquote_api_result['message']); ?>
                                    </p>
                                <?php endif; ?>
                            </td>
                        </tr>
                    </table>
                </div>

                <!-- إعدادات مزود API للعملات -->
                <h3><?php echo esc_html__('Currency API Provider', 'infi-gold-manager'); ?></h3>
                <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label for="currency_api_provider"><?php echo esc_html__('Currency Exchange API', 'infi-gold-manager'); ?></label>
                        </th>
                        <td>
                            <select name="currency_api_provider" id="currency_api_provider" class="currency-api-provider-select">
                                <option value="exchangeratesapi" <?php selected($currency_api_provider, 'exchangeratesapi'); ?>><?php echo esc_html__('ExchangeRatesAPI (requires API key)', 'infi-gold-manager'); ?></option>
                                <option value="exchangerate-api" <?php selected($currency_api_provider, 'exchangerate-api'); ?>><?php echo esc_html__('ExchangeRate-API (free, no API key needed)', 'infi-gold-manager'); ?></option>
                            </select>
                            <p class="description"><?php echo esc_html__('Select which API provider to use for currency exchange rates.', 'infi-gold-manager'); ?></p>
                        </td>
                    </tr>
                </table>

                <!-- إعدادات خاصة بمزود ExchangeRatesAPI -->
                <div class="currency-api-settings exchangeratesapi-settings" <?php echo $currency_api_provider !== 'exchangeratesapi' ? 'style="display:none;"' : ''; ?>>
                    <table class="form-table">
                        <tr>
                            <th scope="row">
                                <label for="exchange_rates_api_key"><?php echo esc_html__('ExchangeRatesAPI Key', 'infi-gold-manager'); ?></label>
                            </th>
                            <td>
                                <input type="text" name="exchange_rates_api_key" id="exchange_rates_api_key" value="<?php echo esc_attr($exchange_rates_api_key); ?>" class="regular-text">
                                <p class="description">
                                    <a href="https://exchangeratesapi.io/pricing/" target="_blank"><?php echo esc_html__('Get ExchangeRatesAPI Key', 'infi-gold-manager'); ?></a>
                                </p>
                                <button type="submit" name="verify_exchange_rates_api" class="button button-secondary"><?php echo esc_html__('Verify Key', 'infi-gold-manager'); ?></button>
                                <?php if ($exchange_rates_api_result): ?>
                                    <p class="<?php echo $exchange_rates_api_result['status'] === 'success' ? 'notice-success' : 'notice-error'; ?>" style="padding: 10px; margin-top: 10px;">
                                        <?php echo esc_html($exchange_rates_api_result['message']); ?>
                                    </p>
                                <?php endif; ?>
                            </td>
                        </tr>
                    </table>
                </div>

                <!-- إعدادات خاصة بمزود ExchangeRate-API -->
                <div class="currency-api-settings exchangerate-api-settings" <?php echo $currency_api_provider !== 'exchangerate-api' ? 'style="display:none;"' : ''; ?>>
                    <table class="form-table">
                        <tr>
                            <th scope="row">
                                <label><?php echo esc_html__('ExchangeRate-API', 'infi-gold-manager'); ?></label>
                            </th>
                            <td>
                                <p class="description">
                                    <?php echo esc_html__('ExchangeRate-API does not require an API key.', 'infi-gold-manager'); ?>
                                </p>
                                <button type="submit" name="verify_open_er_api" class="button button-secondary"><?php echo esc_html__('Verify Connection', 'infi-gold-manager'); ?></button>
                                <?php 
                                if (isset($open_er_api_result)): ?>
                                    <p class="<?php echo $open_er_api_result['status'] === 'success' ? 'notice-success' : 'notice-error'; ?>" style="padding: 10px; margin-top: 10px;">
                                        <?php echo esc_html($open_er_api_result['message']); ?>
                                    </p>
                                <?php endif; ?>
                            </td>
                        </tr>
                    </table>
                </div>

                <!-- إعدادات التحديث -->
                <h2><?php echo esc_html__('Update Settings', 'infi-gold-manager'); ?></h2>
                <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label for="gold_update_interval"><?php echo esc_html__('Gold Price Update Interval', 'infi-gold-manager'); ?></label>
                        </th>
                        <td>
                            <input type="number" name="gold_update_interval" id="gold_update_interval" value="<?php echo esc_attr($gold_update_interval); ?>" min="5" class="small-text"> <?php echo esc_html__('minutes', 'infi-gold-manager'); ?>
                            <p class="description"><?php echo esc_html__('How often to fetch gold prices from API (minimum 5 minutes).', 'infi-gold-manager'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="currency_update_interval"><?php echo esc_html__('Currency Rates Update Interval', 'infi-gold-manager'); ?></label>
                        </th>
                        <td>
                            <input type="number" name="currency_update_interval" id="currency_update_interval" value="<?php echo esc_attr($currency_update_interval); ?>" min="5" class="small-text"> <?php echo esc_html__('minutes', 'infi-gold-manager'); ?>
                            <p class="description"><?php echo esc_html__('How often to fetch currency rates from API (minimum 5 minutes).', 'infi-gold-manager'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="cron_type"><?php echo esc_html__('CRON Type', 'infi-gold-manager'); ?></label>
                        </th>
                        <td>
                            <select name="cron_type" id="cron_type">
                                <option value="wp_cron" <?php selected($cron_type, 'wp_cron'); ?>><?php echo esc_html__('WordPress CRON', 'infi-gold-manager'); ?></option>
                                <option value="external" <?php selected($cron_type, 'external'); ?>><?php echo esc_html__('External CRON', 'infi-gold-manager'); ?></option>
                            </select>
                            <p class="description">
                                <?php echo esc_html__('Use external CRON for better reliability.', 'infi-gold-manager'); ?>
                                <?php if ($cron_type === 'external'): ?>
                                    <br>
                                    <?php echo esc_html__('External CRON URL:', 'infi-gold-manager'); ?> 
                                    <code><?php echo esc_url(site_url('?infi_gold_cron=1&token=' . md5(AUTH_KEY))); ?></code>
                                <?php endif; ?>
                            </p>
                        </td>
                    </tr>
                </table>

            <!-- إعدادات افتراضية -->
            <h2><?php echo esc_html__('Default Settings', 'infi-gold-manager'); ?></h2>
                <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label for="default_currency"><?php echo esc_html__('Default Currency', 'infi-gold-manager'); ?></label>
                        </th>
                        <td>
                        <select name="default_currency" id="default_currency">
                            <!-- العملات العربية -->
                            <option value="AED" <?php selected($default_currency, 'AED'); ?>>AED (درهم إماراتي)</option>
                            <option value="SAR" <?php selected($default_currency, 'SAR'); ?>>SAR (ريال سعودي)</option>
                            <option value="EGP" <?php selected($default_currency, 'EGP'); ?>>EGP (جنيه مصري)</option>
                            <option value="KWD" <?php selected($default_currency, 'KWD'); ?>>KWD (دينار كويتي)</option>
                            <option value="QAR" <?php selected($default_currency, 'QAR'); ?>>QAR (ريال قطري)</option>
                            <option value="BHD" <?php selected($default_currency, 'BHD'); ?>>BHD (دينار بحريني)</option>
                            <option value="OMR" <?php selected($default_currency, 'OMR'); ?>>OMR (ريال عماني)</option>
                            <option value="JOD" <?php selected($default_currency, 'JOD'); ?>>JOD (دينار أردني)</option>
                            <option value="LBP" <?php selected($default_currency, 'LBP'); ?>>LBP (ليرة لبنانية)</option>
                            <option value="SYP" <?php selected($default_currency, 'SYP'); ?>>SYP (ليرة سورية)</option>
                            <option value="YER" <?php selected($default_currency, 'YER'); ?>>YER (ريال يمني)</option>
                            <option value="IQD" <?php selected($default_currency, 'IQD'); ?>>IQD (دينار عراقي)</option>
                            <option value="LYD" <?php selected($default_currency, 'LYD'); ?>>LYD (دينار ليبي)</option>
                            <option value="SDG" <?php selected($default_currency, 'SDG'); ?>>SDG (جنيه سوداني)</option>
                            <option value="TND" <?php selected($default_currency, 'TND'); ?>>TND (دينار تونسي)</option>
                            <option value="DZD" <?php selected($default_currency, 'DZD'); ?>>DZD (دينار جزائري)</option>
                            <option value="MAD" <?php selected($default_currency, 'MAD'); ?>>MAD (درهم مغربي)</option>
                            <option value="MRO" <?php selected($default_currency, 'MRO'); ?>>MRO (أوقية موريتانية)</option>
                            <option value="ILS" <?php selected($default_currency, 'ILS'); ?>>ILS (العملة الفلسطينية - شيكل)</option>
                            
                      <!-- العملات العالمية الأخرى -->
                      <option value="USD" <?php selected($default_currency, 'USD'); ?>>USD (دولار أمريكي)</option>
                            <option value="EUR" <?php selected($default_currency, 'EUR'); ?>>EUR (يورو)</option>
                            <option value="GBP" <?php selected($default_currency, 'GBP'); ?>>GBP (جنيه إسترليني)</option>
                        </select>
                            <p class="description"><?php echo esc_html__('Default currency to display gold prices.', 'infi-gold-manager'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="default_buy_percentage"><?php echo esc_html__('Default Buy Markup', 'infi-gold-manager'); ?></label>
                        </th>
                        <td>
                            <input type="number" step="0.01" name="default_buy_percentage" id="default_buy_percentage" value="<?php echo esc_attr($default_buy_percentage); ?>" class="small-text"> %
                            <p class="description"><?php echo esc_html__('Default percentage to add for buy price.', 'infi-gold-manager'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="default_sell_percentage"><?php echo esc_html__('Default Sell Markup', 'infi-gold-manager'); ?></label>
                        </th>
                        <td>
                            <input type="number" step="0.01" name="default_sell_percentage" id="default_sell_percentage" value="<?php echo esc_attr($default_sell_percentage); ?>" class="small-text"> %
                            <p class="description"><?php echo esc_html__('Default percentage to add for sell price.', 'infi-gold-manager'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="cache_duration"><?php echo esc_html__('Cache Duration', 'infi-gold-manager'); ?></label>
                        </th>
                        <td>
                            <input type="number" name="cache_duration" id="cache_duration" value="<?php echo esc_attr($cache_duration); ?>" min="1" class="small-text"> <?php echo esc_html__('minutes', 'infi-gold-manager'); ?>
                            <p class="description"><?php echo esc_html__('How long to cache data to reduce database queries.', 'infi-gold-manager'); ?></p>
                        </td>
                    </tr>
                </table>
                
                <p class="submit">
                    <input type="submit" name="infi_gold_manager_save_settings" class="button button-primary" value="<?php echo esc_attr__('Save Settings', 'infi-gold-manager'); ?>">
                </p>
            </div>
            
            <div class="card" style="max-width: 800px; margin-top: 20px; padding: 20px; background: #fff; border: 1px solid #ccd0d4; border-radius: 4px; box-shadow: 0 1px 1px rgba(0,0,0,.04);">
                <h2><?php echo esc_html__('Manual Update', 'infi-gold-manager'); ?></h2>
                
                <table class="widefat" style="margin-bottom: 20px;">
                    <thead>
                        <tr>
                            <th><?php echo esc_html__('API', 'infi-gold-manager'); ?></th>
                            <th><?php echo esc_html__('Last Update', 'infi-gold-manager'); ?></th>
                            <th><?php echo esc_html__('Status', 'infi-gold-manager'); ?></th>
                            <th><?php echo esc_html__('Action', 'infi-gold-manager'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>
                                <?php
                                $api_provider_labels = [
                                    'metalprice' => 'MetalPriceAPI',
                                    'metals-api' => 'Metals-API',
                                    'swissquote' => 'Swissquote'
                                ];
                                echo isset($api_provider_labels[$api_provider]) ? esc_html($api_provider_labels[$api_provider]) : esc_html($api_provider);
                                ?>
                            </td>
                            <td>
                                <?php 
                                if (!empty($metals_api_status) && isset($metals_api_status['last_update'])) {
                                    echo esc_html(date_i18n(get_option('date_format') . ' ' . get_option('time_format'), strtotime($metals_api_status['last_update'])));
                                } else {
                                    echo esc_html__('Never', 'infi-gold-manager');
                                }
                                ?>
                            </td>
                            <td>
                                <?php 
                                if (!empty($metals_api_status) && isset($metals_api_status['status'])) {
                                    $status_class = $metals_api_status['status'] === 'success' ? 'status-success' : 'status-error';
                                    echo '<span class="' . esc_attr($status_class) . '">' . esc_html($metals_api_status['status']) . '</span>';
                                    
                                    if ($metals_api_status['status'] === 'error' && !empty($metals_api_status['message'])) {
                                        echo '<p class="description error">' . esc_html($metals_api_status['message']) . '</p>';
                                    }
                                } else {
                                    echo esc_html__('Unknown', 'infi-gold-manager');
                                }
                                ?>
                            </td>
                            <td>
                                <button type="submit" name="update_gold_prices" class="button button-secondary"><?php echo esc_html__('Update Now', 'infi-gold-manager'); ?></button>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <?php
                                $currency_api_provider_labels = [
                                    'exchangeratesapi' => 'ExchangeRatesAPI',
                                    'exchangerate-api' => 'ExchangeRate-API'
                                ];
                                echo isset($currency_api_provider_labels[$currency_api_provider]) ? esc_html($currency_api_provider_labels[$currency_api_provider]) : esc_html($currency_api_provider);
                                ?>
                            </td>
                            <td>
                                <?php 
                                if (!empty($exchange_rates_api_status) && isset($exchange_rates_api_status['last_update'])) {
                                    echo esc_html(date_i18n(get_option('date_format') . ' ' . get_option('time_format'), strtotime($exchange_rates_api_status['last_update'])));
                                } else {
                                    echo esc_html__('Never', 'infi-gold-manager');
                                }
                                ?>
                            </td>
                            <td>
                                <?php 
                                if (!empty($exchange_rates_api_status) && isset($exchange_rates_api_status['status'])) {
                                    $status_class = $exchange_rates_api_status['status'] === 'success' ? 'status-success' : 'status-error';
                                    echo '<span class="' . esc_attr($status_class) . '">' . esc_html($exchange_rates_api_status['status']) . '</span>';
                                    
                                    if ($exchange_rates_api_status['status'] === 'error' && !empty($exchange_rates_api_status['message'])) {
                                        echo '<p class="description error">' . esc_html($exchange_rates_api_status['message']) . '</p>';
                                    }
                                } else {
                                    echo esc_html__('Unknown', 'infi-gold-manager');
                                }
                                ?>
                            </td>
                            <td>
                                <button type="submit" name="update_currency_rates" class="button button-secondary"><?php echo esc_html__('Update Now', 'infi-gold-manager'); ?></button>
                            </td>
                        </tr>
                    </tbody>
                </table>
                
                <style>
                    .status-success { color: green; font-weight: bold; }
                    .status-error { color: red; font-weight: bold; }
                    .description.error { color: red; margin: 5px 0 0; }
                </style>
            </div>
        </form>
        
        <!-- إضافة JavaScript لإخفاء/إظهار حقول API حسب الاختيار -->
        <script type="text/javascript">
            jQuery(document).ready(function($) {
                // تغيير عرض حقول API عند تغيير الاختيار
                $('.api-provider-select').on('change', function() {
                    var provider = $(this).val();
                    $('.api-settings').hide();
                    $('.' + provider + '-api-settings').show();
                });
                
                // تغيير عرض حقول API العملة عند تغيير الاختيار
                $('.currency-api-provider-select').on('change', function() {
                    var provider = $(this).val();
                    $('.currency-api-settings').hide();
                    $('.' + provider + '-settings').show();
                });
            });
        </script>
    </div>
    <?php
}




/**
 * صفحة نسب البيع والشراء
 */
function infi_gold_manager_markup_page() {
    // التحقق من الأذونات
/*    if (!current_user_can('manage_options')) {
        return;
    }
*/
    
    global $wpdb;
    
    // حفظ النسب
    if (isset($_POST['infi_gold_manager_save_markup']) && check_admin_referer('infi_gold_manager_markup_nonce')) {
        try {
            $currency_code = sanitize_text_field($_POST['currency_code']);
            $buy_percentage = floatval($_POST['buy_percentage']);
            $sell_percentage = floatval($_POST['sell_percentage']);
            
            if (empty($currency_code)) {
                throw new Exception(__('Currency code is required.', 'infi-gold-manager'));
            }
            
            $result = infi_save_markup_percentages($currency_code, $buy_percentage, $sell_percentage);
            
            if ($result) {
                echo '<div class="notice notice-success is-dismissible"><p>' . __('Markup percentages saved successfully.', 'infi-gold-manager') . '</p></div>';
            } else {
                echo '<div class="notice notice-error is-dismissible"><p>' . __('Failed to save markup percentages.', 'infi-gold-manager') . '</p></div>';
            }
        } catch (Exception $e) {
            echo '<div class="notice notice-error is-dismissible"><p>' . esc_html($e->getMessage()) . '</p></div>';
        }
    }
    
    // حذف نسب
    if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['currency']) && check_admin_referer('delete_markup')) {
        $currency_code = sanitize_text_field($_GET['currency']);
        $table_name = INFI_MAIN_PREFIX  . 'infi_gold_markup';
        
        $result = $wpdb->delete(
            $table_name,
            ['currency_code' => $currency_code],
            ['%s']
        );
        
        if ($result !== false) {
            echo '<div class="notice notice-success is-dismissible"><p>' . __('Markup deleted successfully.', 'infi-gold-manager') . '</p></div>';
        } else {
            echo '<div class="notice notice-error is-dismissible"><p>' . __('Failed to delete markup.', 'infi-gold-manager') . '</p></div>';
        }
    }
    
    // الحصول على القيم الافتراضية من الإعدادات
    $settings = get_option('infi_gold_manager_settings', []);
    $default_buy = isset($settings['default_buy_percentage']) ? floatval($settings['default_buy_percentage']) : 1.5;
    $default_sell = isset($settings['default_sell_percentage']) ? floatval($settings['default_sell_percentage']) : 2.5;
    
    // الحصول على قائمة النسب المخزنة
    $markup_table = INFI_MAIN_PREFIX  . 'infi_gold_markup';
    $markups = $wpdb->get_results("SELECT currency_code, buy_percentage, sell_percentage FROM $markup_table ORDER BY currency_code", ARRAY_A);
    
    // الحصول على قائمة العملات المتوفرة
    $currency_table = INFI_MAIN_PREFIX  . 'infi_currency_rates';
    $latest_date = $wpdb->get_var("SELECT MAX(currency_date) FROM $currency_table");
    $available_currencies = [];
    
    if ($latest_date) {
        $available_currencies = $wpdb->get_results(
            $wpdb->prepare("SELECT DISTINCT currency_code FROM $currency_table WHERE currency_date = %s ORDER BY currency_code", $latest_date),
            ARRAY_A
        );
    }
    
    ?>
    <div class="wrap">
        <h1><?php echo esc_html__('Gold Markup Settings', 'infi-gold-manager'); ?></h1>
        
        <div class="card" style="max-width: 800px; margin-top: 20px; padding: 20px; background: #fff; border: 1px solid #ccd0d4; border-radius: 4px; box-shadow: 0 1px 1px rgba(0,0,0,.04);">
            <h2><?php echo esc_html__('Add/Edit Markup', 'infi-gold-manager'); ?></h2>
            
            <form method="post" action="">
                <?php wp_nonce_field('infi_gold_manager_markup_nonce'); ?>
                
                <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label for="currency_code"><?php echo esc_html__('Currency', 'infi-gold-manager'); ?></label>
                        </th>
                        <td>
                            <select name="currency_code" id="currency_code" required>
                                <option value=""><?php echo esc_html__('-- Select Currency --', 'infi-gold-manager'); ?></option>
                                <?php
                                if (!empty($available_currencies)) {
                                    foreach ($available_currencies as $currency) {
                                        echo '<option value="' . esc_attr($currency['currency_code']) . '">' . esc_html($currency['currency_code']) . '</option>';
                                    }
                                }
                                ?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="buy_percentage"><?php echo esc_html__('Buy Markup (%)', 'infi-gold-manager'); ?></label>
                        </th>
                        <td>
                            <input type="number" step="0.01" name="buy_percentage" id="buy_percentage" value="<?php echo esc_attr($default_buy); ?>" class="regular-text">
                            <p class="description"><?php echo esc_html__('Percentage to add for buy price.', 'infi-gold-manager'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="sell_percentage"><?php echo esc_html__('Sell Markup (%)', 'infi-gold-manager'); ?></label>
                        </th>
                        <td>
                            <input type="number" step="0.01" name="sell_percentage" id="sell_percentage" value="<?php echo esc_attr($default_sell); ?>" class="regular-text">
                            <p class="description"><?php echo esc_html__('Percentage to add for sell price.', 'infi-gold-manager'); ?></p>
                        </td>
                    </tr>
                </table>
                
                <p class="submit">
                    <input type="submit" name="infi_gold_manager_save_markup" class="button button-primary" value="<?php echo esc_attr__('Save Markup', 'infi-gold-manager'); ?>">
                </p>
            </form>
        </div>
        
        <div class="card" style="max-width: 800px; margin-top: 20px; padding: 20px; background: #fff; border: 1px solid #ccd0d4; border-radius: 4px; box-shadow: 0 1px 1px rgba(0,0,0,.04);">
            <h2><?php echo esc_html__('Current Markup Settings', 'infi-gold-manager'); ?></h2>
            
            <?php if (empty($markups)): ?>
                <p><?php echo esc_html__('No markup settings found. Default values will be used.', 'infi-gold-manager'); ?></p>
            <?php else: ?>
                <table class="widefat">
                    <thead>
                        <tr>
                            <th><?php echo esc_html__('Currency', 'infi-gold-manager'); ?></th>
                            <th><?php echo esc_html__('Buy Markup (%)', 'infi-gold-manager'); ?></th>
                            <th><?php echo esc_html__('Sell Markup (%)', 'infi-gold-manager'); ?></th>
                            <th><?php echo esc_html__('Actions', 'infi-gold-manager'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($markups as $markup): ?>
                            <tr>
                                <td><?php echo esc_html($markup['currency_code']); ?></td>
                                <td><?php echo esc_html($markup['buy_percentage']); ?></td>
                                <td><?php echo esc_html($markup['sell_percentage']); ?></td>
                                <td>
                                    <a href="<?php echo esc_url(wp_nonce_url(admin_url('admin.php?page=infi-gold-markup&action=delete&currency=' . $markup['currency_code']), 'delete_markup')); ?>" class="button button-small" onclick="return confirm('<?php echo esc_js(__('Are you sure you want to delete this markup?', 'infi-gold-manager')); ?>');"><?php echo esc_html__('Delete', 'infi-gold-manager'); ?></a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
            
            <p>
                <strong><?php echo esc_html__('Default Values:', 'infi-gold-manager'); ?></strong>
                <?php echo esc_html__('Buy Markup:', 'infi-gold-manager'); ?> <?php echo esc_html($default_buy); ?>% | 
                <?php echo esc_html__('Sell Markup:', 'infi-gold-manager'); ?> <?php echo esc_html($default_sell); ?>%
            </p>
        </div>
    </div>
    <?php
}

/**
 * صفحة عرض أسعار الذهب
 */
function infi_gold_manager_prices_page() {
    // التحقق من الأذونات
/*    if (!current_user_can('manage_options')) {
        return;
    }
*/
    
    // الحصول على العيار المحدد للعرض
    $selected_carat = isset($_GET['carat']) ? sanitize_text_field($_GET['carat']) : '24k';
    $selected_currency = isset($_GET['currency']) ? sanitize_text_field($_GET['currency']) : 'USD';
    
    // الحصول على إعدادات العملة الافتراضية
    $settings = get_option('infi_gold_manager_settings', []);
    $default_currency = isset($settings['default_currency']) ? $settings['default_currency'] : 'USD';
    
    if (empty($selected_currency)) {
        $selected_currency = $default_currency;
    }
    
    // الحصول على أحدث أسعار الذهب
    $gold_prices = infi_get_latest_gold_prices();
    
    // الحصول على أحدث أسعار العملات
    $currency_rates = infi_get_latest_currency_rates();
    
    // تنظيم البيانات
    $organized_prices = [];
    $carats = [];
    
    if (!empty($gold_prices)) {
        foreach ($gold_prices as $price) {
            if (!in_array($price['carat'], $carats)) {
                $carats[] = $price['carat'];
            }
            
            $price_usd = floatval($price['price_usd']);
            $price_in_currency = $selected_currency === 'USD' ? $price_usd : ($price_usd * $currency_rates[$selected_currency]);
            
            $organized_prices[$price['carat']] = [
                'price_usd' => $price_usd,
                'price_currency' => $price_in_currency
            ];
        }
    }
    
    // الحصول على تحليل التغير في الأسعار
    if (!empty($selected_carat)) {
        $daily_change = infi_get_gold_price_change($selected_carat, 'daily');
        $weekly_change = infi_get_gold_price_change($selected_carat, 'weekly');
    }
    
    ?>
    <div class="wrap">
        <h1><?php echo esc_html__('Gold Prices', 'infi-gold-manager'); ?></h1>
        
        <div class="card" style="max-width: 800px; margin-top: 20px; padding: 20px; background: #fff; border: 1px solid #ccd0d4; border-radius: 4px; box-shadow: 0 1px 1px rgba(0,0,0,.04);">
            <form method="get" action="">
                <input type="hidden" name="page" value="infi-gold-prices">
                
                <div style="display: flex; gap: 20px; margin-bottom: 20px;">
                    <div>
                        <label for="carat"><?php echo esc_html__('Select Gold Carat:', 'infi-gold-manager'); ?></label>
                        <select name="carat" id="carat">
                            <?php foreach ($carats as $carat): ?>
                                <option value="<?php echo esc_attr($carat); ?>" <?php selected($selected_carat, $carat); ?>><?php echo esc_html($carat); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div>
                        <label for="currency"><?php echo esc_html__('Currency:', 'infi-gold-manager'); ?></label>
                        <select name="currency" id="currency">
                            <option value="USD" <?php selected($selected_currency, 'USD'); ?>>USD (US Dollar)</option>
                            <?php 
                            if (!empty($currency_rates)) {
                                foreach ($currency_rates as $code => $rate) {
                                    if ($code === 'USD') continue;
                                    echo '<option value="' . esc_attr($code) . '" ' . selected($selected_currency, $code, false) . '>' . esc_html($code) . '</option>';
                                }
                            }
                            ?>
                        </select>
                    </div>
                    
                    <div>
                        <button type="submit" class="button button-primary"><?php echo esc_html__('Apply', 'infi-gold-manager'); ?></button>
                    </div>
                </div>
            </form>
            
            <?php if (!empty($organized_prices)): ?>
                <h2><?php echo esc_html__('Current Gold Prices', 'infi-gold-manager'); ?></h2>
                
                <table class="widefat">
                    <thead>
                        <tr>
                            <th><?php echo esc_html__('Gold Carat', 'infi-gold-manager'); ?></th>
                            <th><?php echo esc_html__('Price (USD)', 'infi-gold-manager'); ?></th>
                            <th><?php echo esc_html__('Price (' . esc_html($selected_currency) . ')', 'infi-gold-manager'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($organized_prices as $carat => $price_data): ?>
                            <tr>
                                <td><?php echo esc_html($carat); ?></td>
                                <td><?php echo number_format($price_data['price_usd'], 2); ?></td>
                                <td><?php echo number_format($price_data['price_currency'], 2); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                
                <?php if (!empty($selected_carat) && isset($daily_change) && isset($weekly_change)): ?>
                    <h2><?php echo esc_html__('Price Changes for ' . $selected_carat, 'infi-gold-manager'); ?></h2>
                    
                    <table class="widefat" style="margin-top: 20px;">
                        <thead>
                            <tr>
                                <th><?php echo esc_html__('Period', 'infi-gold-manager'); ?></th>
                                <th><?php echo esc_html__('Current Price', 'infi-gold-manager'); ?></th>
                                <th><?php echo esc_html__('Previous Price', 'infi-gold-manager'); ?></th>
                                <th><?php echo esc_html__('Change', 'infi-gold-manager'); ?></th>
                                <th><?php echo esc_html__('Change %', 'infi-gold-manager'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!empty($daily_change) && $daily_change['previous_price'] !== null): ?>
                                <tr>
                                    <td><?php echo esc_html__('Daily', 'infi-gold-manager'); ?></td>
                                    <td><?php echo number_format($daily_change['current_price'], 2); ?> USD</td>
                                    <td><?php echo number_format($daily_change['previous_price'], 2); ?> USD</td>
                                    <td>
                                        <?php
                                        $change_class = $daily_change['change_value'] >= 0 ? 'positive' : 'negative';
                                        $change_sign = $daily_change['change_value'] >= 0 ? '+' : '';
                                        echo '<span class="' . esc_attr($change_class) . '">' . $change_sign . number_format($daily_change['change_value'], 2) . ' USD</span>';
                                        ?>
                                    </td>
                                    <td>
                                        <?php
                                        echo '<span class="' . esc_attr($change_class) . '">' . $change_sign . number_format($daily_change['change_percentage'], 2) . '%</span>';
                                        ?>
                                    </td>
                                </tr>
                            <?php endif; ?>
                            
                            <?php if (!empty($weekly_change) && $weekly_change['previous_price'] !== null): ?>
                                <tr>
                                    <td><?php echo esc_html__('Weekly', 'infi-gold-manager'); ?></td>
                                    <td><?php echo number_format($weekly_change['current_price'], 2); ?> USD</td>
                                    <td><?php echo number_format($weekly_change['previous_price'], 2); ?> USD</td>
                                    <td>
                                        <?php
                                        $change_class = $weekly_change['change_value'] >= 0 ? 'positive' : 'negative';
                                        $change_sign = $weekly_change['change_value'] >= 0 ? '+' : '';
                                        echo '<span class="' . esc_attr($change_class) . '">' . $change_sign . number_format($weekly_change['change_value'], 2) . ' USD</span>';
                                        ?>
                                    </td>
                                    <td>
                                        <?php
                                        echo '<span class="' . esc_attr($change_class) . '">' . $change_sign . number_format($weekly_change['change_percentage'], 2) . '%</span>';
                                        ?>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                    
                    <style>
                        .positive { color: green; font-weight: bold; }
                        .negative { color: red; font-weight: bold; }
                    </style>
                <?php endif; ?>
                
            <?php else: ?>
                <div class="notice notice-warning">
                    <p><?php echo esc_html__('No gold prices available. Please make sure API settings are configured correctly and data has been fetched.', 'infi-gold-manager'); ?></p>
                </div>
            <?php endif; ?>
        </div>
    </div>
    <?php
}

/**
 * صفحة عرض سجلات الأخطاء
 */
function infi_gold_manager_logs_page() {
    // التحقق من الأذونات
/*    if (!current_user_can('manage_options')) {
        return;
    }
*/
    
    // حذف ملف السجل
    if (isset($_POST['clear_log']) && check_admin_referer('infi_gold_manager_logs_nonce')) {
        $log_file = INFI_GOLD_MANAGER_PATH . 'debug.log';
        if (file_exists($log_file)) {
            file_put_contents($log_file, '');
            echo '<div class="notice notice-success is-dismissible"><p>' . __('Log file cleared successfully.', 'infi-gold-manager') . '</p></div>';
        }
    }
    
    // تنزيل ملف السجل
    if (isset($_POST['download_log']) && check_admin_referer('infi_gold_manager_logs_nonce')) {
        $log_file = INFI_GOLD_MANAGER_PATH . 'debug.log';
        if (file_exists($log_file)) {
            header('Content-Type: text/plain');
            header('Content-Disposition: attachment; filename="gold-manager-debug.log"');
            header('Content-Length: ' . filesize($log_file));
            readfile($log_file);
            exit;
        }
    }
    
    // قراءة ملف السجل
    $log_content = '';
    $log_file = INFI_GOLD_MANAGER_PATH . 'debug.log';
    if (file_exists($log_file)) {
        $log_content = file_get_contents($log_file);
    }
    
    // تنسيق السجل للعرض
    $log_lines = [];
    if (!empty($log_content)) {
        $lines = explode("\n", $log_content);
        $lines = array_reverse($lines); // عرض الأحدث أولاً
        
        foreach ($lines as $line) {
            if (!empty(trim($line))) {
                $log_lines[] = $line;
            }
        }
    }
    
    ?>
    <div class="wrap">
        <h1><?php echo esc_html__('Gold Manager Logs', 'infi-gold-manager'); ?></h1>
        
        <div class="card" style="max-width: 1200px; margin-top: 20px; padding: 20px; background: #fff; border: 1px solid #ccd0d4; border-radius: 4px; box-shadow: 0 1px 1px rgba(0,0,0,.04);">
            <form method="post" action="">
                <?php wp_nonce_field('infi_gold_manager_logs_nonce'); ?>
                
                <div style="margin-bottom: 20px;">
                    <button type="submit" name="clear_log" class="button button-secondary" onclick="return confirm('<?php echo esc_js(__('Are you sure you want to clear the log file?', 'infi-gold-manager')); ?>');"><?php echo esc_html__('Clear Log', 'infi-gold-manager'); ?></button>
                    <button type="submit" name="download_log" class="button button-secondary"><?php echo esc_html__('Download Log', 'infi-gold-manager'); ?></button>
                </div>
            </form>
            
            <h2><?php echo esc_html__('Log Entries', 'infi-gold-manager'); ?></h2>
            
            <div style="max-height: 500px; overflow-y: auto; border: 1px solid #ddd; padding: 10px; background: #f5f5f5; font-family: monospace;">
                <?php
                if (empty($log_lines)) {
                    echo '<p>' . esc_html__('Log is empty.', 'infi-gold-manager') . '</p>';
                } else {
                    foreach ($log_lines as $line) {
                        $line_class = '';
                        if (strpos($line, '[ERROR]') !== false || strpos($line, '[CRITICAL]') !== false) {
                            $line_class = 'error-line';
                        } elseif (strpos($line, '[WARNING]') !== false) {
                            $line_class = 'warning-line';
                        } elseif (strpos($line, '[DEBUG]') !== false) {
                            $line_class = 'debug-line';
                        }
                        
                        echo '<div class="log-line ' . esc_attr($line_class) . '">' . esc_html($line) . '</div>';
                    }
                }
                ?>
            </div>
            
            <style>
                .log-line { padding: 3px 0; }
                .error-line { color: #d63638; }
                .warning-line { color: #dba617; }
                .debug-line { color: #3582c4; }
                .log-line:hover { background-color: #e9e9e9; }
            </style>
        </div>
    </div>
    <?php
}

/**
 * صفحة توثيق الشورت كود
 */
function infi_gold_manager_shortcodes_page() {
    ?>
    <div class="wrap">
        <h1><?php echo esc_html__('Gold Manager Shortcodes', 'infi-gold-manager'); ?></h1>
        
        <div class="card" style="max-width: 1200px; margin-top: 20px; padding: 20px; background: #fff; border: 1px solid #ccd0d4; border-radius: 4px; box-shadow: 0 1px 1px rgba(0,0,0,.04);">
            <h2><?php echo esc_html__('Available Shortcodes', 'infi-gold-manager'); ?></h2>
            
            <table class="widefat" style="margin-bottom: 30px;">
                <thead>
                    <tr>
                        <th><?php echo esc_html__('Shortcode', 'infi-gold-manager'); ?></th>
                        <th><?php echo esc_html__('Description', 'infi-gold-manager'); ?></th>
                        <th><?php echo esc_html__('Parameters', 'infi-gold-manager'); ?></th>
                        <th><?php echo esc_html__('Example', 'infi-gold-manager'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <!-- Currency Rate -->
                    <tr>
                        <td><code>[infi_currency_rate]</code></td>
                        <td><?php echo esc_html__('Display currency exchange rate against usd', 'infi-gold-manager'); ?></td>
                        <td>
                            <ul>
                                <li><code>currency</code>: <?php echo esc_html__('Currency code (default: site default)', 'infi-gold-manager'); ?></li>
                                <li><code>date</code>: <?php echo esc_html__('Specific date (YYYY-MM-DD)', 'infi-gold-manager'); ?></li>
                                <li><code>decimals</code>: <?php echo esc_html__('Decimal places (default: 2)', 'infi-gold-manager'); ?></li>
                            </ul>
                        </td>
                        <td><code>[infi_currency_rate currency="USD"]</code></td>
                    </tr>
                    
                    <!-- Gold Price in usd -->
                    <tr>
                        <td><code>[infi_gold_price_usd]</code></td>
                        <td><?php echo esc_html__('Display gold price in usd', 'infi-gold-manager'); ?></td>
                        <td>
                            <ul>
                                <li><code>carat</code>: <?php echo esc_html__('Gold carat (24k, 22k, 21k, 18k, 14k, 12k, 24k_oz)', 'infi-gold-manager'); ?></li>
                                <li><code>date</code>: <?php echo esc_html__('Specific date (YYYY-MM-DD)', 'infi-gold-manager'); ?></li>
                                <li><code>decimals</code>: <?php echo esc_html__('Decimal places (default: 2)', 'infi-gold-manager'); ?></li>
                            </ul>
                        </td>
                        <td><code>[infi_gold_price_usd carat="21k"]</code></td>
                    </tr>
                    
                    <!-- Gold Price in Any Currency -->
                    <tr>
                        <td><code>[infi_gold_price]</code></td>
                        <td><?php echo esc_html__('Display gold price in specified currency', 'infi-gold-manager'); ?></td>
                        <td>
                            <ul>
                                <li><code>carat</code>: <?php echo esc_html__('Gold carat (24k, 22k, 21k, 18k, 14k, 12k, 24k_oz)', 'infi-gold-manager'); ?></li>
                                <li><code>currency</code>: <?php echo esc_html__('Currency code (default: site default)', 'infi-gold-manager'); ?></li>
                                <li><code>date</code>: <?php echo esc_html__('Specific date (YYYY-MM-DD)', 'infi-gold-manager'); ?></li>
                                <li><code>decimals</code>: <?php echo esc_html__('Decimal places (default: 2)', 'infi-gold-manager'); ?></li>
                            </ul>
                        </td>
                        <td><code>[infi_gold_price carat="24k" currency="AED"]</code></td>
                    </tr>
                    
                    <!-- Gold Table -->
                    <tr>
                        <td><code>[infi_gold_table]</code></td>
                        <td><?php echo esc_html__('Display table of gold prices for all carats', 'infi-gold-manager'); ?></td>
                        <td>
                            <ul>
                                <li><code>currency</code>: <?php echo esc_html__('Currency code (default: site default)', 'infi-gold-manager'); ?></li>
                                <li><code>show_buy_sell</code>: <?php echo esc_html__('Show buy/sell prices (yes/no)', 'infi-gold-manager'); ?></li>
                                <li><code>show_change</code>: <?php echo esc_html__('Show price changes (yes/no)', 'infi-gold-manager'); ?></li>
                                <li><code>decimals</code>: <?php echo esc_html__('Decimal places (default: 2)', 'infi-gold-manager'); ?></li>
                            </ul>
                        </td>
                        <td><code>[infi_gold_table currency="SAR"]</code></td>
                    </tr>
                    
                    <!-- Gold Chart -->
                    <tr>
                        <td><code>[infi_gold_chart]</code></td>
                        <td><?php echo esc_html__('Display interactive gold price chart', 'infi-gold-manager'); ?></td>
                        <td>
                            <ul>
                                <li><code>carat</code>: <?php echo esc_html__('Gold carat (default: 24k)', 'infi-gold-manager'); ?></li>
                                <li><code>currency</code>: <?php echo esc_html__('Currency code (default: site default)', 'infi-gold-manager'); ?></li>
                                <li><code>period</code>: <?php echo esc_html__('Time period (month, 3months, 6months)', 'infi-gold-manager'); ?></li>
                                <li><code>width</code>: <?php echo esc_html__('Chart width (default: 100%)', 'infi-gold-manager'); ?></li>
                                <li><code>height</code>: <?php echo esc_html__('Chart height (default: 405)', 'infi-gold-manager'); ?></li>
                                <li><code>title</code>: <?php echo esc_html__('Chart title', 'infi-gold-manager'); ?></li>
                                <li><code>mobile_height</code>: <?php echo esc_html__('Mobile height (default: 300)', 'infi-gold-manager'); ?></li>
                            </ul>
                        </td>
                        <td><code>[infi_gold_chart carat="21k" period="3months"]</code></td>
                    </tr>
                    
                    <!-- Gold Extremes -->
                    <tr>
                        <td><code>[infi_gold_extremes]</code></td>
                        <td><?php echo esc_html__('Display highest/lowest gold prices', 'infi-gold-manager'); ?></td>
                        <td>
                            <ul>
                                <li><code>carat</code>: <?php echo esc_html__('Gold carat (default: 24k)', 'infi-gold-manager'); ?></li>
                                <li><code>currency</code>: <?php echo esc_html__('Currency code (default: site default)', 'infi-gold-manager'); ?></li>
                                <li><code>days</code>: <?php echo esc_html__('Number of days to analyze (default: 30)', 'infi-gold-manager'); ?></li>
                                <li><code>show_dates</code>: <?php echo esc_html__('Show dates (yes/no)', 'infi-gold-manager'); ?></li>
                                <li><code>show</code>: <?php echo esc_html__('both/highest/lowest (default: both)', 'infi-gold-manager'); ?></li>
                                <li><code>decimals</code>: <?php echo esc_html__('Decimal places (default: 2)', 'infi-gold-manager'); ?></li>
                            </ul>
                        </td>
                        <td><code>[infi_gold_extremes carat="21k" days="90"]</code></td>
                    </tr>
                    
                    <!-- Gold Change -->
                    <tr>
                        <td><code>[infi_gold_change]</code></td>
                        <td><?php echo esc_html__('Display price change percentage', 'infi-gold-manager'); ?></td>
                        <td>
                            <ul>
                                <li><code>carat</code>: <?php echo esc_html__('Gold carat (default: 24k)', 'infi-gold-manager'); ?></li>
                                <li><code>period</code>: <?php echo esc_html__('daily/weekly (default: daily)', 'infi-gold-manager'); ?></li>
                                <li><code>show_percentage</code>: <?php echo esc_html__('Show percentage (yes/no)', 'infi-gold-manager'); ?></li>
                                <li><code>show_value</code>: <?php echo esc_html__('Show value (yes/no)', 'infi-gold-manager'); ?></li>
                                <li><code>currency</code>: <?php echo esc_html__('Currency code (default: USD)', 'infi-gold-manager'); ?></li>
                                <li><code>decimals</code>: <?php echo esc_html__('Decimal places (default: 2)', 'infi-gold-manager'); ?></li>
                            </ul>
                        </td>
                        <td><code>[infi_gold_change carat="24k" period="daily"]</code></td>
                    </tr>
                    
                    <!-- Gold Cards -->
                    <tr>
                        <td><code>[infi_gold_cards]</code></td>
                        <td><?php echo esc_html__('Display gold price cards for all carats', 'infi-gold-manager'); ?></td>
                        <td>
                            <ul>
                                <li><code>currency</code>: <?php echo esc_html__('Currency code (default: site default)', 'infi-gold-manager'); ?></li>
                                <li><code>featured_carat</code>: <?php echo esc_html__('Carat to highlight (default: 21k)', 'infi-gold-manager'); ?></li>
                                <li><code>decimals</code>: <?php echo esc_html__('Decimal places (default: 2)', 'infi-gold-manager'); ?></li>
                                <li><code>currency_label</code>: <?php echo esc_html__('Custom currency label', 'infi-gold-manager'); ?></li>
                                <li><code>base_url</code>: <?php echo esc_html__('Base URL for carat links', 'infi-gold-manager'); ?></li>
                            </ul>
                        </td>
                        <td><code>[infi_gold_cards currency="AED"]</code></td>
                    </tr>
                    
                    <!-- Gold Info Boxes -->
                    <tr>
                        <td><code>[infi_gold_info_boxes]</code></td>
                        <td><?php echo esc_html__('Display gold and currency info boxes', 'infi-gold-manager'); ?></td>
                        <td>
                            <ul>
                                <li><code>currency</code>: <?php echo esc_html__('Currency code (default: site default)', 'infi-gold-manager'); ?></li>
                                <li><code>box_type</code>: <?php echo esc_html__('all/pound/ounce_usd/ounce/dollar', 'infi-gold-manager'); ?></li>
                                <li><code>pound_url</code>: <?php echo esc_html__('URL for gold pound link', 'infi-gold-manager'); ?></li>
                                <li><code>ounce_usd_url</code>: <?php echo esc_html__('URL for ounce in USD link', 'infi-gold-manager'); ?></li>
                                <li><code>ounce_url</code>: <?php echo esc_html__('URL for ounce link', 'infi-gold-manager'); ?></li>
                                <li><code>dollar_url</code>: <?php echo esc_html__('URL for dollar link', 'infi-gold-manager'); ?></li>
                            </ul>
                        </td>
                        <td><code>[infi_gold_info_boxes currency="SAR"]</code></td>
                    </tr>
                    
                    <!-- Gold Price Cards -->
                    <tr>
                        <td><code>[infi_gold_price_cards]</code></td>
                        <td><?php echo esc_html__('Display price cards for gold ounce and 21k', 'infi-gold-manager'); ?></td>
                        <td>
                            <ul>
                                <li><code>currency</code>: <?php echo esc_html__('Currency code (default: site default)', 'infi-gold-manager'); ?></li>
                                <li><code>layout</code>: <?php echo esc_html__('horizontal/vertical (default: horizontal)', 'infi-gold-manager'); ?></li>
                                <li><code>show_cards</code>: <?php echo esc_html__('both/ounce/gram21 (default: both)', 'infi-gold-manager'); ?></li>
                            </ul>
                        </td>
                        <td><code>[infi_gold_price_cards layout="vertical"]</code></td>
                    </tr>
                    
                    <!-- Advanced Gold Table -->
                    <tr>
                        <td><code>[infi_gold_table_advanced]</code></td>
                        <td><?php echo esc_html__('Display advanced gold price table with buy/sell prices', 'infi-gold-manager'); ?></td>
                        <td>
                            <ul>
                                <li><code>currency</code>: <?php echo esc_html__('Currency code (default: site default)', 'infi-gold-manager'); ?></li>
                                <li><code>country</code>: <?php echo esc_html__('Country name for display', 'infi-gold-manager'); ?></li>
                                <li><code>header_bg</code>: <?php echo esc_html__('Header background color', 'infi-gold-manager'); ?></li>
                                <li><code>header_color</code>: <?php echo esc_html__('Header text color', 'infi-gold-manager'); ?></li>
                                <li><code>table_class</code>: <?php echo esc_html__('Additional table classes', 'infi-gold-manager'); ?></li>
                                <li><code>currency_label</code>: <?php echo esc_html__('Custom currency label', 'infi-gold-manager'); ?></li>
                            </ul>
                        </td>
                        <td><code>[infi_gold_table_advanced currency="EGP" country="مصر"]</code></td>
                    </tr>
                    
                    <!-- Gold Calculator -->
                    <tr>
                        <td><code>[infi_gold_calculator]</code></td>
                        <td><?php echo esc_html__('Display gold price calculator', 'infi-gold-manager'); ?></td>
                        <td>
                            <ul>
                                <li><code>currency</code>: <?php echo esc_html__('Currency code (default: site default)', 'infi-gold-manager'); ?></li>
                            </ul>
                        </td>
                        <td><code>[infi_gold_calculator currency="AED"]</code></td>
                    </tr>
                    
                    <!-- Gold Weight Table -->
                    <tr>
                        <td><code>[infi_gold_weight_table]</code></td>
                        <td><?php echo esc_html__('Display table of gold prices by weight', 'infi-gold-manager'); ?></td>
                        <td>
                            <ul>
                                <li><code>carat</code>: <?php echo esc_html__('Gold carat (default: 24k)', 'infi-gold-manager'); ?></li>
                                <li><code>currency</code>: <?php echo esc_html__('Currency code (default: site default)', 'infi-gold-manager'); ?></li>
                                <li><code>weights</code>: <?php echo esc_html__('Comma-separated weight values (default: 1,5,10,15,20,25,50,100,250,500,1000)', 'infi-gold-manager'); ?></li>
                            </ul>
                        </td>
                        <td><code>[infi_gold_weight_table carat="21k" weights="1,5,10,50"]</code></td>
                    </tr>
                    
                    <!-- Gold Price Display -->
                    <tr>
                        <td><code>[infi_gold_price_display]</code></td>
                        <td><?php echo esc_html__('Comprehensive gold price display with calculator', 'infi-gold-manager'); ?></td>
                        <td>
                            <ul>
                                <li><code>country</code>: <?php echo esc_html__('Country name (auto-detected)', 'infi-gold-manager'); ?></li>
                                <li><code>currency</code>: <?php echo esc_html__('Currency code (auto-detected)', 'infi-gold-manager'); ?></li>
                                <li><code>carat</code>: <?php echo esc_html__('Gold carat (default: 24k)', 'infi-gold-manager'); ?></li>
                                <li><code>show_calculator</code>: <?php echo esc_html__('Show calculator (yes/no)', 'infi-gold-manager'); ?></li>
                                <li><code>weights</code>: <?php echo esc_html__('Comma-separated weight values', 'infi-gold-manager'); ?></li>
                            </ul>
                        </td>
                        <td><code>[infi_gold_price_display carat="21k"]</code></td>
                    </tr>
                    
                    <!-- Currency Display -->
                    <tr>
                        <td><code>[infi_currency_display]</code></td>
                        <td><?php echo esc_html__('Comprehensive currency exchange rate display with calculator', 'infi-gold-manager'); ?></td>
                        <td>
                            <ul>
                                <li><code>from_currency</code>: <?php echo esc_html__('Base currency (default: USD)', 'infi-gold-manager'); ?></li>
                                <li><code>to_currency</code>: <?php echo esc_html__('Target currency (auto-detected)', 'infi-gold-manager'); ?></li>
                                <li><code>country</code>: <?php echo esc_html__('Country name (auto-detected)', 'infi-gold-manager'); ?></li>
                                <li><code>decimals</code>: <?php echo esc_html__('Decimal places (default: 2)', 'infi-gold-manager'); ?></li>
                                <li><code>show_calculator</code>: <?php echo esc_html__('Show calculator (yes/no)', 'infi-gold-manager'); ?></li>
                                <li><code>weights</code>: <?php echo esc_html__('Comma-separated amount values', 'infi-gold-manager'); ?></li>
                                <li><code>calculator_title</code>: <?php echo esc_html__('Calculator title', 'infi-gold-manager'); ?></li>
                            </ul>
                        </td>
                        <td><code>[infi_currency_display from_currency="USD"]</code></td>
                    </tr>
                    
                    <!-- Countries Display -->
                    <tr>
                        <td><code>[display_countries]</code></td>
                        <td><?php echo esc_html__('Display supported countries with flags', 'infi-gold-manager'); ?></td>
                        <td>
                            <ul>
                                <li><?php echo esc_html__('No parameters', 'infi-gold-manager'); ?></li>
                            </ul>
                        </td>
                        <td><code>[display_countries]</code></td>
                    </tr>
                    
                    <!-- Debug Data -->
                    <tr>
                        <td><code>[infi_debug_data]</code></td>
                        <td><?php echo esc_html__('Display debug information for troubleshooting', 'infi-gold-manager'); ?></td>
                        <td>
                            <ul>
                                <li><?php echo esc_html__('No parameters', 'infi-gold-manager'); ?></li>
                            </ul>
                        </td>
                        <td><code>[infi_debug_data]</code></td>
                    </tr>
                </tbody>
            </table>
            
            <h2><?php echo esc_html__('Usage Examples', 'infi-gold-manager'); ?></h2>
            
            <div class="usage-examples">
                <div class="example">
                    <h3><?php echo esc_html__('Basic Gold Price Display', 'infi-gold-manager'); ?></h3>
                    <pre><code>Today's gold price (24k): [infi_gold_price]</code></pre>
                    <pre><code>Today's gold price (21k) in Saudi Arabia: [infi_gold_price carat="21k" currency="SAR"]</code></pre>
                </div>
                
                <div class="example">
                    <h3><?php echo esc_html__('Currency Exchange Rate', 'infi-gold-manager'); ?></h3>
                    <pre><code>1 USD = [infi_currency_rate currency="AED"] AED</code></pre>
                    <pre><code>1 usd = [infi_currency_rate currency="EGP"] EGP</code></pre>
                </div>
                
                <div class="example">
                    <h3><?php echo esc_html__('Comprehensive Gold Display', 'infi-gold-manager'); ?></h3>
                    <pre><code>[infi_gold_price_display carat="21k"]</code></pre>
                    <pre><code>[infi_gold_price_display carat="24k_oz" show_calculator="no"]</code></pre>
                </div>
                
                <div class="example">
                    <h3><?php echo esc_html__('Currency Converter', 'infi-gold-manager'); ?></h3>
                    <pre><code>[infi_currency_display from_currency="USD" calculator_title="حاسبة الدولار الأمريكي"]</code></pre>
                    <pre><code>[infi_currency_display from_currency="usd" to_currency="AED"]</code></pre>
                </div>
                
                <div class="example">
                    <h3><?php echo esc_html__('Gold Price Table', 'infi-gold-manager'); ?></h3>
                    <pre><code>[infi_gold_table_advanced currency="AED" country="الإمارات"]</code></pre>
                    <pre><code>[infi_gold_table currency="SAR" show_buy_sell="yes"]</code></pre>
                </div>
                
                <div class="example">
                    <h3><?php echo esc_html__('Gold Price Chart', 'infi-gold-manager'); ?></h3>
                    <pre><code>[infi_gold_chart carat="24k" period="3months" title="سعر الذهب عيار 24 خلال 3 أشهر"]</code></pre>
                </div>
            </div>
            
            <style>
                .usage-examples { 
                    display: grid; 
                    grid-template-columns: repeat(auto-fill, minmax(400px, 1fr)); 
                    gap: 20px; 
                    margin-top: 20px; 
                }
                .example { 
                    background: #f9f9f9; 
                    padding: 15px; 
                    border-radius: 5px; 
                    border: 1px solid #e0e0e0; 
                }
                .example h3 { 
                    margin-top: 0; 
                    margin-bottom: 15px;
                    color: #23282d;
                }
                .example pre { 
                    background: #fff; 
                    padding: 10px; 
                    border-radius: 3px; 
                    border: 1px solid #ddd; 
                    overflow-x: auto; 
                    margin-bottom: 10px;
                }
                .example code { 
                    display: block; 
                    white-space: pre-wrap;
                    font-family: monospace;
                }
                table.widefat {
                    border-spacing: 0;
                    width: 100%;
                    clear: both;
                    margin: 0;
                    border: 1px solid #ccd0d4;
                    box-shadow: 0 1px 1px rgba(0,0,0,.04);
                }
                table.widefat th, table.widefat td {
                    padding: 12px;
                    text-align: left;
                    vertical-align: top;
                    border: 1px solid #ccd0d4;
                }
                table.widefat th {
                    background: #f5f5f5;
                    font-weight: 600;
                }
                table.widefat ul {
                    margin: 0;
                    padding-left: 20px;
                }
                table.widefat li {
                    margin-bottom: 5px;
                }
                code {
                    background: #f0f0f1;
                    padding: 2px 4px;
                    border-radius: 3px;
                    font-family: monospace;
                }
            </style>
        </div>
    </div>
    <?php
}









// إضافة قائمة فرعية للبيانات التاريخية
// إضافة قائمة فرعية للبيانات التاريخية
add_action('admin_menu', 'infi_add_historical_data_menu');
function infi_add_historical_data_menu() {
    add_submenu_page(
        'admin.php?page=infi-gold-manager', // معلمة parent_slug المحدثة
        __('Historical Data', 'infi-gold-manager'),
        __('Historical Data', 'infi-gold-manager'),
        'manage_options',
        'infi-gold-historical', 
        'infi_gold_manager_historical_page'
    );
}

/**
 * صفحة إدارة البيانات التاريخية
 */
function infi_gold_manager_historical_page() {
    // التحقق من الأذونات
/*    if (!current_user_can('manage_options')) {
        return;
    }
*/
    
    $message = '';
    $error = '';
    
    // معالجة طلب تحميل البيانات التاريخية
    if (isset($_POST['load_historical_data']) && check_admin_referer('infi_historical_data_nonce')) {
        $days = isset($_POST['days']) ? intval($_POST['days']) : 30;
        
        if ($days <= 0 || $days > 365) {
            $error = __('Please enter a valid number of days (1-365).', 'infi-gold-manager');
        } else {
            $result = infi_load_historical_gold_data($days);
            
            if ($result['status'] === 'success') {
                $message = sprintf(
                    __('Successfully loaded historical gold prices for %d days (%d entries).', 'infi-gold-manager'),
                    $days,
                    $result['count']
                );
            } else {
                $error = sprintf(
                    __('Error loading historical data: %s', 'infi-gold-manager'),
                    $result['message']
                );
            }
        }
    }
    
    // عرض صفحة الإدارة
    ?>
    <div class="wrap">
        <h1><?php echo esc_html__('Historical Gold Data', 'infi-gold-manager'); ?></h1>
        
        <?php if ($message): ?>
            <div class="notice notice-success is-dismissible">
                <p><?php echo esc_html($message); ?></p>
            </div>
        <?php endif; ?>
        
        <?php if ($error): ?>
            <div class="notice notice-error is-dismissible">
                <p><?php echo esc_html($error); ?></p>
            </div>
        <?php endif; ?>
        
        <div class="card" style="max-width: 800px; margin-top: 20px; padding: 20px; background: #fff; border: 1px solid #ccd0d4; border-radius: 4px; box-shadow: 0 1px 1px rgba(0,0,0,.04);">
            <h2><?php echo esc_html__('Load Historical Gold Prices', 'infi-gold-manager'); ?></h2>
            <p><?php echo esc_html__('Use this tool to load historical gold prices for a specified number of days. This is useful for filling charts with data when your site is new.', 'infi-gold-manager'); ?></p>
            
            <form method="post" action="">
                <?php wp_nonce_field('infi_historical_data_nonce'); ?>
                
                <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label for="days"><?php echo esc_html__('Number of Days', 'infi-gold-manager'); ?></label>
                        </th>
                        <td>
                            <input type="number" name="days" id="days" value="30" min="1" max="365" class="small-text">
                            <p class="description"><?php echo esc_html__('How many days of historical data to load (1-365).', 'infi-gold-manager'); ?></p>
                        </td>
                    </tr>
                </table>
                
                <p class="submit">
                    <input type="submit" name="load_historical_data" class="button button-primary" value="<?php echo esc_attr__('Load Historical Data', 'infi-gold-manager'); ?>">
                </p>
            </form>
        </div>
        
        <div class="card" style="max-width: 800px; margin-top: 20px; padding: 20px; background: #fff; border: 1px solid #ccd0d4; border-radius: 4px; box-shadow: 0 1px 1px rgba(0,0,0,.04);">
            <h2><?php echo esc_html__('Current Data Status', 'infi-gold-manager'); ?></h2>
            
            <?php
            // استعلام لمعرفة البيانات المتوفرة حاليًا
            global $wpdb;
            $gold_table = INFI_MAIN_PREFIX  . 'infi_gold_prices';
            
            $earliest_date = $wpdb->get_var("SELECT MIN(gold_date) FROM $gold_table");
            $latest_date = $wpdb->get_var("SELECT MAX(gold_date) FROM $gold_table");
            $total_entries = $wpdb->get_var("SELECT COUNT(*) FROM $gold_table");
            $distinct_dates = $wpdb->get_var("SELECT COUNT(DISTINCT gold_date) FROM $gold_table");
            $carats = $wpdb->get_col("SELECT DISTINCT carat FROM $gold_table ORDER BY carat");
            
            ?>
            
            <table class="widefat">
                <tr>
                    <th><?php echo esc_html__('First Available Date', 'infi-gold-manager'); ?></th>
                    <td><?php echo $earliest_date ? esc_html($earliest_date) : esc_html__('No data', 'infi-gold-manager'); ?></td>
                </tr>
                <tr>
                    <th><?php echo esc_html__('Last Available Date', 'infi-gold-manager'); ?></th>
                    <td><?php echo $latest_date ? esc_html($latest_date) : esc_html__('No data', 'infi-gold-manager'); ?></td>
                </tr>
                <tr>
                    <th><?php echo esc_html__('Total Date Range', 'infi-gold-manager'); ?></th>
                    <td>
                        <?php
                        if ($earliest_date && $latest_date) {
                            $date1 = new DateTime($earliest_date);
                            $date2 = new DateTime($latest_date);
                            $interval = $date1->diff($date2);
                            echo esc_html($interval->days + 1) . ' ' . esc_html__('days', 'infi-gold-manager');
                        } else {
                            echo esc_html__('No data', 'infi-gold-manager');
                        }
                        ?>
                    </td>
                </tr>
                <tr>
                    <th><?php echo esc_html__('Total Records', 'infi-gold-manager'); ?></th>
                    <td><?php echo esc_html($total_entries); ?></td>
                </tr>
                <tr>
                    <th><?php echo esc_html__('Distinct Dates', 'infi-gold-manager'); ?></th>
                    <td><?php echo esc_html($distinct_dates); ?></td>
                </tr>
                <tr>
                    <th><?php echo esc_html__('Available Carats', 'infi-gold-manager'); ?></th>
                    <td><?php echo !empty($carats) ? esc_html(implode(', ', $carats)) : esc_html__('None', 'infi-gold-manager'); ?></td>
                </tr>
            </table>
        </div>
    </div>
    <?php
}

/**
 * تحميل بيانات الذهب التاريخية
 */
function infi_load_historical_gold_data($days = 30) {
    try {
        // الحصول على مفتاح API من الإعدادات
        $settings = get_option('infi_gold_manager_settings', []);
        $api_key = isset($settings['metals_api_key']) ? $settings['metals_api_key'] : '';
        
        if (empty($api_key)) {
            return [
                'status' => 'error',
                'message' => 'Metals API key is missing'
            ];
        }
        
        // تحديد النطاق الزمني
        $end_date = date('Y-m-d');
        $start_date = date('Y-m-d', strtotime("-$days days"));
        
        infi_gold_log("Loading historical gold prices from $start_date to $end_date");
        
        // الحصول على التواريخ التي لديها بيانات بالفعل
        global $wpdb;
        $gold_table = INFI_MAIN_PREFIX  . 'infi_gold_prices';
        $existing_dates = $wpdb->get_col($wpdb->prepare(
            "SELECT DISTINCT gold_date FROM $gold_table WHERE gold_date BETWEEN %s AND %s",
            $start_date,
            $end_date
        ));
        
        // تحديد التواريخ المفقودة
        $all_dates = [];
        $current_date = new DateTime($start_date);
        $end_datetime = new DateTime($end_date);
        
        while ($current_date <= $end_datetime) {
            $date_str = $current_date->format('Y-m-d');
            if (!in_array($date_str, $existing_dates)) {
                $all_dates[] = $date_str;
            }
            $current_date->modify('+1 day');
        }
        
        if (empty($all_dates)) {
            return [
                'status' => 'error',
                'message' => 'No missing dates found in the specified range'
            ];
        }
        
        // العيارات المطلوبة
        $carats = [24, 22, 21, 18, 14, 12];
        $entry_count = 0;
        
        // احصل على سعر الصرف من usd إلى USD للتحويل العكسي
        // افتراضيًا نستخدم قيمة تقديرية إذا كان API لا يوفر هذه المعلومات
        $usd_to_usd = 1.1; // قيمة تقريبية
        
        foreach ($all_dates as $date) {
            infi_gold_log("Fetching gold price for date: $date");
            
            // استعلام عن سعر الذهب في تاريخ معين
            $endpoint = "https://metals-api.com/api/{$date}?access_key={$api_key}&base=usd&symbols=XAU";
            
            $response = wp_remote_get($endpoint, [
                'timeout' => 30,
                'headers' => [
                    'Accept' => 'application/json'
                ]
            ]);
            
            if (is_wp_error($response)) {
                infi_gold_log('API request failed: ' . $response->get_error_message(), 'error');
                continue;
            }
            
            $status_code = wp_remote_retrieve_response_code($response);
            if ($status_code !== 200) {
                infi_gold_log("API returned error status code: $status_code for date $date", 'error');
                continue;
            }
            
            $body = wp_remote_retrieve_body($response);
            $data = json_decode($body, true);
            
            if (!isset($data['success']) || $data['success'] !== true) {
                $error_message = isset($data['error']['message']) ? $data['error']['message'] : 'Unknown error';
                infi_gold_log("API error for date $date: $error_message", 'error');
                continue;
            }
            
            if (!isset($data['rates']['XAU'])) {
                infi_gold_log("Gold price data not found in API response for date $date", 'error');
                continue;
            }
            
            // سعر الأونصة باليورو
            $xau_oz_price = 1 / $data['rates']['XAU']; // تحويل لأن API يعطي عدد XAU لكل يورو
            
            // حساب أسعار العيارات المختلفة
            // 1 أونصة = 31.1034768 جرام
            $xau_gram_price = $xau_oz_price / 31.1034768;
            
            $prices = [];
            
            // إضافة سعر الذهب عيار 24 (الأونصة)
            $prices[] = [
                'metal' => 'gold',
                'carat' => '24k_oz',
                'price_usd' => $xau_oz_price
            ];
            
            // إضافة سعر الذهب عيار 24 (الجرام)
            $prices[] = [
                'metal' => 'gold',
                'carat' => '24k',
                'price_usd' => $xau_gram_price
            ];
            
            // حساب أسعار العيارات الأخرى
            foreach ($carats as $carat) {
                if ($carat == 24) {
                    continue; // تم إضافته بالفعل
                }
                
                $purity = $carat / 24;
                $price = $xau_gram_price * $purity;
                
                $prices[] = [
                    'metal' => 'gold',
                    'carat' => $carat . 'k',
                    'price_usd' => $price
                ];
            }
            
            // حفظ الأسعار لهذا اليوم
            $current_time = current_time('mysql', true);
            
            foreach ($prices as $price) {
                $result = $wpdb->insert(
                    $gold_table,
                    [
                        'fetch_date' => $current_time,
                        'gold_date' => $date,
                        'metal' => $price['metal'],
                        'carat' => $price['carat'],
                        'price_usd' => $price['price_usd']
                    ],
                    ['%s', '%s', '%s', '%s', '%f']
                );
                
                if ($result !== false) {
                    $entry_count++;
                }
            }
            
            // تأخير صغير بين الطلبات لتجنب تجاوز حدود API
            sleep(1);
        }
        
        infi_gold_log("Historical data load completed: $entry_count entries added");
        
        // مسح التخزين المؤقت بعد تحديث البيانات
        infi_clear_cache();
        
        return [
            'status' => 'success',
            'count' => $entry_count,
            'message' => "Successfully loaded historical gold prices ($entry_count entries)"
        ];
        
    } catch (Exception $e) {
        infi_gold_log('Error loading historical gold data: ' . $e->getMessage(), 'error');
        return [
            'status' => 'error',
            'message' => $e->getMessage()
        ];
    }
}






/**
 * الدالة الرئيسية لجلب أسعار العملات
 */
function infi_fetch_currency_rates() {
    try {
        $settings = get_option('infi_gold_manager_settings', []);
        $currency_api_provider = isset($settings['currency_api_provider']) ? $settings['currency_api_provider'] : 'exchangeratesapi';
        
        switch ($currency_api_provider) {
            case 'exchangerate-api':
                return infi_fetch_currency_rates_open_er();
            case 'exchangeratesapi':
            default:
                return infi_fetch_currency_rates_exchange_rates_api();
        }
    } catch (Exception $e) {
        infi_gold_log('Error in fetch_currency_rates: ' . $e->getMessage(), 'error');
        return false;
    }
}

/**
 * جلب أسعار العملات من ExchangeRatesAPI
 */
function infi_fetch_currency_rates_exchange_rates_api() {
    try {
        $settings = get_option('infi_gold_manager_settings', []);
        $api_key = isset($settings['exchange_rates_api_key']) ? $settings['exchange_rates_api_key'] : '';
        
        if (empty($api_key)) {
            throw new Exception('Exchange Rates API key is missing');
        }
        
        infi_gold_log('Starting to fetch currency rates from ExchangeRatesAPI');
        
        $endpoint = "https://api.exchangeratesapi.io/v1/latest?access_key={$api_key}&base=usd";
        
        $response = wp_remote_get($endpoint, [
            'timeout' => 30,
            'headers' => [
                'Accept' => 'application/json'
            ]
        ]);
        
        if (is_wp_error($response)) {
            throw new Exception('API request failed: ' . $response->get_error_message());
        }
        
        $status_code = wp_remote_retrieve_response_code($response);
        if ($status_code !== 200) {
            throw new Exception("API returned error status code: $status_code");
        }
        
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        
        infi_gold_log('Exchange Rates API Response: ' . print_r($data, true), 'debug');
        
        if (!isset($data['success']) || $data['success'] !== true) {
            $error_message = isset($data['error']['message']) ? $data['error']['message'] : 'Unknown error';
            throw new Exception("API error: $error_message");
        }
        
        if (!isset($data['rates']) || !is_array($data['rates'])) {
            throw new Exception('Currency rates data not found in API response');
        }
        
        $data['rates']['usd'] = 1.0;
        
        infi_gold_log('Successfully fetched currency rates for ' . count($data['rates']) . ' currencies from ExchangeRatesAPI');
        return $data['rates'];
        
    } catch (Exception $e) {
        infi_gold_log('Failed to fetch currency rates from ExchangeRatesAPI: ' . $e->getMessage(), 'error');
        infi_update_last_update_status('exchange_rates_api', 'error', $e->getMessage());
        return false;
    }
}

/**
 * جلب أسعار العملات من ExchangeRate-API (open.er-api.com)
 */
function infi_fetch_currency_rates_open_er() {
    try {
        infi_gold_log('Starting to fetch currency rates from ExchangeRate-API (open.er-api.com)');
        
        $endpoint = "https://open.er-api.com/v6/latest/usd";
        
        $response = wp_remote_get($endpoint, [
            'timeout' => 30,
            'headers' => [
                'Accept' => 'application/json'
            ]
        ]);
        
        if (is_wp_error($response)) {
            throw new Exception('API request failed: ' . $response->get_error_message());
        }
        
        $status_code = wp_remote_retrieve_response_code($response);
        if ($status_code !== 200) {
            throw new Exception("API returned error status code: $status_code");
        }
        
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        
        infi_gold_log('ExchangeRate-API Response: ' . print_r($data, true), 'debug');
        
        if (!isset($data['result']) || $data['result'] !== 'success') {
            $error_message = isset($data['error']) ? $data['error'] : 'Unknown error';
            throw new Exception("API error: $error_message");
        }
        
        if (!isset($data['rates']) || !is_array($data['rates'])) {
            throw new Exception('Currency rates data not found in API response');
        }
        
        infi_gold_log('Successfully fetched currency rates for ' . count($data['rates']) . ' currencies from ExchangeRate-API');
        return $data['rates'];
        
    } catch (Exception $e) {
        infi_gold_log('Failed to fetch currency rates from ExchangeRate-API: ' . $e->getMessage(), 'error');
        infi_update_last_update_status('exchange_rates_api', 'error', $e->getMessage());
        return false;
    }
}

/**
 * التحقق من صلاحية API بدون مفتاح (ExchangeRate-API)
 */
function infi_verify_open_er_api() {
    try {
        $endpoint = "https://open.er-api.com/v6/latest/usd";
        
        $response = wp_remote_get($endpoint, [
            'timeout' => 30,
            'headers' => [
                'Accept' => 'application/json'
            ]
        ]);
        
        if (is_wp_error($response)) {
            throw new Exception('API request failed: ' . $response->get_error_message());
        }
        
        $status_code = wp_remote_retrieve_response_code($response);
        if ($status_code !== 200) {
            throw new Exception("API returned error status code: $status_code");
        }
        
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        
        if (!isset($data['result']) || $data['result'] !== 'success') {
            throw new Exception('Invalid API response format');
        }
        
        return [
            'status' => 'success',
            'message' => 'ExchangeRate-API connection is valid (no API key needed)'
        ];
        
    } catch (Exception $e) {
        infi_gold_log('ExchangeRate-API verification failed: ' . $e->getMessage(), 'error');
        return [
            'status' => 'error',
            'message' => $e->getMessage()
        ];
    }
}



require_once INFI_GOLD_MANAGER_PATH . 'pagescreate.php';
