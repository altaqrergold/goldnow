<?php
/**
 * شورت كود لعرض أسعار الذهب والعملات بتصميم متجاوب مع حاسبة مدمجة
 * 
 * الاستخدام: [gold_currency_display type="gold_24k" currency="SAR" country="السعودية" heading="سعر الذهب عيار 24" show_related="yes" show_calculator="yes"]
 */

function gold_currency_display_shortcode($atts) {
    // لتجنب التعارض مع المتغيرات العامة
    global $currency_names, $carat_labels, $wpdb;

    // الإعدادات الافتراضية
    $settings = get_option('infi_gold_manager_settings', []);
    $default_currency = isset($settings['default_currency']) ? $settings['default_currency'] : 'USD';
    $default_country_code = isset($settings['default_country_code']) ? $settings['default_country_code'] : 'sa';
    
    // الكشف عن الدولة والعملة
    $detected_currency = $default_currency;
    $detected_country = 'السعودية'; // القيمة الافتراضية
    
    // إذا تم تحديد رمز الدولة الافتراضي في الإعدادات، استخدمه
    if (!empty($default_country_code)) {
        $country_info = get_user_country_info($default_country_code);
        if ($country_info) {
            $detected_country = $country_info['name'];
            // نستخدم العملة من إعدادات الإضافة بدلاً من ربطها تلقائيًا بالدولة
        }
    }
    
    // إذا كان كشف الدولة عبر Cloudflare نشطًا
    if (isset($settings['user_country_detection']) && $settings['user_country_detection'] === 'cloudflare' && 
        isset($_SERVER["HTTP_CF_IPCOUNTRY"]) && !empty($_SERVER["HTTP_CF_IPCOUNTRY"])) {
        $country_code = strtolower($_SERVER["HTTP_CF_IPCOUNTRY"]);
        $country_info = get_user_country_info($country_code);
        if ($country_info) {
            $detected_country = $country_info['name'];
            // نحتفظ بالعملة من الإعدادات
        }
    }
    
    // تعريف قائمة أنواع الذهب والعملات المتاحة
    $available_types = [
        // الجنيهات
        'gold_pound_21' => ['name' => 'جنيه الذهب 8 جرام عيار 21', 'carat' => '21k', 'weight' => 8],
        'gold_pound_22' => ['name' => 'جنيه الذهب 8 جرام عيار 22', 'carat' => '22k', 'weight' => 8],
        'gold_pound_24' => ['name' => 'جنيه الذهب 8 جرام عيار 24', 'carat' => '24k', 'weight' => 8],
        
        // السبائك
        'gold_bar_1g' => ['name' => 'سبيكة ذهب 1 جرام', 'carat' => '24k', 'weight' => 1],
        'gold_bar_2.5g' => ['name' => 'سبيكة الذهب 2.5 جرام', 'carat' => '24k', 'weight' => 2.5],
        'gold_bar_5g' => ['name' => 'سبيكة الذهب 5 جرام', 'carat' => '24k', 'weight' => 5],
        'gold_bar_8g' => ['name' => 'سبيكة الذهب 8 جرام', 'carat' => '24k', 'weight' => 8],
        'gold_bar_10g' => ['name' => 'سبيكة الذهب 10 جرام', 'carat' => '24k', 'weight' => 10],
        'gold_bar_20g' => ['name' => 'سبيكة الذهب 20 جرام', 'carat' => '24k', 'weight' => 20],
        'gold_bar_50g' => ['name' => 'سبيكة الذهب 50 جرام', 'carat' => '24k', 'weight' => 50],
        'gold_bar_100g' => ['name' => 'سبيكة الذهب 100 جرام', 'carat' => '24k', 'weight' => 100],
        'gold_bar_500g' => ['name' => 'سبيكة الذهب 500 جرام', 'carat' => '24k', 'weight' => 500],
        'gold_bar_1000g' => ['name' => 'سبيكة الذهب 1000 جرام', 'carat' => '24k', 'weight' => 1000],
        
        // الأونصات
        'gold_ounce' => ['name' => 'سبيكة الذهب أونصة', 'carat' => '24k_oz', 'weight' => 1],
        'gold_half_ounce' => ['name' => 'سبيكة الذهب نصف أونصة', 'carat' => '24k_oz', 'weight' => 0.5],
        
        // العيارات
        'gold_14k' => ['name' => 'عيار 14', 'carat' =>'14k', 'weight' => 1],
        'gold_22k' => ['name' => 'عيار 22', 'carat' => '22k', 'weight' => 1],
        'gold_21k' => ['name' => 'عيار 21', 'carat' => '21k', 'weight' => 1],
        'gold_18k' => ['name' => 'عيار 18', 'carat' => '18k', 'weight' => 1],
        
        // بصيغة أخرى
        'gold_24k' => ['name' => 'سعر جرام الذهب عيار 24', 'carat' => '24k', 'weight' => 1],
        'gold_22k_gram' => ['name' => 'سعر جرام الذهب عيار 22', 'carat' => '22k', 'weight' => 1],
        'gold_21k_gram' => ['name' => 'سعر جرام الذهب عيار 21', 'carat' => '21k', 'weight' => 1],
        'gold_18k_gram' => ['name' => 'سعر جرام الذهب عيار 18', 'carat' => '18k', 'weight' => 1],
        'gold_14k_gram' => ['name' => 'سعر جرام الذهب عيار 14', 'carat' => '14k', 'weight' => 1],
        'gold_ounce_price' => ['name' => 'سعر أونصة الذهب', 'carat' => '24k_oz', 'weight' => 1],
        
        // العملات
        'currency_usd' => ['name' => 'دولار أمريكي', 'currency_code' => 'USD'],
        'currency_eur' => ['name' => 'يورو', 'currency_code' => 'EUR'],
        'currency_gbp' => ['name' => 'جنيه إسترليني', 'currency_code' => 'GBP'],
        'currency_chf' => ['name' => 'فرنك سويسري', 'currency_code' => 'CHF'],
        'currency_jpy' => ['name' => 'ين ياباني', 'currency_code' => 'JPY'],
    ];
    
    // تحديد المعلمات المستلمة
    $atts = shortcode_atts([
        'type' => 'gold_24k',                  // نوع السعر المعروض
        'currency' => $default_currency,        // استخدام العملة الافتراضية من الإعدادات
        'country' => $detected_country,         // الدولة للعرض
        'heading' => '',                        // عنوان القسم
        'show_related' => 'yes',                // عرض الأنواع ذات الصلة
        'primary_color' => '',                  // اللون الرئيسي
        'text_color' => '',                     // لون النص
        'decimals' => 2,                        // عدد الأرقام العشرية
        'related_count' => 6,                   // عدد العناصر ذات الصلة
        'links_base' => '',                     // الرابط الأساسي للصفحات
        'show_date' => 'yes',                   // عرض تاريخ التحديث
        'show_header' => 'no',                  // عرض منطقة الرأس
        'show_calculator' => 'yes',             // عرض الحاسبة
        'calculator_title' => '',               // عنوان الحاسبة
        'calculator_position' => 'after_price', // موضع الحاسبة (after_price/before_related/after_related)
    ], $atts, 'gold_currency_display');
    
    // تنظيف وتجهيز المعلمات
    $type = sanitize_text_field($atts['type']);
    $currency = strtoupper(sanitize_text_field($atts['currency']));
    $country = sanitize_text_field($atts['country']);
    $show_related = $atts['show_related'] === 'yes';
    $show_date = $atts['show_date'] === 'yes';
    $show_header = $atts['show_header'] === 'yes';
    $show_calculator = $atts['show_calculator'] === 'yes';
    $calculator_position = sanitize_text_field($atts['calculator_position']);
    $decimals = intval($atts['decimals']);
    $related_count = intval($atts['related_count']);
    $links_base = trailingslashit(sanitize_text_field($atts['links_base']));
    
    // تحديد اللون الرئيسي
    $primary_color = empty($atts['primary_color']) ? get_theme_mod('infi_default_color', '#ffb301') : sanitize_hex_color($atts['primary_color']);
    $text_color = empty($atts['text_color']) ? '#333333' : sanitize_hex_color($atts['text_color']);

    // تحقق من وجود النوع المطلوب
    if (!isset($available_types[$type])) {
        return '<div class="text-red-500 p-4 text-center">نوع غير صحيح: ' . esc_html($type) . '</div>';
    }
    
    // المعلومات حول النوع المطلوب
    $type_info = $available_types[$type];
    
    // الحصول على الاسم والعنوان
    $item_name = $type_info['name'];
    $heading = !empty($atts['heading']) ? sanitize_text_field($atts['heading']) : $item_name;
    
    // السعر الحالي
    $current_price = 0;
    $currency_symbol = '';
    $currency_name = $currency;
    
    // قائمة أسماء العملات
    $currency_names = [
        'USD' => 'دولار أمريكي',
        'EUR' => 'يورو',
        'GBP' => 'جنيه إسترليني',
        'AED' => 'درهم إماراتي',
        'SAR' => 'ريال سعودي',
        'KWD' => 'دينار كويتي',
        'BHD' => 'دينار بحريني',
        'QAR' => 'ريال قطري',
        'OMR' => 'ريال عماني',
        'JOD' => 'دينار أردني',
        'EGP' => 'جنيه مصري',
        'IQD' => 'دينار عراقي',
        'CHF' => 'فرنك سويسري',
        'JPY' => 'ين ياباني',
    ];
    
    // استخدام اسم العملة إذا كان متوفرًا
    if (isset($currency_names[$currency])) {
        $currency_name = $currency_names[$currency];
    }
    
    // حساب السعر - للذهب
    if (isset($type_info['carat'])) {
        // استخدام دالة موجودة أو حساب مباشر
        $base_price = do_shortcode('[infi_gold_price carat="' . esc_attr($type_info['carat']) . '" currency="' . esc_attr($currency) . '" decimals="' . esc_attr($decimals) . '"]');
        
        if ($base_price !== 'N/A' && $base_price !== 'Error') {
            $base_price = floatval(str_replace(',', '', $base_price));
            $current_price = $base_price * $type_info['weight'];
        }
    }
    // للعملات
    else if (isset($type_info['currency_code'])) {
        // الحصول على سعر الصرف
        $exchange_rate = do_shortcode('[infi_currency_rate currency="' . esc_attr($type_info['currency_code']) . '" decimals="' . esc_attr($decimals) . '"]');
        
        if ($exchange_rate !== 'N/A' && $exchange_rate !== 'Error') {
            $current_price = floatval(str_replace(',', '', $exchange_rate));
        }
    }
    
    // تنسيق السعر للعرض
    $formatted_price = number_format($current_price, $decimals);
    
    // الحصول على تاريخ آخر تحديث
    $last_update = '';
    if ($show_date) {
        // جلب المنطقة الزمنية من WordPress
        $timezone_string = wp_timezone_string();
        
        // ضبط المنطقة الزمنية في PHP لضمان التوافق
        date_default_timezone_set($timezone_string);
        
        // الحصول على بيانات آخر تحديث من قاعدة البيانات
        $last_update_table = INFI_MAIN_PREFIX . 'infi_last_updates';
        $latest_update = $wpdb->get_var("SELECT MAX(last_update) FROM $last_update_table");
        
        // تنسيق التاريخ باستخدام wp_date
        if ($latest_update) {
            // تحويل التاريخ إلى المنطقة الزمنية المحلية
            try {
                $date = new DateTime($latest_update, new DateTimeZone('UTC')); // التاريخ من قاعدة البيانات بـ UTC
                $date->setTimezone(new DateTimeZone($timezone_string)); // تحويل إلى المنطقة الزمنية المحلية
                $formatted_last_update = wp_date(get_option('date_format') . ' ' . get_option('time_format'), $date->getTimestamp());
            } catch (Exception $e) {
                // في حالة وجود خطأ (مثل تاريخ غير صالح)
                $formatted_last_update = wp_date(get_option('date_format') . ' ' . get_option('time_format'), time());
            }
        } else {
            // إذا لم يكن هناك تاريخ، استخدام الوقت الحالي
            $formatted_last_update = wp_date(get_option('date_format') . ' ' . get_option('time_format'), time());
        }
        
        // تعريف مصفوفة للمناطق الزمنية ومدنها بالعربية
        $timezone_cities = array(
            'Asia/Riyadh' => 'توقيت الرياض',
            'Asia/Dubai' => 'توقيت دبي',
            'Asia/Kuwait' => 'توقيت الكويت',
            'Asia/Bahrain' => 'توقيت المنامة',
            'Asia/Qatar' => 'توقيت الدوحة',
            'Asia/Muscat' => 'توقيت مسقط',
            'Asia/Aden' => 'توقيت عدن',
            'Asia/Baghdad' => 'توقيت بغداد',
            'Asia/Amman' => 'توقيت عمان',
            'Asia/Damascus' => 'توقيت دمشق',
            'Asia/Beirut' => 'توقيت بيروت',
            'Asia/Jerusalem' => 'توقيت القدس',
            'Africa/Cairo' => 'توقيت القاهرة',
            'Africa/Khartoum' => 'توقيت الخرطوم',
            'Africa/Tripoli' => 'توقيت طرابلس',
            'Africa/Tunis' => 'توقيت تونس',
            'Africa/Algiers' => 'توقيت الجزائر',
            'Africa/Casablanca' => 'توقيت الدار البيضاء',
            'Africa/Nouakchott' => 'توقيت نواكشوط',
            'UTC' => 'التوقيت العالمي'
        );
        
        // تحديد اسم المدينة المناسب أو استخدام المنطقة الزمنية إذا لم تكن موجودة
        $city_time = isset($timezone_cities[$timezone_string]) ? $timezone_cities[$timezone_string] : 'توقيت ' . $timezone_string;
        
        // إنشاء نص آخر تحديث
        $last_update = 'آخر تحديث: ' . esc_html($formatted_last_update) . ' (' . esc_html($city_time) . ')';
    }
    
    // العناصر ذات الصلة للعرض
    $related_items = [];
    /*
    if ($show_related) {
        // معرفة العناصر ذات الصلة
        if (strpos($type, 'gold_') === 0) {
            // للذهب - البحث عن عيارات أخرى أو أوزان مشابهة
            if (isset($type_info['carat'])) {
                foreach ($available_types as $key => $info) {
                    if ($key !== $type && isset($info['carat']) && 
                        (($type_info['carat'] === $info['carat'] && $type_info['weight'] !== $info['weight']) || 
                         ($type_info['carat'] !== $info['carat'] && $type_info['weight'] === $info['weight']))) {
                        $related_items[$key] = $info;
                        if (count($related_items) >= $related_count) break;
                    }
                }
            }
        } else if (strpos($type, 'currency_') === 0) {
            // للعملات - عرض عملات أخرى
            foreach ($available_types as $key => $info) {
                if ($key !== $type && strpos($key, 'currency_') === 0) {
                    $related_items[$key] = $info;
                    if (count($related_items) >= $related_count) break;
                }
            }
        }
    }
    */
    
    // إعداد عنصر الحاسبة
    $calculator_html = '';
    if ($show_calculator && isset($type_info['carat'])) {
        // تحديد عنوان الحاسبة
        $calc_title = !empty($atts['calculator_title']) ? sanitize_text_field($atts['calculator_title']) : 'حاسبة ' . $item_name;
        $calc_weight = isset($type_info['weight']) ? $type_info['weight'] : 1;
        
        // تحديد القيمة الأولية لسعر الجرام (وليس الإجمالي)
        $gram_price = $base_price; // سعر الجرام في العملة المحددة
        
        // إنشاء معرّف فريد للحاسبة
        $calc_id = 'gold-calc-' . uniqid();
        
        $calculator_html = '
        <div class="gold-calculator p-6 bg-gray-50 border-t border-gray-200">
            <h3 class="text-lg font-semibold mb-4">' . esc_html($calc_title) . '</h3>
            
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                <div>
                    <label class="block text-gray-700 mb-2 font-medium" for="' . $calc_id . '-weight">الوزن بالجرام</label>
                    <input type="number" id="' . $calc_id . '-weight" class="w-full p-3 border border-gray-300 rounded-md shadow-sm focus:ring-2 focus:border-transparent" 
                           value="' . esc_attr($calc_weight) . '" min="0.01" step="0.01">
                </div>
                
                <div>
                    <label class="block text-gray-700 mb-2 font-medium" for="' . $calc_id . '-price">سعر الجرام (' . esc_html($currency) . ')</label>
                    <input type="number" id="' . $calc_id . '-price" class="w-full p-3 border border-gray-300 rounded-md shadow-sm focus:ring-2 focus:border-transparent" 
                           value="' . esc_attr($gram_price) . '" min="0.01" step="0.01">
                </div>
            </div>
            
            <div class="p-4 rounded-md" style="background-color: ' . esc_attr(adjust_brightness($primary_color, -30)) . '15;">
                <div class="text-gray-700 mb-2 font-semibold text-center">القيمة الإجمالية</div>
                <div id="' . $calc_id . '-total" class="text-2xl font-bold text-center" style="color: ' . esc_attr($primary_color) . ';">
                    ' . number_format($calc_weight * $gram_price, $decimals) . '
                </div>
                <div class="text-gray-600 text-center text-sm">' . esc_html($currency_name) . '</div>
            </div>
            
            <script>
            document.addEventListener("DOMContentLoaded", function() {
                const weightInput = document.getElementById("' . $calc_id . '-weight");
                const priceInput = document.getElementById("' . $calc_id . '-price");
                const totalDisplay = document.getElementById("' . $calc_id . '-total");
                
                function calculateTotal() {
                    const weight = parseFloat(weightInput.value) || 0;
                    const price = parseFloat(priceInput.value) || 0;
                    const total = weight * price;
                    
                    totalDisplay.textContent = total.toLocaleString(undefined, {
                        minimumFractionDigits: ' . $decimals . ',
                        maximumFractionDigits: ' . $decimals . '
                    });
                }
                
                // حساب القيمة الأولية
                calculateTotal();
                
                // إضافة مستمعي الأحداث
                weightInput.addEventListener("input", calculateTotal);
                priceInput.addEventListener("input", calculateTotal);
            });
            </script>
        </div>';
    }
    
    // بناء المخرج HTML
    $output = '<div class="gold-price-container w-full max-w-4xl mx-auto bg-white shadow-lg rounded-lg overflow-hidden">';
    
    // رأس القسم (مخفي افتراضيًا)
    if ($show_header) {
        $output .= '<div class="py-6 px-8 bg-gradient-to-r from-' . esc_attr(str_replace('#', '', $primary_color)) . '-600 to-' . esc_attr(str_replace('#', '', $primary_color)) . '-400 text-white">';
        $output .= '<h2 class="text-2xl font-bold text-center mb-4">' . esc_html($heading) . '</h2>';
        $output .= '<p class="text-center opacity-80 text-sm">' . esc_html($heading) . ' في ' . esc_html($country) . ' اليوم هو:</p>';
        $output .= '</div>';
    }
    
    // عرض السعر
    $output .= '<div class="py-8 px-4 text-center">';
    $output .= '<div class="text-5xl font-bold mb-4" style="color: ' . esc_attr($primary_color) . '">' . esc_html($formatted_price) . '</div>';
    $output .= '<div class="text-lg text-gray-600">' . esc_html($currency_name) . '</div>';
    
    if (!empty($last_update)) {
        $output .= '<div class="text-sm text-gray-500 mt-3">' . $last_update . '</div>';
    }
    $output .= '</div>';
    

    
    // العناصر ذات الصلة
    if ($show_related && !empty($related_items)) {
        $output .= '<div class="px-8 py-6 bg-gray-50 border-t border-gray-200">';
        $output .= '<h3 class="text-lg font-semibold mb-4">اعرف أكثر:</h3>';
        $output .= '<div class="grid grid-cols-2 md:grid-cols-3 gap-4">';
        
        foreach ($related_items as $item_type => $item_info) {
            $item_url = !empty($links_base) ? $links_base . $item_type . '/' : '#' . $item_type;
            $item_display_name = $item_info['name'];
            
            // إضافة "سعر" قبل الاسم إذا لم تكن موجودة بالفعل
            if (strpos($item_display_name, 'سعر') !== 0) {
                $item_display_name = 'سعر ' . $item_display_name . ' في ' . $country;
            }
            
            $output .= '<a href="' . esc_url($item_url) . '" class="bg-white p-4 rounded shadow-sm hover:shadow-md transition-shadow flex flex-col items-center text-center">';
            $output .= '<div class="text-sm font-medium" style="color: ' . esc_attr($primary_color) . '">' . esc_html($item_display_name) . '</div>';
            $output .= '</a>';
        }
        
        $output .= '</div>'; // Closing grid
        $output .= '</div>'; // Closing related section
    }
    


   
   // إضافة CSS التخصيصي
    $output .= '
    <style>
        .from-' . str_replace('#', '', $primary_color) . '-600 { background-color: ' . esc_attr($primary_color) . '; }
        .to-' . str_replace('#', '', $primary_color) . '-400 { background-color: ' . esc_attr(adjust_brightness($primary_color, 20)) . '; }
        .focus\:ring-2:focus { box-shadow: 0 0 0 3px ' . esc_attr(adjust_brightness($primary_color, 20)) . '50; border-color: ' . esc_attr($primary_color) . '; }
        input:focus { outline: none; }
    </style>';
    
    return $output;
}
add_shortcode('gold_currency_display', 'gold_currency_display_shortcode');

// دالة مساعدة لضبط سطوع اللون (تفتيح/تغميق)
function adjust_brightness($hex, $steps) {
    // تحويل اللون الست عشري إلى RGB
    $hex = str_replace('#', '', $hex);
    
    $r = hexdec(substr($hex, 0, 2));
    $g = hexdec(substr($hex, 2, 2));
    $b = hexdec(substr($hex, 4, 2));
    
    // ضبط السطوع
    $r = max(0, min(255, $r + $steps));
    $g = max(0, min(255, $g + $steps));
    $b = max(0, min(255, $b + $steps));
    
    // تحويل عودة إلى الهيكس
    return '#' . str_pad(dechex($r), 2, '0', STR_PAD_LEFT) . 
           str_pad(dechex($g), 2, '0', STR_PAD_LEFT) . 
           str_pad(dechex($b), 2, '0', STR_PAD_LEFT);
}