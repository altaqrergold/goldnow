<?php
/**
 * Plugin Name: Goldx Manager for WordPress lite
 * Plugin URI: https://www.infinyteam.com/
 * Description: إضافة لعرض أسعار الذهب بمختلف العيارات والعملات باستخدام Metals-API وExchangeRatesAPI
 * Version: 1.0.0
 * Author: محمد الرسموكي
 * Author URI: https://www.infinyteam.com/
 * Text Domain: infi-gold-manager-lite
 * 
 * Path: /gold-manager-for-wordpress.php
 * 
 * ملاحظة مهمة: ازالة حقوق المطور من هذه الإضافة يلغي الدعم الفني، وقد يسبب أخطاء في الموقع. ابقائك للحقوق دعم لمجهود المطور، ولا يؤثر في أداء موقعك.
 */


// إيقاف الوصول المباشر
if (!defined('ABSPATH')) {
    exit;
}


function infi_clear_all_transients() {
    global $wpdb;
    $wpdb->query("DELETE FROM $wpdb->options WHERE option_name LIKE '%_transient_%'");
}
//infi_clear_all_transients();
// تعريف الثوابت
define('INFI_GOLD_MANAGER_VERSION', '1.0.0');
define('INFI_GOLD_MANAGER_PATH', plugin_dir_path(__FILE__));
define('INFI_GOLD_MANAGER_URL', plugin_dir_url(__FILE__));
define('INFI_GOLD_MANAGER_BASENAME', plugin_basename(__FILE__));

// إضافة نظام تسجيل الأخطاء
function infi_gold_log($message, $level = 'info') {
    
    /*
    $log_file = INFI_GOLD_MANAGER_PATH . 'debug.log';
    $timestamp = date('[Y-m-d H:i:s]');
    $log_message = $timestamp . ' [' . strtoupper($level) . '] ' . (is_array($message) || is_object($message) ? print_r($message, true) : $message) . PHP_EOL;
    error_log($log_message, 3, $log_file);*/
}

// تسجيل معلومات الخطأ عندما تحدث
function infi_gold_error_handler($errno, $errstr, $errfile, $errline) {
    $error_message = "PHP Error [$errno]: $errstr in $errfile on line $errline";
    infi_gold_log($error_message, 'error');
    return false; // للسماح بالتعامل الافتراضي مع الخطأ
}
set_error_handler('infi_gold_error_handler');

// لمعالجة الأخطاء الغير محتجزة
function infi_gold_exception_handler($exception) {
    $error_message = "Uncaught Exception: " . $exception->getMessage() . " in " . $exception->getFile() . " on line " . $exception->getLine();
    infi_gold_log($error_message, 'critical');
}
set_exception_handler('infi_gold_exception_handler');

// لتصحيح أخطاء الـ 400
function infi_gold_http_api_debug($response, $context, $class, $args, $url) {
    if (is_wp_error($response)) {
        infi_gold_log("WP Error on API request to $url: " . $response->get_error_message(), 'error');
    } else if (isset($response['response']['code']) && $response['response']['code'] >= 400) {
        infi_gold_log("HTTP Error {$response['response']['code']} on API request to $url", 'error');
        infi_gold_log("Request args: " . print_r($args, true), 'debug');
        infi_gold_log("Response body: " . print_r($response['body'], true), 'debug');
    }
    return $response;
}
add_filter('http_api_debug', 'infi_gold_http_api_debug', 10, 5);

// تضمين الملفات اللازمة
require_once INFI_GOLD_MANAGER_PATH . 'database.php';
require_once INFI_GOLD_MANAGER_PATH . 'api-handler.php';
require_once INFI_GOLD_MANAGER_PATH . 'admin.php';
require_once INFI_GOLD_MANAGER_PATH . 'shortcodes.php';
require_once INFI_GOLD_MANAGER_PATH . 'functions.php';
require_once INFI_GOLD_MANAGER_PATH . 'cron.php';

// تنشيط الإضافة
register_activation_hook(__FILE__, 'infi_gold_manager_activate');
function infi_gold_manager_activate() {
    try {
        infi_gold_log('Plugin activation started', 'info');
        infi_create_database_tables();
        infi_setup_default_options();
        infi_setup_cron_schedules();
        infi_gold_log('Plugin activated successfully', 'info');
    } catch (Exception $e) {
        infi_gold_log('Error during plugin activation: ' . $e->getMessage(), 'error');
    }
}

// إلغاء تنشيط الإضافة
register_deactivation_hook(__FILE__, 'infi_gold_manager_deactivate');
function infi_gold_manager_deactivate() {
    try {
        infi_gold_log('Plugin deactivation started', 'info');
        infi_clear_cron_schedules();
        infi_gold_log('Plugin deactivated successfully', 'info');
    } catch (Exception $e) {
        infi_gold_log('Error during plugin deactivation: ' . $e->getMessage(), 'error');
    }
}

// إعداد الإضافة
add_action('plugins_loaded', 'infi_gold_manager_init');
function infi_gold_manager_init() {
    try {
        infi_gold_log('Plugin initialization started', 'info');
        
        // إضافة قائمة الإدارة
        add_action('admin_menu', 'infi_gold_manager_admin_menu');
        
        // تسجيل الشورت كود
        infi_register_shortcodes();
        
        infi_gold_log('Plugin initialized successfully', 'info');
    } catch (Exception $e) {
        infi_gold_log('Error during plugin initialization: ' . $e->getMessage(), 'error');
    }
}

// أضف رابط إعدادات في صفحة الإضافات
add_filter('plugin_action_links_' . INFI_GOLD_MANAGER_BASENAME, 'infi_gold_manager_settings_link');
function infi_gold_manager_settings_link($links) {
    $settings_link = '<a href="' . admin_url('admin.php?page=infi-gold-manager') . '">' . __('Settings', 'infi-gold-manager') . '</a>';
    array_unshift($links, $settings_link);
    return $links;
}

















/**
 * مصفوفة للدول العربية والمصطلحات المختلفة للسعر
 */
function get_arab_countries_price_terms() {
    return [
        'sa' => ['name' => 'السعودية', 'price_term' => 'سعر'],
        'ae' => ['name' => 'الإمارات', 'price_term' => 'سعر'],
        'kw' => ['name' => 'الكويت', 'price_term' => 'سعر'],
        'qa' => ['name' => 'قطر', 'price_term' => 'سعر'],
        'bh' => ['name' => 'البحرين', 'price_term' => 'سعر'],
        'om' => ['name' => 'عمان', 'price_term' => 'سعر'],
        'eg' => ['name' => 'مصر', 'price_term' => 'سعر'],
        'ma' => ['name' => 'المغرب', 'price_term' => 'ثمن'],
        'dz' => ['name' => 'الجزائر', 'price_term' => 'سعر'],
        'tn' => ['name' => 'تونس', 'price_term' => 'سعر'],
        'ly' => ['name' => 'ليبيا', 'price_term' => 'سعر'],
        'jo' => ['name' => 'الأردن', 'price_term' => 'سعر'],
        'lb' => ['name' => 'لبنان', 'price_term' => 'سعر'],
        'sy' => ['name' => 'سوريا', 'price_term' => 'سعر'],
        'iq' => ['name' => 'العراق', 'price_term' => 'سعر'],
        'ye' => ['name' => 'اليمن', 'price_term' => 'سعر'],
        'sd' => ['name' => 'السودان', 'price_term' => 'سعر'],
        'ps' => ['name' => 'فلسطين', 'price_term' => 'سعر'],
        'mr' => ['name' => 'موريتانيا', 'price_term' => 'سعر'],
        'so' => ['name' => 'الصومال', 'price_term' => 'سعر'],
        'dj' => ['name' => 'جيبوتي', 'price_term' => 'سعر'],
        'km' => ['name' => 'جزر القمر', 'price_term' => 'سعر']
    ];
}

/**
 * شورت كود لعرض الدول المدعومة كقائمة ul/li متجاوبة
 */
function gold_country_list_shortcode($atts) {
    // الإعدادات الافتراضية
    $atts = shortcode_atts([
        'items_per_row' => 3,          // عدد العناصر في كل صف
        'show_all' => 'yes',            // عرض كل الدول أم لا
        'countries' => '',              // الدول المحددة (مفصولة بفواصل) إذا كان show_all = no
        'title_prefix' => '',           // نص قبل عنوان البند (اختياري)
        'title_suffix' => 'اليوم',      // نص بعد عنوان البند
        'accent_color' => '',           // لون التمييز (اختياري)
        'use_price_term' => 'yes',      // استخدام مصطلح السعر حسب الدولة
        'default_price_term' => 'سعر',  // مصطلح السعر الافتراضي
        'flag_size' => '24px',          // حجم علم الدولة
        'link_type' => 'default',       // نوع الرابط: 'default', 'subdomain', 'path'
        'domain' => home_url(),  // النطاق الأساسي (إذا كان link_type ليس 'default')
        'slug_type' => 'code', 
        'path_prefix' => 'country',            // بادئة المسار (إذا كان link_type = 'path')
        'target' => '_self'             // هدف الرابط (_self, _blank, إلخ)
    ], $atts, 'gold_country_list');
    
    // تحويل المدخلات
    $items_per_row = intval($atts['items_per_row']);
    $show_all = ($atts['show_all'] === 'yes');
    $use_price_term = ($atts['use_price_term'] === 'yes');
    $default_price_term = sanitize_text_field($atts['default_price_term']);
    $title_prefix = sanitize_text_field($atts['title_prefix']);
    $title_suffix = sanitize_text_field($atts['title_suffix']);
    $accent_color = get_theme_mod('infi_default_color', '#ffb301');
    $flag_size = sanitize_text_field($atts['flag_size']);
    $link_type = sanitize_text_field($atts['link_type']);
    $domain = sanitize_text_field($atts['domain']);
    $slug_type = sanitize_text_field($atts['slug_type']);
    $path_prefix = sanitize_text_field($atts['path_prefix']);
    $target = sanitize_text_field($atts['target']);
    
    // الحصول على مصفوفة الدول والمصطلحات
    $countries_terms = get_arab_countries_price_terms();
    
    // إذا كان show_all = no، استخدم فقط الدول المحددة
    $selected_countries = [];
    if (!$show_all && !empty($atts['countries'])) {
        $country_codes = explode(',', $atts['countries']);
        foreach ($country_codes as $code) {
            $code = trim($code);
            if (isset($countries_terms[$code])) {
                $selected_countries[$code] = $countries_terms[$code];
            }
        }
    } else {
        $selected_countries = $countries_terms;
    }
    
    // تحديد لون التمييز (استخدام لون الموقع الافتراضي إذا لم يتم تحديد لون)
    if (empty($accent_color)) {
        $accent_color = get_theme_mod('infi_default_color', '#ffb301');
    }
    
    // المسار الأساسي للأعلام
    $flags_base_path = get_template_directory_uri() . '/assets/flags/';
    
    // قاموس الأسماء الإنجليزية (يمكن توسيعه حسب الحاجة)
    $english_names = [
        'sa' => 'saudi-arabia',
        'kw' => 'kuwait',
        'bh' => 'bahrain',
        'qa' => 'qatar',
        'ae' => 'uae',
        'eg' => 'egypt',
        'ma' => 'morocco',
        'iq' => 'iraq',


       
        'om' => 'oman',


        'tr' => 'turkey',
        'dz' => 'algeria',
        'jo' => 'jordan',
        'lb' => 'lebanon',
        'sy' => 'syria',
        'ps' => 'palestine',
        'ye' => 'yemen',
        'ly' => 'libya',
        'tn' => 'tunisia',
        'sd' => 'sudan'
    ];
    
    // حساب العرض الإجمالي بناءً على عدد العناصر في الصف
    $item_width = 100 / $items_per_row;
    
    // بدء بناء المخرجات باستخدام ul/li
    $output = '<div class="gold-countries-container p-0">';
    $output .= '<ul class="gold-countries-list" style="list-style: none; padding: 0; margin: 0; display: flex; flex-wrap: wrap; margin: -10px;">';
    
    foreach ($selected_countries as $code => $country_info) {
        $country_name = $country_info['name'];
        $price_term = $use_price_term ? $country_info['price_term'] : $default_price_term;
        $flag_url = $flags_base_path . $code . '.svg';
        
        // الحصول على المعرف المناسب للرابط
        $english_name = isset($english_names[$code]) ? $english_names[$code] : $code;
        
        if ($slug_type === 'code') {
            $url_slug = strtolower($code);
        } else {
            $url_slug = strtolower(str_replace(' ', '-', $english_name));
        }
        
        // إنشاء الرابط حسب النوع المطلوب
        if ($link_type === 'subdomain') {
            $country_url =  $url_slug . '.' . $domain . '/';
        } elseif ($link_type === 'path') {
            if (!empty($path_prefix)) {
                $country_url =  $domain . '/' . $path_prefix . '/' . $url_slug;
            } else {
                $country_url = $domain . '/' . $url_slug;
            }
        } else {
            // النمط الافتراضي: /country/code
            $country_url = home_url('/country/' . $code);
        }
        
        // تكوين عنوان الرابط
        $link_title = $title_prefix;
        $link_title .= (!empty($link_title) ? ' ' : '') . $price_term . ' الذهب في ' . $country_name;
        $link_title .= (!empty($title_suffix) ? ' ' . $title_suffix : '');
        
        $output .= '<li class="gold-country-item" style="flex: 0 0 ' . $item_width . '%; max-width: ' . $item_width . '%; padding: 10px; box-sizing: border-box; margin: 0;">';
        $output .= '<a href="' . esc_url($country_url) . '" class="gold-country-link" target="' . esc_attr($target) . '" style="display: flex; align-items: center; padding: 10px; background-color: #f9f9f9; border-radius: 8px; text-decoration: none; color: #333; transition: all 0.3s ease;">';
        $output .= '<img src="' . esc_url($flag_url) . '" alt="' . esc_attr($country_name) . '" style="width: ' . esc_attr($flag_size) . '; height: auto; margin-left: 10px; border-radius: 50%;">';
        $output .= '<span class="gold-country-text" style="flex-grow: 1;">' . esc_html($link_title) . '</span>';
        $output .= '<i class="fa-solid fa-angle-left" style="margin-right: 5px; font-size: 12px; color: ' . esc_attr($accent_color) . ';"></i>';
        $output .= '</a>';
        $output .= '</li>';
    }
    
    $output .= '</ul>'; // Closing the ul
    $output .= '</div>'; // gold-countries-container
    
    // إضافة CSS للتحوير عند تمرير المؤشر وجعل التصميم متجاوب
    $output .= '
    <style>
        .gold-country-link:hover {
            background-color: ' . esc_attr($accent_color) . ' !important;
            color: white !important;
        }
        .gold-country-link:hover i {
            color: white !important;
        }
        
        @media (max-width: 992px) {
            .gold-country-item {
                flex: 0 0 33.33% !important;
                max-width: 33.33% !important;
            }
        }
        
        @media (max-width: 768px) {
            .gold-country-item {
                flex: 0 0 50% !important;
                max-width: 50% !important;
            }
        }
        
        @media (max-width: 480px) {
            .gold-country-item {
                flex: 0 0 100% !important;
                max-width: 100% !important;
            }
        }
    </style>';
    
    return $output;
}
add_shortcode('gold_country_list', 'gold_country_list_shortcode');

/**
 * دالة للحصول على مصفوفة الدول العربية ومصطلحات السعر
 * ملاحظة: يجب استبدال هذه الدالة بدالتك الخاصة إذا كانت موجودة
 */
if (!function_exists('get_arab_countries_price_terms')) {
    function get_arab_countries_price_terms() {
        return [
            'sa' => ['name' => 'السعودية', 'price_term' => 'سعر'],
            'kw' => ['name' => 'الكويت', 'price_term' => 'سعر'],
            'bh' => ['name' => 'البحرين', 'price_term' => 'سعر'],
            'qa' => ['name' => 'قطر', 'price_term' => 'سعر'],
            'ae' => ['name' => 'الإمارات', 'price_term' => 'سعر'],
            'om' => ['name' => 'عمان', 'price_term' => 'سعر'],
            'eg' => ['name' => 'مصر', 'price_term' => 'سعر'],
            'tr' => ['name' => 'تركيا', 'price_term' => 'سعر'],
            'ma' => ['name' => 'المغرب', 'price_term' => 'سعر'],
            'dz' => ['name' => 'الجزائر', 'price_term' => 'سعر'],
            'jo' => ['name' => 'الأردن', 'price_term' => 'سعر'],
            'lb' => ['name' => 'لبنان', 'price_term' => 'سعر'],
            'sy' => ['name' => 'سوريا', 'price_term' => 'سعر'],
            'ps' => ['name' => 'فلسطين', 'price_term' => 'سعر'],
            'iq' => ['name' => 'العراق', 'price_term' => 'سعر'],
            'ye' => ['name' => 'اليمن', 'price_term' => 'سعر'],
            'ly' => ['name' => 'ليبيا', 'price_term' => 'سعر'],
            'tn' => ['name' => 'تونس', 'price_term' => 'سعر'],
            'sd' => ['name' => 'السودان', 'price_term' => 'سعر']
        ];
    }
}


/**
 * شورت كود لعرض تاريخ آخر تحديث لأسعار الذهب وأسعار الصرف كنص بسيط
 */
function gold_simple_last_update_shortcode($atts) {
    // الإعدادات الافتراضية
    $atts = shortcode_atts([
        'type' => 'both',              // نوع التحديث (gold, currency, both)
        'date_format' => '',           // تنسيق التاريخ (اختياري)
        'time_format' => '',           // تنسيق الوقت (اختياري)
        'prefix' => '',     // النص قبل التاريخ
        'suffix' => ''                 // النص بعد التاريخ
    ], $atts, 'gold_simple_last_update');
    
    // تحويل المدخلات
    $type = sanitize_text_field($atts['type']);
    $prefix = sanitize_text_field($atts['prefix']);
    $suffix = sanitize_text_field($atts['suffix']);
    
    // إذا لم يتم تحديد تنسيق، استخدم التنسيق الافتراضي من ووردبريس
    $date_format = !empty($atts['date_format']) ? sanitize_text_field($atts['date_format']) : get_option('date_format');
    $time_format = !empty($atts['time_format']) ? sanitize_text_field($atts['time_format']) : get_option('time_format');
    
    // الحصول على معلومات آخر تحديث
    global $wpdb;
    $last_update_table =  INFI_MAIN_PREFIX . 'infi_last_updates';
    
    $gold_update = null;
    $currency_update = null;
    
    if ($type == 'gold' || $type == 'both') {
        $gold_query = "SELECT last_update FROM $last_update_table WHERE api_type = 'metals_api' ORDER BY last_update DESC LIMIT 1";
        $gold_update = $wpdb->get_var($gold_query);
    }
    
    if ($type == 'currency' || $type == 'both') {
        $currency_query = "SELECT last_update FROM $last_update_table WHERE api_type = 'exchange_rates_api' ORDER BY last_update DESC LIMIT 1";
        $currency_update = $wpdb->get_var($currency_query);
    }
    
    // تحديد أحدث تحديث
    $latest_update = null;
    
    if ($type == 'both' && $gold_update && $currency_update) {
        $gold_timestamp = strtotime($gold_update);
        $currency_timestamp = strtotime($currency_update);
        $latest_update = ($gold_timestamp > $currency_timestamp) ? $gold_update : $currency_update;
    } else if ($type == 'gold' && $gold_update) {
        $latest_update = $gold_update;
    } else if ($type == 'currency' && $currency_update) {
        $latest_update = $currency_update;
    } else if ($gold_update) {
        $latest_update = $gold_update;
    } else if ($currency_update) {
        $latest_update = $currency_update;
    }
    
    // إذا لم يتم العثور على تاريخ تحديث
    if (!$latest_update) {
      //  return 'لا يوجد معلومات عن آخر تحديث';
    }
    
    // تنسيق التاريخ والوقت
    $formatted_date = date_i18n($date_format, strtotime($latest_update));
    $formatted_time = date_i18n($time_format, strtotime($latest_update));
    
    // عرض النص مع التاريخ
    return $prefix . $formatted_date . ' ' . $formatted_time . $suffix;
}
add_shortcode('gold_last_update', 'gold_simple_last_update_shortcode');



function display_gold_last_update() {
    global $wpdb;
    $last_update_table = INFI_MAIN_PREFIX . 'infi_last_updates';
    
    // الحصول على آخر تحديث مباشرة من قاعدة البيانات
    $latest_update_query = "SELECT MAX(last_update) FROM $last_update_table";
    $latest_update = $wpdb->get_var($latest_update_query);
    
    // إذا لم يكن هناك تحديث، استخدم تاريخ اليوم كبديل
    if(empty($latest_update)) {
        $latest_timestamp = current_time('timestamp', true);
    } else {
        $latest_timestamp = strtotime($latest_update);
    }
    
    // استدعاء الشورت كود للحصول على النص المنسق
    $formatted_text = do_shortcode('[gold_last_update type="both" prefix="آخر تحديث: " suffix=""]');
    
    // في حالة عدم وجود نتيجة من الشورت كود
    if(empty($formatted_text)) {
        $formatted_text = 'آخر تحديث: ' . date_i18n(get_option('date_format') . ' ' . get_option('time_format'), $latest_timestamp);
    }
    
    // تنسيق ISO 8601 للخاصية content وdatetime
    $iso_date = date('c', $latest_timestamp);
    
    // عرض التاريخ مع تنسيق HTML مناسب لمحركات البحث
    echo '<div class="gold-price-update" itemprop="dateModified" content="' . esc_attr($iso_date) . '">';
    echo '<time datetime="' . esc_attr($iso_date) . '">';
    echo $formatted_text;
    echo '</time>';
    echo '</div>';
}

require_once INFI_GOLD_MANAGER_PATH . 'shortcodes/gold_currency_display.php';
require_once INFI_GOLD_MANAGER_PATH . 'reportspage.php';


/**
 * التحقق من وجود عمود price_usd في جدول أسعار الذهب وإضافته إذا لم يكن موجودًا
 */
function infi_check_add_price_usd_column() {
    global $wpdb;
    
    // الحصول على اسم الجدول مع البادئة الصحيحة
    $gold_table = INFI_MAIN_PREFIX . 'infi_gold_prices';
    
    // التحقق مما إذا كان الجدول موجود أولاً
    $table_exists = $wpdb->get_var("SHOW TABLES LIKE '{$gold_table}'");
    
    if (!$table_exists) {
        infi_gold_log('جدول أسعار الذهب غير موجود. يرجى تنشيط الإضافة أو إعادة تثبيتها.', 'error');
        return false;
    }
    
    // الحصول على معلومات أعمدة الجدول
    $columns = $wpdb->get_results("SHOW COLUMNS FROM {$gold_table}");
    $column_names = array_map(function($column) {
        return $column->Field;
    }, $columns);
    
    // التحقق من وجود عمود price_usd
    if (!in_array('price_usd', $column_names)) {
        infi_gold_log('عمود price_usd غير موجود في جدول أسعار الذهب. سيتم إضافته الآن.', 'warning');
        
        // إضافة العمود إلى الجدول
        // لا نحدد موقع العمود بعد عمود معين لتجنب الخطأ
        $result = $wpdb->query("ALTER TABLE {$gold_table} ADD COLUMN price_usd DECIMAL(15,6) NOT NULL");
        
        if ($result === false) {
            infi_gold_log('فشل إضافة عمود price_usd: ' . $wpdb->last_error, 'error');
            return false;
        }
        
        infi_gold_log('تم إضافة عمود price_usd بنجاح إلى جدول أسعار الذهب.', 'info');
        return true;
    }
    
    infi_gold_log('عمود price_usd موجود بالفعل في جدول أسعار الذهب.', 'info');
    return true;
}

// تشغيل الدالة عند تحميل الإضافة
add_action('plugins_loaded', 'infi_check_add_price_usd_column', 20);
/**
 * التحقق من وجود الأعمدة المطلوبة في جداول الإضافة وإضافتها إذا كانت مفقودة
 */
function infi_check_and_fix_database_columns() {
    global $wpdb;
    
    // تحقق من جدول أسعار الذهب
    $gold_table = INFI_MAIN_PREFIX . 'infi_gold_prices';
    $table_exists = $wpdb->get_var("SHOW TABLES LIKE '{$gold_table}'");
    
    if ($table_exists) {
        // فحص عمود price_usd
        $price_usd_exists = $wpdb->get_var("SHOW COLUMNS FROM {$gold_table} LIKE 'price_usd'");
        
        if (!$price_usd_exists) {
            infi_gold_log('عمود price_usd غير موجود في جدول أسعار الذهب. سيتم إضافته الآن.', 'warning');
            
            $result = $wpdb->query("ALTER TABLE {$gold_table} ADD COLUMN price_usd DECIMAL(15,6) NOT NULL");
            
            if ($result === false) {
                infi_gold_log('فشل إضافة عمود price_usd: ' . $wpdb->last_error, 'error');
            } else {
                infi_gold_log('تم إضافة عمود price_usd بنجاح إلى جدول أسعار الذهب.', 'info');
            }
        }
    } else {
        infi_gold_log('جدول أسعار الذهب غير موجود.', 'error');
    }
    
    // تحقق من جدول أسعار العملات
    $currency_table = INFI_MAIN_PREFIX . 'infi_currency_rates';
    $table_exists = $wpdb->get_var("SHOW TABLES LIKE '{$currency_table}'");
    
    if ($table_exists) {
        // فحص عمود rate_to_usd
        $rate_to_usd_exists = $wpdb->get_var("SHOW COLUMNS FROM {$currency_table} LIKE 'rate_to_usd'");
        
        if (!$rate_to_usd_exists) {
            infi_gold_log('عمود rate_to_usd غير موجود في جدول أسعار العملات. سيتم إضافته الآن.', 'warning');
            
            $result = $wpdb->query("ALTER TABLE {$currency_table} ADD COLUMN rate_to_usd DECIMAL(15,6) NOT NULL");
            
            if ($result === false) {
                infi_gold_log('فشل إضافة عمود rate_to_usd: ' . $wpdb->last_error, 'error');
            } else {
                infi_gold_log('تم إضافة عمود rate_to_usd بنجاح إلى جدول أسعار العملات.', 'info');
                
                // تحديث عمود rate_to_usd بالبيانات الموجودة في الجدول إذا كان هناك عمود آخر للسعر
                $exchange_rate_exists = $wpdb->get_var("SHOW COLUMNS FROM {$currency_table} LIKE 'exchange_rate'");
                
                if ($exchange_rate_exists) {
                    $wpdb->query("UPDATE {$currency_table} SET rate_to_usd = exchange_rate");
                    infi_gold_log('تم نسخ البيانات من exchange_rate إلى rate_to_usd.', 'info');
                }
            }
        }
    } else {
        infi_gold_log('جدول أسعار العملات غير موجود.', 'error');
    }
}

// تشغيل الدالة عند تحميل الإضافة وقبل تنفيذ أي استعلام
add_action('plugins_loaded', 'infi_check_and_fix_database_columns', 5);

/**
 * إضافة إصلاح مؤقت لمشكلة عمود rate_to_usd غير الموجود في استعلامات البحث
 */
function infi_fix_db_errors() {
    global $wpdb;
    
    // سجّل الخطأ الأخير في قاعدة البيانات
    $last_error = $wpdb->last_error;
    
    // إذا كان الخطأ متعلقًا بعمود rate_to_usd غير موجود
    if (!empty($last_error) && strpos($last_error, "Unknown column 'rate_to_usd'") !== false) {
        // محاولة إنشاء العمود المفقود
        $currency_table = INFI_MAIN_PREFIX . 'infi_currency_rates';
        $rate_to_usd_exists = $wpdb->get_var("SHOW COLUMNS FROM {$currency_table} LIKE 'rate_to_usd'");
        
        if (!$rate_to_usd_exists) {
            $result = $wpdb->query("ALTER TABLE {$currency_table} ADD COLUMN rate_to_usd DECIMAL(15,6) NOT NULL");
            if ($result !== false) {
                infi_gold_log('تم إضافة عمود rate_to_usd تلقائيًا بعد اكتشاف خطأ في الاستعلام.', 'info');
            }
        }
    }
    
    // إذا كان الخطأ متعلقًا بعمود price_usd غير موجود
    if (!empty($last_error) && strpos($last_error, "Unknown column 'price_usd'") !== false) {
        // محاولة إنشاء العمود المفقود
        $gold_table = INFI_MAIN_PREFIX . 'infi_gold_prices';
        $price_usd_exists = $wpdb->get_var("SHOW COLUMNS FROM {$gold_table} LIKE 'price_usd'");
        
        if (!$price_usd_exists) {
            $result = $wpdb->query("ALTER TABLE {$gold_table} ADD COLUMN price_usd DECIMAL(15,6) NOT NULL");
            if ($result !== false) {
                infi_gold_log('تم إضافة عمود price_usd تلقائيًا بعد اكتشاف خطأ في الاستعلام.', 'info');
            }
        }
    }
}

// تسجيل الدالة لمعالجة أخطاء قاعدة البيانات
add_action('wp_db_error', 'infi_fix_db_errors');
