<?php

if (!defined('ABSPATH')) {
    exit;
}




/**
 * تحويل سعر الذهب من عيار إلى آخر
 */
function infi_convert_carat($price, $from_carat, $to_carat) {
    // تحويل عيار الذهب إلى نسبة مئوية
    $from_purity = infi_carat_to_purity($from_carat);
    $to_purity = infi_carat_to_purity($to_carat);
    
    // حساب السعر الجديد
    if ($from_purity > 0) {
        return $price * ($to_purity / $from_purity);
    }
    
    return 0;
}

/**
 * تحويل عيار الذهب إلى نسبة النقاء
 */
function infi_carat_to_purity($carat) {
    // التحويل من النص إلى الرقم (مثال: 24k إلى 24)
    if (is_string($carat)) {
        $carat = preg_replace('/[^0-9.]/', '', $carat);
    }
    
    // تحويل العيار إلى نقاء
    $carat = floatval($carat);
    return $carat / 24;
}

/**
 * تنسيق سعر الذهب مع رمز العملة
 */
function infi_format_price($price, $currency, $decimals = 2) {
    if (!is_numeric($price)) {
        return $price;
    }
    
    $formatted = number_format($price, $decimals);
    
    // إضافة رمز العملة
    switch ($currency) {
        case 'USD':
            return '$' . $formatted;
        case 'usd':
            return '€' . $formatted;
        case 'GBP':
            return '£' . $formatted;
        case 'JPY':
            return '¥' . $formatted;
        case 'AED':
            return $formatted . ' AED';
        case 'SAR':
            return $formatted . ' SAR';
        case 'KWD':
            return $formatted . ' KWD';
        case 'BHD':
            return $formatted . ' BHD';
        case 'QAR':
            return $formatted . ' QAR';
        case 'EGP':
            return $formatted . ' EGP';
        default:
            return $formatted . ' ' . $currency;
    }
}

/**
 * حساب سعر البيع والشراء بناءً على نسبة الهامش
 */
function infi_calculate_buy_sell_prices($price, $currency) {
    // الحصول على نسب البيع والشراء للعملة
    $markup = infi_get_markup_percentages($currency);
    
    // حساب سعر البيع والشراء
    $buy_price = $price * (1 + ($markup['buy_percentage'] / 100));
    $sell_price = $price * (1 - ($markup['sell_percentage'] / 100));
    
    return [
        'buy_price' => $buy_price,
        'sell_price' => $sell_price
    ];
}

/**
 * تحميل ملفات CSS وJavaScript للواجهة الأمامية
 */
function infi_enqueue_frontend_scripts() {
    // للمخططات
    if (
        has_shortcode(get_the_content(), 'infi_gold_chart') ||
        has_shortcode(get_the_content(), 'infi_gold_table') ||
        has_shortcode(get_the_content(), 'infi_gold_change')
    ) {
        wp_enqueue_style('infi-gold-manager-css', INFI_GOLD_MANAGER_URL . 'assets/css/frontend.css', [], INFI_GOLD_MANAGER_VERSION);
        
        // إضافة مكتبة Chart.js للمخططات البيانية
        if (has_shortcode(get_the_content(), 'infi_gold_chart')) {
            wp_enqueue_script('chartjs', 'https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.7.0/chart.min.js', [], '3.7.0', true);
        }
    }
}
add_action('wp_enqueue_scripts', 'infi_enqueue_frontend_scripts');

/**
 * تحميل ملفات CSS وJavaScript للوحة التحكم
 */
function infi_enqueue_admin_scripts($hook) {
    if (strpos($hook, 'infi-gold') !== false) {
        wp_enqueue_style('infi-gold-manager-admin-css', INFI_GOLD_MANAGER_URL . 'assets/css/admin.css', [], INFI_GOLD_MANAGER_VERSION);
        wp_enqueue_script('infi-gold-manager-admin-js', INFI_GOLD_MANAGER_URL . 'assets/js/admin.js', ['jquery'], INFI_GOLD_MANAGER_VERSION, true);
    }
}
add_action('admin_enqueue_scripts', 'infi_enqueue_admin_scripts');

/**
 * إضافة مجلد الأصول عند تنشيط الإضافة
 */
function infi_setup_assets_folder() {
    $assets_dir = INFI_GOLD_MANAGER_PATH . 'assets';
    
    if (!file_exists($assets_dir)) {
        mkdir($assets_dir, 0755, true);
    }
    
    $css_dir = $assets_dir . '/css';
    if (!file_exists($css_dir)) {
        mkdir($css_dir, 0755, true);
    }
    
    $js_dir = $assets_dir . '/js';
    if (!file_exists($js_dir)) {
        mkdir($js_dir, 0755, true);
    }
    
    // إنشاء ملف CSS للواجهة الأمامية
    $frontend_css = $css_dir . '/frontend.css';
    if (!file_exists($frontend_css)) {
        file_put_contents($frontend_css, "
/* Gold Manager Frontend Styles */
.infi-gold-table {
    width: 100%;
    border-collapse: collapse;
    margin: 20px 0;
}
.infi-gold-table th, .infi-gold-table td {
    padding: 10px;
    text-align: center;
    border: 1px solid #ddd;
}
.infi-gold-table th {
    background-color: #f5f5f5;
    font-weight: bold;
}
.infi-gold-table tr:nth-child(even) {
    background-color: #f9f9f9;
}
.infi-gold-table tr:hover {
    background-color: #f0f0f0;
}
.infi-gold-table .positive-change {
    color: green;
}
.infi-gold-table .negative-change {
    color: red;
}
.infi-gold-table-info {
    font-size: 0.9em;
    color: #777;
    text-align: right;
    margin-top: 10px;
}
");
    }
    
    // إنشاء ملف CSS للوحة التحكم
    $admin_css = $css_dir . '/admin.css';
    if (!file_exists($admin_css)) {
        file_put_contents($admin_css, "
/* Gold Manager Admin Styles */
.infi-gold-admin-card {
    max-width: 800px;
    margin-top: 20px;
    padding: 20px;
    background: #fff;
    border: 1px solid #ccd0d4;
    border-radius: 4px;
    box-shadow: 0 1px 1px rgba(0,0,0,.04);
}
.status-success {
    color: green;
    font-weight: bold;
}
.status-error {
    color: red;
    font-weight: bold;
}
.description.error {
    color: red;
    margin: 5px 0 0;
}
.log-line {
    padding: 3px 0;
}
.error-line {
    color: #d63638;
}
.warning-line {
    color: #dba617;
}
.debug-line {
    color: #3582c4;
}
.log-line:hover {
    background-color: #e9e9e9;
}
");
    }
    
    // إنشاء ملف JavaScript للوحة التحكم
    $admin_js = $js_dir . '/admin.js';
    if (!file_exists($admin_js)) {
        file_put_contents($admin_js, "
/**
 * Gold Manager Admin Scripts
 */
jQuery(document).ready(function($) {
    // تحديد العملة عند اختيار صف في جدول نسب البيع والشراء
    $('.infi-gold-markup-table tr').on('click', function() {
        var currency = $(this).data('currency');
        var buy = $(this).data('buy');
        var sell = $(this).data('sell');
        
        if (currency) {
            $('#currency_code').val(currency);
            $('#buy_percentage').val(buy);
            $('#sell_percentage').val(sell);
        }
    });
    
    // تأكيد حذف نسب البيع والشراء
    $('.delete-markup').on('click', function() {
        return confirm('Are you sure you want to delete this markup?');
    });
    
    // تأكيد مسح ملف السجل
    $('#clear-log').on('click', function() {
        return confirm('Are you sure you want to clear the log file?');
    });
});
");
    }
}
add_action('admin_init', 'infi_setup_assets_folder');

/**
 * تحويل رقم العملة إلى الرمز
 */
function infi_currency_symbol($currency_code) {
    $symbols = [
        'USD' => '$',
        'usd' => '€',
        'GBP' => '£',
        'JPY' => '¥',
        'AUD' => 'A$',
        'CAD' => 'C$',
        'CHF' => 'Fr',
        'CNY' => '¥',
        'SEK' => 'kr',
        'NZD' => 'NZ$',
        'INR' => '₹',
        'BRL' => 'R$',
        'RUB' => '₽',
        'KRW' => '₩',
        'TRY' => '₺',
        'ZAR' => 'R',
        'HKD' => 'HK$',
        'AED' => 'د.إ',
        'SAR' => '﷼',
        'KWD' => 'د.ك',
        'BHD' => '.د.ب',
        'QAR' => '﷼',
        'EGP' => 'E£',
    ];
    
    return isset($symbols[$currency_code]) ? $symbols[$currency_code] : $currency_code;
}

/**
 * عرض العملة مع الرمز
 */
function infi_display_currency($currency_code) {
    $symbol = infi_currency_symbol($currency_code);
    
    if ($symbol === $currency_code) {
        return $currency_code;
    }
    
    return $symbol . ' (' . $currency_code . ')';
}

/**
 * تسجيل المستويات المخصصة للتحديثات الدورية بالدقائق
 */
function infi_register_cron_schedules($schedules) {
    $settings = get_option('infi_gold_manager_settings', []);
    $gold_interval = isset($settings['gold_update_interval']) ? intval($settings['gold_update_interval']) : 60;
    $currency_interval = isset($settings['currency_update_interval']) ? intval($settings['currency_update_interval']) : 60;
    
    // التأكد من أن الفترات ليست أقل من 5 دقائق
    $gold_interval = max(5, $gold_interval);
    $currency_interval = max(5, $currency_interval);
    
    $schedules['infi_gold_interval'] = [
        'interval' => $gold_interval * 60,
        'display' => sprintf(__('Every %d minutes', 'infi-gold-manager'), $gold_interval)
    ];
    
    $schedules['infi_currency_interval'] = [
        'interval' => $currency_interval * 60,
        'display' => sprintf(__('Every %d minutes', 'infi-gold-manager'), $currency_interval)
    ];
    
    return $schedules;
}
add_filter('cron_schedules', 'infi_register_cron_schedules');

/**
 * تشغيل Cron الخارجي
 */
function infi_process_external_cron() {
    if (isset($_GET['infi_gold_cron']) && $_GET['infi_gold_cron'] == 1) {
        // التحقق من الرمز المميز للأمان
        if (!isset($_GET['token']) || $_GET['token'] !== md5(AUTH_KEY)) {
            status_header(403);
            die('Access Denied');
        }
        
        // تحديد نوع التحديث (الذهب أو العملات أو كلاهما)
        $update_type = isset($_GET['type']) ? sanitize_text_field($_GET['type']) : 'all';
        
        if ($update_type === 'gold' || $update_type === 'all') {
            infi_update_gold_prices();
        }
        
        if ($update_type === 'currency' || $update_type === 'all') {
            infi_update_currency_rates();
        }
        
        echo 'CRON executed successfully. Type: ' . $update_type;
        exit;
    }
}
add_action('init', 'infi_process_external_cron');

/**
 * حذف البيانات القديمة بشكل دوري
 */
function infi_cleanup_old_data() {
    global $wpdb;
    
    try {
        // حذف البيانات القديمة (أكثر من سنة)
        $one_year_ago = date('Y-m-d', strtotime('-1 year'));
        
        // حذف أسعار الذهب القديمة
        $gold_table = INFI_MAIN_PREFIX  . 'infi_gold_prices';
        $wpdb->query($wpdb->prepare(
            "DELETE FROM $gold_table WHERE gold_date < %s",
            $one_year_ago
        ));
        
        // حذف أسعار العملات القديمة
        $currency_table = INFI_MAIN_PREFIX  . 'infi_currency_rates';
        $wpdb->query($wpdb->prepare(
            "DELETE FROM $currency_table WHERE currency_date < %s",
            $one_year_ago
        ));
        
        infi_gold_log('Cleaned up old data older than ' . $one_year_ago);
        
    } catch (Exception $e) {
        infi_gold_log('Error cleaning up old data: ' . $e->getMessage(), 'error');
    }
}

/**
 * إضافة الرمز الخاص بالإضافة إلى صفحة الرأس
 */
function infi_add_header_code() {
    if (
        has_shortcode(get_the_content(), 'infi_gold_chart') ||
        has_shortcode(get_the_content(), 'infi_gold_table') ||
        has_shortcode(get_the_content(), 'infi_gold_change') ||
        has_shortcode(get_the_content(), 'infi_gold_price') ||
        has_shortcode(get_the_content(), 'infi_gold_price_usd') ||
        has_shortcode(get_the_content(), 'infi_currency_rate') ||
        has_shortcode(get_the_content(), 'infi_gold_extremes')
    ) {
        echo '<style>
            .positive-change { color: green; }
            .negative-change { color: red; }
        </style>';
    }
}
add_action('wp_head', 'infi_add_header_code');

/**
 * تحديث الإعدادات الإفتراضية عند تحديث الإضافة
 */
function infi_update_settings_on_upgrade() {
    $db_version = get_option('infi_gold_manager_version', '0.0.0');
    
    if (version_compare($db_version, INFI_GOLD_MANAGER_VERSION, '<')) {
        // تحديث الإعدادات الإفتراضية
        $default_options = [
            'metals_api_key' => '',
            'exchange_rates_api_key' => '',
            'gold_update_interval' => 60,
            'currency_update_interval' => 60,
            'cron_type' => 'wp_cron',
            'default_buy_percentage' => 1.5,
            'default_sell_percentage' => 2.5,
            'cache_duration' => 30,
            'default_currency' => 'USD'
        ];
        
        $current_settings = get_option('infi_gold_manager_settings', []);
        $updated_settings = array_merge($default_options, $current_settings);
        
        update_option('infi_gold_manager_settings', $updated_settings);
        update_option('infi_gold_manager_version', INFI_GOLD_MANAGER_VERSION);
        
        // إعادة إعداد مجلد الأصول
        infi_setup_assets_folder();
        
        infi_gold_log('Updated plugin from ' . $db_version . ' to ' . INFI_GOLD_MANAGER_VERSION);
    }
}
add_action('admin_init', 'infi_update_settings_on_upgrade');






/**
 * إضافة خيار اللون الافتراضي في تخصيص هوية الموقع
 */
function infi_customize_register($wp_customize) {
    // إضافة قسم جديد
    $wp_customize->add_section('infi_colors_section', array(
        'title'    => 'ألوان الموقع',
        'priority' => 30,
    ));

    // إضافة إعداد اللون الافتراضي
    $wp_customize->add_setting('infi_default_color', array(
        'default'           => '#ffb301', // اللون الافتراضي
        'sanitize_callback' => 'sanitize_hex_color',
        'transport'         => 'refresh',
    ));

    // إضافة عنصر تحكم اللون
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'infi_default_color', array(
        'label'    => 'اللون الافتراضي للموقع',
        'section'  => 'infi_colors_section',
        'settings' => 'infi_default_color',
        'description' => 'حدد اللون الرئيسي الذي سيستخدم في جميع أنحاء الموقع',
    )));

    // يمكنك إضافة المزيد من إعدادات الألوان هنا
    $wp_customize->add_setting('infi_secondary_color', array(
        'default'           => '#ffb301',
        'sanitize_callback' => 'sanitize_hex_color',
        'transport'         => 'refresh',
    ));

    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'infi_secondary_color', array(
        'label'    => 'اللون الثانوي للموقع',
        'section'  => 'infi_colors_section',
        'settings' => 'infi_secondary_color',
        'description' => 'حدد اللون الثانوي للموقع',
    )));

    // إضافة خيار لون النص
    $wp_customize->add_setting('infi_text_color', array(
        'default'           => '#ffb301',
        'sanitize_callback' => 'sanitize_hex_color',
        'transport'         => 'refresh',
    ));

    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'infi_text_color', array(
        'label'    => 'لون النص الرئيسي',
        'section'  => 'infi_colors_section',
        'settings' => 'infi_text_color',
        'description' => 'حدد لون النص الافتراضي للموقع',
    )));
}
add_action('customize_register', 'infi_customize_register');

/**
 * إضافة CSS المخصص إلى رأس الصفحة
 */
function infi_customize_css() {
    ?>
  
    <?php
}
add_action('wp_head', 'infi_customize_css');