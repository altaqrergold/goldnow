<?php
/**
 * إدارة المهام المجدولة (Cron)
 * Path: /cron.php
 */

// منع الوصول المباشر
if (!defined('ABSPATH')) {
    exit;
}

/**
 * إعداد جدولة المهام
 */
function infi_setup_cron_schedules() {
    $settings = get_option('infi_gold_manager_settings', []);
    $cron_type = isset($settings['cron_type']) ? $settings['cron_type'] : 'wp_cron';
    
    // فقط قم بإعداد WP Cron إذا كان مختارًا
    if ($cron_type === 'wp_cron') {
        // جدولة تحديث أسعار الذهب
        if (!wp_next_scheduled('infi_update_gold_prices_event')) {
            wp_schedule_event(time(), 'infi_gold_interval', 'infi_update_gold_prices_event');
            infi_gold_log('Scheduled gold prices update cron job');
        }
        
        // جدولة تحديث أسعار العملات
        if (!wp_next_scheduled('infi_update_currency_rates_event')) {
            wp_schedule_event(time(), 'infi_currency_interval', 'infi_update_currency_rates_event');
            infi_gold_log('Scheduled currency rates update cron job');
        }
        
        // جدولة تنظيف البيانات القديمة (مرة في الأسبوع)
        if (!wp_next_scheduled('infi_cleanup_old_data_event')) {
            wp_schedule_event(time(), 'weekly', 'infi_cleanup_old_data_event');
            infi_gold_log('Scheduled data cleanup cron job');
        }
    }
}

/**
 * إزالة جدولة المهام
 */
function infi_clear_cron_schedules() {
    // إلغاء جدولة تحديث أسعار الذهب
    $timestamp = wp_next_scheduled('infi_update_gold_prices_event');
    if ($timestamp) {
        wp_unschedule_event($timestamp, 'infi_update_gold_prices_event');
    }
    
    // إلغاء جدولة تحديث أسعار العملات
    $timestamp = wp_next_scheduled('infi_update_currency_rates_event');
    if ($timestamp) {
        wp_unschedule_event($timestamp, 'infi_update_currency_rates_event');
    }
    
    // إلغاء جدولة تنظيف البيانات القديمة
    $timestamp = wp_next_scheduled('infi_cleanup_old_data_event');
    if ($timestamp) {
        wp_unschedule_event($timestamp, 'infi_cleanup_old_data_event');
    }
    
    infi_gold_log('Cleared all cron schedules');
}

/**
 * استدعاء دالة تحديث أسعار الذهب
 */
function infi_cron_update_gold_prices() {
    try {
        infi_gold_log('Starting scheduled gold prices update');
        $result = infi_update_gold_prices();
        
        if ($result) {
            infi_gold_log('Scheduled gold prices update completed successfully');
        } else {
            infi_gold_log('Scheduled gold prices update failed', 'error');
        }
    } catch (Exception $e) {
        infi_gold_log('Error in scheduled gold prices update: ' . $e->getMessage(), 'error');
    }
}
add_action('infi_update_gold_prices_event', 'infi_cron_update_gold_prices');

/**
 * استدعاء دالة تحديث أسعار العملات
 */
function infi_cron_update_currency_rates() {
    try {
        infi_gold_log('Starting scheduled currency rates update');
        $result = infi_update_currency_rates();
        
        if ($result) {
            infi_gold_log('Scheduled currency rates update completed successfully');
        } else {
            infi_gold_log('Scheduled currency rates update failed', 'error');
        }
    } catch (Exception $e) {
        infi_gold_log('Error in scheduled currency rates update: ' . $e->getMessage(), 'error');
    }
}
add_action('infi_update_currency_rates_event', 'infi_cron_update_currency_rates');

/**
 * استدعاء دالة تنظيف البيانات القديمة
 */
function infi_cron_cleanup_old_data() {
    try {
        infi_gold_log('Starting scheduled data cleanup');
        infi_cleanup_old_data();
        infi_gold_log('Scheduled data cleanup completed successfully');
    } catch (Exception $e) {
        infi_gold_log('Error in scheduled data cleanup: ' . $e->getMessage(), 'error');
    }
}
add_action('infi_cleanup_old_data_event', 'infi_cron_cleanup_old_data');