<?php
/**
 * تحويل نظام الإضافة للعمل بالدولار بدلاً من اليورو
 * Path: /usd-converter.php
 */

// منع الوصول المباشر
if (!defined('ABSPATH')) {
    exit;
}

// إضافة وظائف للإضافة
add_action('plugins_loaded', 'infi_initialize_usd_conversion', 5);

function infi_initialize_usd_conversion() {
    // التحقق مما إذا كان التحويل قد تم بالفعل
    $conversion_done = get_option('infi_gold_manager_usd_conversion_done', false);
    
    if (!$conversion_done) {
        // إنشاء الجداول الجديدة
        if (infi_create_dollar_based_tables()) {
            // نقل البيانات من الجداول القديمة إلى الجديدة
            if (infi_migrate_to_dollar_based_tables()) {
                // تحديث الخيار للإشارة إلى أن التحويل قد تم
                update_option('infi_gold_manager_usd_conversion_done', true);
                infi_gold_log('USD conversion completed successfully');
            }
        }
    }
}