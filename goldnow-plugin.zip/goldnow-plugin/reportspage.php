<?php
/**
 * صفحة تقرير البيانات
 * تعرض معلومات عن البيانات المحملة من المصادر المختلفة
 * (محدثة لدعم الدولار كعملة أساسية)
 */

// إضافة قائمة فرعية لتقرير البيانات
add_action('admin_menu', 'infi_add_data_report_menu');
function infi_add_data_report_menu() {
    add_submenu_page(
        'infi-gold-manager',
        __('تقرير البيانات', 'infi-gold-manager'),
        __('تقرير البيانات', 'infi-gold-manager'),
        'edit_posts',
        'infi-gold-data-report',
        'infi_gold_manager_data_report_page'
    );
}

/**
 * تحويل أسعار الذهب من اليورو إلى الدولار في قاعدة البيانات
 * تستخدم مرة واحدة فقط لتحويل البيانات القديمة
 */

/**
 * صفحة عرض تقرير البيانات
 */
function infi_gold_manager_data_report_page() {
    global $wpdb;
    
    // جلب إعدادات الإضافة
    $settings = get_option('infi_gold_manager_settings', []);
    $gold_api_provider = isset($settings['api_provider']) ? $settings['api_provider'] : 'metalprice';
    $currency_api_provider = isset($settings['currency_api_provider']) ? $settings['currency_api_provider'] : 'exchangeratesapi';
    
    // جدول آخر تحديث
    $last_update_table = INFI_MAIN_PREFIX . 'infi_last_updates';
    
    // جدول أسعار الذهب
    $gold_table = INFI_MAIN_PREFIX . 'infi_gold_prices';
    
    // جدول أسعار العملات
    $currency_table = INFI_MAIN_PREFIX . 'infi_currency_rates';
    
    // الحصول على آخر تحديث للذهب
    $gold_last_update = $wpdb->get_row(
        "SELECT * FROM $last_update_table WHERE api_type = 'metals_api' ORDER BY last_update DESC LIMIT 1",
        ARRAY_A
    );
    
    // الحصول على آخر تحديث للعملات
    $currency_last_update = $wpdb->get_row(
        "SELECT * FROM $last_update_table WHERE api_type = 'exchange_rates_api' ORDER BY last_update DESC LIMIT 1",
        ARRAY_A
    );
    
    // الحصول على آخر تاريخ لبيانات الذهب في قاعدة البيانات
    $latest_gold_date = $wpdb->get_var("SELECT MAX(gold_date) FROM $gold_table");
    
    // الحصول على آخر تاريخ لبيانات العملات في قاعدة البيانات
    $latest_currency_date = $wpdb->get_var("SELECT MAX(currency_date) FROM $currency_table");
    
    // الحصول على آخر أسعار الذهب لعرض بيانات الموقع (عيار 24)
    $site_gold_price = $wpdb->get_var($wpdb->prepare(
        "SELECT price_usd FROM $gold_table 
         WHERE carat = %s AND gold_date = %s 
         ORDER BY fetch_date DESC LIMIT 1",
        '24k',
        $latest_gold_date
    ));
    
    // ملاحظة: price_usd تحتوي فعلياً على سعر الدولار
    $site_gold_price_usd = $site_gold_price; // الآن نعتبر أن price_usd هو فعلياً بالدولار
    
    // الحصول على معدل اليورو مقابل الدولار
    $usd_usd_rate = $wpdb->get_var($wpdb->prepare(
        "SELECT rate_to_usd FROM $currency_table 
         WHERE currency_code = %s AND currency_date = %s 
         ORDER BY fetch_date DESC LIMIT 1",
        'USD',
        $latest_currency_date
    ));
    
    // محاولة جلب بيانات مباشرة من المصدر للذهب
    $source_gold_price = null;
    try {
        switch ($gold_api_provider) {
            case 'metalprice':
                if (isset($settings['metalprice_api_key']) && !empty($settings['metalprice_api_key'])) {
                    $api_key = $settings['metalprice_api_key'];
                    $endpoint = "https://api.metalpriceapi.com/v1/latest?api_key={$api_key}&base=USD&currencies=XAU";
                    $response = wp_remote_get($endpoint, ['timeout' => 15]);
                    
                    if (!is_wp_error($response) && wp_remote_retrieve_response_code($response) === 200) {
                        $data = json_decode(wp_remote_retrieve_body($response), true);
                        if (isset($data['rates']['XAU'])) {
                            $xau_value = $data['rates']['XAU'];
                            $source_gold_price = 1 / $xau_value; // سعر الأونصة بالدولار
                        }
                    }
                }
                break;
            
            case 'metals-api':
                if (isset($settings['metals_api_key']) && !empty($settings['metals_api_key'])) {
                    $api_key = $settings['metals_api_key'];
                    // تغيير إلى استخدام الدولار كعملة أساسية
                    $endpoint = "https://metals-api.com/api/latest?access_key={$api_key}&base=USD&symbols=XAU";
                    $response = wp_remote_get($endpoint, ['timeout' => 15]);
                    
                    if (!is_wp_error($response) && wp_remote_retrieve_response_code($response) === 200) {
                        $data = json_decode(wp_remote_retrieve_body($response), true);
                        if (isset($data['rates']['XAU'])) {
                            $source_gold_price = 1 / $data['rates']['XAU']; // سعر الأونصة بالدولار
                        }
                    }
                }
                break;
            
            case 'swissquote':
                $endpoint = "https://forex-data-feed.swissquote.com/public-quotes/bboquotes/instrument/XAU/USD";
                $response = wp_remote_get($endpoint, ['timeout' => 15]);
                
                if (!is_wp_error($response) && wp_remote_retrieve_response_code($response) === 200) {
                    $data = json_decode(wp_remote_retrieve_body($response), true);
                    if (is_array($data) && !empty($data)) {
                        foreach ($data as $item) {
                            if (isset($item['spreadProfilePrices'][0]['bid']) && isset($item['spreadProfilePrices'][0]['ask'])) {
                                $bid = floatval($item['spreadProfilePrices'][0]['bid']);
                                $ask = floatval($item['spreadProfilePrices'][0]['ask']);
                                $source_gold_price = ($bid + $ask) / 2; // سعر الأونصة بالدولار
                                break;
                            }
                        }
                    }
                }
                break;
        }
    } catch (Exception $e) {
        $source_gold_price = null;
    }
    
    // محاولة جلب بيانات مباشرة من المصدر للعملات
    $source_usd_usd_rate = null;
    try {
        switch ($currency_api_provider) {
            case 'exchangeratesapi':
                if (isset($settings['exchange_rates_api_key']) && !empty($settings['exchange_rates_api_key'])) {
                    $api_key = $settings['exchange_rates_api_key'];
                    $endpoint = "https://api.exchangeratesapi.io/v1/latest?access_key={$api_key}&base=usd&symbols=USD";
                    $response = wp_remote_get($endpoint, ['timeout' => 15]);
                    
                    if (!is_wp_error($response) && wp_remote_retrieve_response_code($response) === 200) {
                        $data = json_decode(wp_remote_retrieve_body($response), true);
                        if (isset($data['rates']['USD'])) {
                            $source_usd_usd_rate = $data['rates']['USD'];
                        }
                    }
                }
                break;
            
            case 'exchangerate-api':
                $endpoint = "https://open.er-api.com/v6/latest/usd";
                $response = wp_remote_get($endpoint, ['timeout' => 15]);
                
                if (!is_wp_error($response) && wp_remote_retrieve_response_code($response) === 200) {
                    $data = json_decode(wp_remote_retrieve_body($response), true);
                    if (isset($data['rates']['USD'])) {
                        $source_usd_usd_rate = $data['rates']['USD'];
                    }
                }
                break;
        }
    } catch (Exception $e) {
        $source_usd_usd_rate = null;
    }
    
    // ترجمة أسماء مزودي API
    $providers_names = [
        'metalprice' => 'MetalPriceAPI',
        'metals-api' => 'Metals-API',
        'swissquote' => 'Swissquote',
        'exchangeratesapi' => 'ExchangeRatesAPI',
        'exchangerate-api' => 'ExchangeRate-API (Open ER)'
    ];
    
    $gold_provider_name = isset($providers_names[$gold_api_provider]) ? $providers_names[$gold_api_provider] : $gold_api_provider;
    $currency_provider_name = isset($providers_names[$currency_api_provider]) ? $providers_names[$currency_api_provider] : $currency_api_provider;
    
    // معالجة طلب التحويل
    if (isset($_POST['convert_usd_to_usd']) && check_admin_referer('convert_currency_nonce')) {
        $result = convert_usd_to_usd_in_database();
        
        if ($result['status'] === 'success') {
            echo '<div class="notice notice-success is-dismissible"><p>' . esc_html($result['message']) . '</p>';
            echo '<p>' . esc_html__('تم عمل نسخة احتياطية في الجدول: ', 'infi-gold-manager') . esc_html($result['backup_table']) . '</p></div>';
        } else {
            echo '<div class="notice notice-error is-dismissible"><p>' . esc_html($result['message']) . '</p></div>';
        }
    }
    
    // عرض الصفحة
    ?>
    <div class="wrap">
        <h1><?php echo esc_html__('تقرير البيانات', 'infi-gold-manager'); ?></h1>
        
        <div class="card" style="max-width: 800px; margin-top: 20px; padding: 20px; background: #fff; border: 1px solid #ccd0d4; border-radius: 4px; box-shadow: 0 1px 1px rgba(0,0,0,.04);">
            <h2><?php echo esc_html__('ملخص المصادر', 'infi-gold-manager'); ?></h2>
            
            <table class="widefat">
                <tr>
                    <th><?php echo esc_html__('النوع', 'infi-gold-manager'); ?></th>
                    <th><?php echo esc_html__('المصدر المستخدم', 'infi-gold-manager'); ?></th>
                    <th><?php echo esc_html__('آخر تحديث في المصدر', 'infi-gold-manager'); ?></th>
                    <th><?php echo esc_html__('آخر تحديث في الموقع', 'infi-gold-manager'); ?></th>
                </tr>
                <tr>
                    <td><strong><?php echo esc_html__('أسعار الذهب', 'infi-gold-manager'); ?></strong></td>
                    <td><?php echo esc_html($gold_provider_name); ?></td>
                    <td>
                        <?php 
                        if (!empty($gold_last_update)) {
                            echo esc_html(date_i18n(get_option('date_format') . ' ' . get_option('time_format'), strtotime($gold_last_update['last_update'])));
                        } else {
                            echo esc_html__('غير متوفر', 'infi-gold-manager');
                        }
                        ?>
                    </td>
                    <td>
                        <?php 
                        if (!empty($latest_gold_date)) {
                            echo esc_html(date_i18n(get_option('date_format'), strtotime($latest_gold_date)));
                        } else {
                            echo esc_html__('غير متوفر', 'infi-gold-manager');
                        }
                        ?>
                    </td>
                </tr>
                <tr>
                    <td><strong><?php echo esc_html__('أسعار العملات', 'infi-gold-manager'); ?></strong></td>
                    <td><?php echo esc_html($currency_provider_name); ?></td>
                    <td>
                        <?php 
                        if (!empty($currency_last_update)) {
                            echo esc_html(date_i18n(get_option('date_format') . ' ' . get_option('time_format'), strtotime($currency_last_update['last_update'])));
                        } else {
                            echo esc_html__('غير متوفر', 'infi-gold-manager');
                        }
                        ?>
                    </td>
                    <td>
                        <?php 
                        if (!empty($latest_currency_date)) {
                            echo esc_html(date_i18n(get_option('date_format'), strtotime($latest_currency_date)));
                        } else {
                            echo esc_html__('غير متوفر', 'infi-gold-manager');
                        }
                        ?>
                    </td>
                </tr>
            </table>
        </div>
        
        <div class="card" style="max-width: 800px; margin-top: 20px; padding: 20px; background: #fff; border: 1px solid #ccd0d4; border-radius: 4px; box-shadow: 0 1px 1px rgba(0,0,0,.04);">
            <h2><?php echo esc_html__('مقارنة بيانات الذهب', 'infi-gold-manager'); ?></h2>
            
            <table class="widefat">
                <tr>
                    <th><?php echo esc_html__('النوع', 'infi-gold-manager'); ?></th>
                    <th><?php echo esc_html__('سعر المصدر (USD)', 'infi-gold-manager'); ?></th>
                    <th><?php echo esc_html__('سعر الموقع (USD)', 'infi-gold-manager'); ?></th>
                    <th><?php echo esc_html__('الفرق', 'infi-gold-manager'); ?></th>
                </tr>
                <tr>
                    <td><strong><?php echo esc_html__('أونصة الذهب', 'infi-gold-manager'); ?></strong></td>
                    <td>
                        <?php 
                        if ($source_gold_price !== null) {
                            echo esc_html(number_format($source_gold_price, 2)) . ' USD';
                        } else {
                            echo esc_html__('غير متوفر', 'infi-gold-manager');
                        }
                        ?>
                    </td>
                    <td>
                        <?php 
                        if ($site_gold_price !== null) {
                            $site_gold_price_oz = floatval($site_gold_price_usd) * 31.1034768;
                            echo esc_html(number_format($site_gold_price_oz, 2)) . ' USD';
                        } else {
                            echo esc_html__('غير متوفر', 'infi-gold-manager');
                        }
                        ?>
                    </td>
                    <td>
                        <?php 
                        if ($source_gold_price !== null && $site_gold_price !== null) {
                            $site_gold_price_oz = floatval($site_gold_price_usd) * 31.1034768;
                            $difference = $site_gold_price_oz - $source_gold_price;
                            $difference_percent = ($difference / $source_gold_price) * 100;
                            
                            $color = $difference_percent > 0 ? '#28a745' : ($difference_percent < 0 ? '#dc3545' : '#6c757d');
                            echo '<span style="color: ' . $color . ';">' . number_format($difference_percent, 2) . '%</span>';
                        } else {
                            echo esc_html__('غير متوفر', 'infi-gold-manager');
                        }
                        ?>
                    </td>
                </tr>
                <tr>
                    <td><strong><?php echo esc_html__('جرام الذهب عيار 24', 'infi-gold-manager'); ?></strong></td>
                    <td>
                        <?php 
                        if ($source_gold_price !== null) {
                            $gram_price = $source_gold_price / 31.1034768;
                            echo esc_html(number_format($gram_price, 2)) . ' USD';
                        } else {
                            echo esc_html__('غير متوفر', 'infi-gold-manager');
                        }
                        ?>
                    </td>
                    <td>
                        <?php 
                        if ($site_gold_price !== null) {
                            echo esc_html(number_format(floatval($site_gold_price_usd), 2)) . ' USD';
                        } else {
                            echo esc_html__('غير متوفر', 'infi-gold-manager');
                        }
                        ?>
                    </td>
                    <td>
                        <?php 
                        if ($source_gold_price !== null && $site_gold_price !== null) {
                            $source_gold_price_gram = $source_gold_price / 31.1034768;
                            $difference = floatval($site_gold_price_usd) - $source_gold_price_gram;
                            $difference_percent = ($difference / $source_gold_price_gram) * 100;
                            
                            $color = $difference_percent > 0 ? '#28a745' : ($difference_percent < 0 ? '#dc3545' : '#6c757d');
                            echo '<span style="color: ' . $color . ';">' . number_format($difference_percent, 2) . '%</span>';
                        } else {
                            echo esc_html__('غير متوفر', 'infi-gold-manager');
                        }
                        ?>
                    </td>
                </tr>
            </table>
        </div>
        
        <div class="card" style="max-width: 800px; margin-top: 20px; padding: 20px; background: #fff; border: 1px solid #ccd0d4; border-radius: 4px; box-shadow: 0 1px 1px rgba(0,0,0,.04);">
            <h2><?php echo esc_html__('مقارنة بيانات العملات', 'infi-gold-manager'); ?></h2>
            
            <table class="widefat">
                <tr>
                    <th><?php echo esc_html__('العملة', 'infi-gold-manager'); ?></th>
                    <th><?php echo esc_html__('سعر المصدر (usd/USD)', 'infi-gold-manager'); ?></th>
                    <th><?php echo esc_html__('سعر الموقع (usd/USD)', 'infi-gold-manager'); ?></th>
                    <th><?php echo esc_html__('الفرق', 'infi-gold-manager'); ?></th>
                </tr>
                <tr>
                    <td><strong><?php echo esc_html__('الدولار الأمريكي (USD)', 'infi-gold-manager'); ?></strong></td>
                    <td>
                        <?php 
                        if ($source_usd_usd_rate !== null) {
                            echo esc_html(number_format($source_usd_usd_rate, 4)) . ' usd/USD';
                        } else {
                            echo esc_html__('غير متوفر', 'infi-gold-manager');
                        }
                        ?>
                    </td>
                    <td>
                        <?php 
                        if ($usd_usd_rate !== null) {
                            echo esc_html(number_format(floatval($usd_usd_rate), 4)) . ' usd/USD';
                        } else {
                            echo esc_html__('غير متوفر', 'infi-gold-manager');
                        }
                        ?>
                    </td>
                    <td>
                        <?php 
                        if ($source_usd_usd_rate !== null && $usd_usd_rate !== null) {
                            $difference = floatval($usd_usd_rate) - $source_usd_usd_rate;
                            $difference_percent = ($difference / $source_usd_usd_rate) * 100;
                            
                            $color = $difference_percent > 0 ? '#28a745' : ($difference_percent < 0 ? '#dc3545' : '#6c757d');
                            echo '<span style="color: ' . $color . ';">' . number_format($difference_percent, 2) . '%</span>';
                        } else {
                            echo esc_html__('غير متوفر', 'infi-gold-manager');
                        }
                        ?>
                    </td>
                </tr>
            </table>
        </div>
        
        <div class="card" style="max-width: 800px; margin-top: 20px; padding: 20px; background: #fff; border: 1px solid #ccd0d4; border-radius: 4px; box-shadow: 0 1px 1px rgba(0,0,0,.04);">
            <h2><?php echo esc_html__('حالة التحديثات', 'infi-gold-manager'); ?></h2>
            
            <table class="widefat">
                <tr>
                    <th><?php echo esc_html__('النوع', 'infi-gold-manager'); ?></th>
                    <th><?php echo esc_html__('الحالة', 'infi-gold-manager'); ?></th>
                    <th><?php echo esc_html__('الرسالة', 'infi-gold-manager'); ?></th>
                </tr>
                <tr>
                    <td><strong><?php echo esc_html__('أسعار الذهب', 'infi-gold-manager'); ?></strong></td>
                    <td>
                        <?php 
                        if (!empty($gold_last_update)) {
                            $status_class = $gold_last_update['status'] === 'success' ? 'status-success' : 'status-error';
                            echo '<span class="' . esc_attr($status_class) . '">' . esc_html($gold_last_update['status']) . '</span>';
                        } else {
                            echo esc_html__('غير متوفر', 'infi-gold-manager');
                        }
                        ?>
                    </td>
                    <td>
                        <?php 
                        if (!empty($gold_last_update) && !empty($gold_last_update['message'])) {
                            echo esc_html($gold_last_update['message']);
                        } else {
                            echo '-';
                        }
                        ?>
                    </td>
                </tr>
                <tr>
                    <td><strong><?php echo esc_html__('أسعار العملات', 'infi-gold-manager'); ?></strong></td>
                    <td>
                        <?php 
                        if (!empty($currency_last_update)) {
                            $status_class = $currency_last_update['status'] === 'success' ? 'status-success' : 'status-error';
                            echo '<span class="' . esc_attr($status_class) . '">' . esc_html($currency_last_update['status']) . '</span>';
                        } else {
                            echo esc_html__('غير متوفر', 'infi-gold-manager');
                        }
                        ?>
                    </td>
                    <td>
                        <?php 
                        if (!empty($currency_last_update) && !empty($currency_last_update['message'])) {
                            echo esc_html($currency_last_update['message']);
                        } else {
                            echo '-';
                        }
                        ?>
                    </td>
                </tr>
            </table>
        </div>
        
        <div class="card" style="max-width: 800px; margin-top: 20px; padding: 20px; background: #fff; border: 1px solid #ccd0d4; border-radius: 4px; box-shadow: 0 1px 1px rgba(0,0,0,.04);">
            <h2><?php echo esc_html__('إحصائيات البيانات', 'infi-gold-manager'); ?></h2>
            
            <?php
            // عدد سجلات الذهب
            $gold_count = $wpdb->get_var("SELECT COUNT(*) FROM $gold_table");
            
            // عدد سجلات العملات
            $currency_count = $wpdb->get_var("SELECT COUNT(*) FROM $currency_table");
            
            // أول تاريخ لبيانات الذهب
            $first_gold_date = $wpdb->get_var("SELECT MIN(gold_date) FROM $gold_table");
            
            // أول تاريخ لبيانات العملات
            $first_currency_date = $wpdb->get_var("SELECT MIN(currency_date) FROM $currency_table");
            
            // عدد العيارات المختلفة المسجلة
            $carats_count = $wpdb->get_var("SELECT COUNT(DISTINCT carat) FROM $gold_table");
            
            // عدد العملات المختلفة المسجلة
            $currencies_count = $wpdb->get_var("SELECT COUNT(DISTINCT currency_code) FROM $currency_table");
            ?>
            
            <table class="widefat">
            <tr>
                    <th><?php echo esc_html__('نوع البيانات', 'infi-gold-manager'); ?></th>
                    <th><?php echo esc_html__('عدد السجلات', 'infi-gold-manager'); ?></th>
                    <th><?php echo esc_html__('أول تاريخ', 'infi-gold-manager'); ?></th>
                    <th><?php echo esc_html__('آخر تاريخ', 'infi-gold-manager'); ?></th>
                    <th><?php echo esc_html__('العناصر المختلفة', 'infi-gold-manager'); ?></th>
                </tr>
                <tr>
                    <td><strong><?php echo esc_html__('أسعار الذهب', 'infi-gold-manager'); ?></strong></td>
                    <td><?php echo esc_html(number_format($gold_count)); ?></td>
                    <td>
                        <?php 
                        if (!empty($first_gold_date)) {
                            echo esc_html(date_i18n(get_option('date_format'), strtotime($first_gold_date)));
                        } else {
                            echo '-';
                        }
                        ?>
                    </td>
                    <td>
                        <?php 
                        if (!empty($latest_gold_date)) {
                            echo esc_html(date_i18n(get_option('date_format'), strtotime($latest_gold_date)));
                        } else {
                            echo '-';
                        }
                        ?>
                    </td>
                    <td><?php echo esc_html($carats_count) . ' ' . esc_html__('عيار', 'infi-gold-manager'); ?></td>
                </tr>
                <tr>
                    <td><strong><?php echo esc_html__('أسعار العملات', 'infi-gold-manager'); ?></strong></td>
                    <td><?php echo esc_html(number_format($currency_count)); ?></td>
                    <td>
                        <?php 
                        if (!empty($first_currency_date)) {
                            echo esc_html(date_i18n(get_option('date_format'), strtotime($first_currency_date)));
                        } else {
                            echo '-';
                        }
                        ?>
                    </td>
                    <td>
                        <?php 
                        if (!empty($latest_currency_date)) {
                            echo esc_html(date_i18n(get_option('date_format'), strtotime($latest_currency_date)));
                        } else {
                            echo '-';
                        }
                        ?>
                    </td>
                    <td><?php echo esc_html($currencies_count) . ' ' . esc_html__('عملة', 'infi-gold-manager'); ?></td>
                </tr>
            </table>
        </div>
        
        <div class="card" style="max-width: 800px; margin-top: 20px; padding: 20px; background: #fff; border: 1px solid #ccd0d4; border-radius: 4px; box-shadow: 0 1px 1px rgba(0,0,0,.04);">
            <h2><?php echo esc_html__('أحدث أسعار الذهب', 'infi-gold-manager'); ?></h2>
            
            <?php
            // الحصول على أحدث أسعار الذهب لجميع العيارات
            $gold_prices = $wpdb->get_results($wpdb->prepare(
                "SELECT t1.* FROM $gold_table t1
                INNER JOIN (
                    SELECT carat, MAX(fetch_date) AS max_date
                    FROM $gold_table
                    WHERE gold_date = %s
                    GROUP BY carat
                ) t2 ON t1.carat = t2.carat AND t1.fetch_date = t2.max_date
                WHERE t1.gold_date = %s
                ORDER BY t1.carat",
                $latest_gold_date,
                $latest_gold_date
            ), ARRAY_A);
            
            if (!empty($gold_prices)):
            ?>
            <table class="widefat">
                <tr>
                    <th><?php echo esc_html__('العيار', 'infi-gold-manager'); ?></th>
                    <th><?php echo esc_html__('السعر (USD)', 'infi-gold-manager'); ?></th>
                    <th><?php echo esc_html__('تاريخ التحديث', 'infi-gold-manager'); ?></th>
                </tr>
                <?php foreach ($gold_prices as $price): ?>
                <tr>
                    <td><strong><?php echo esc_html($price['carat']); ?></strong></td>
                    <td><?php echo esc_html(number_format(floatval($price['price_usd']), 4)); ?></td>
                    <td><?php echo esc_html(date_i18n(get_option('date_format') . ' ' . get_option('time_format'), strtotime($price['fetch_date']))); ?></td>
                </tr>
                <?php endforeach; ?>
            </table>
            <?php else: ?>
            <p><?php echo esc_html__('لا توجد بيانات متاحة.', 'infi-gold-manager'); ?></p>
            <?php endif; ?>
        </div>
        
        <div class="card" style="max-width: 800px; margin-top: 20px; padding: 20px; background: #fff; border: 1px solid #ccd0d4; border-radius: 4px; box-shadow: 0 1px 1px rgba(0,0,0,.04);">
            <h2><?php echo esc_html__('أحدث أسعار العملات', 'infi-gold-manager'); ?></h2>
            
            <?php
            // الحصول على أحدث أسعار العملات الرئيسية
            $main_currencies = ['USD', 'usd', 'GBP', 'SAR', 'AED', 'KWD', 'EGP'];
            $currency_prices = [];
            
            foreach ($main_currencies as $code) {
                $rate = $wpdb->get_row($wpdb->prepare(
                    "SELECT * FROM $currency_table 
                     WHERE currency_code = %s AND currency_date = %s 
                     ORDER BY fetch_date DESC LIMIT 1",
                    $code,
                    $latest_currency_date
                ), ARRAY_A);
                
                if ($rate) {
                    $currency_prices[] = $rate;
                }
            }
            
            if (!empty($currency_prices)):
            ?>
            <table class="widefat">
                <tr>
                    <th><?php echo esc_html__('العملة', 'infi-gold-manager'); ?></th>
                    <th><?php echo esc_html__('السعر (usd)', 'infi-gold-manager'); ?></th>
                    <th><?php echo esc_html__('تاريخ التحديث', 'infi-gold-manager'); ?></th>
                </tr>
                <?php foreach ($currency_prices as $currency): ?>
                <tr>
                    <td><strong><?php echo esc_html($currency['currency_code']); ?></strong></td>
                    <td><?php echo esc_html(number_format(floatval($currency['rate_to_usd']), 4)); ?></td>
                    <td><?php echo esc_html(date_i18n(get_option('date_format') . ' ' . get_option('time_format'), strtotime($currency['fetch_date']))); ?></td>
                </tr>
                <?php endforeach; ?>
            </table>
            <?php else: ?>
            <p><?php echo esc_html__('لا توجد بيانات متاحة.', 'infi-gold-manager'); ?></p>
            <?php endif; ?>
        </div>
        
        <div class="card" style="max-width: 800px; margin-top: 20px; margin-bottom: 20px; padding: 20px; background: #fff; border: 1px solid #ccd0d4; border-radius: 4px; box-shadow: 0 1px 1px rgba(0,0,0,.04);">
            <h2><?php echo esc_html__('تحويل البيانات من اليورو إلى الدولار', 'infi-gold-manager'); ?></h2>
            <p class="description"><?php echo esc_html__('استخدم هذا الزر لتحويل جميع أسعار الذهب المخزنة من اليورو إلى الدولار. سيتم عمل نسخة احتياطية تلقائيًا.', 'infi-gold-manager'); ?></p>
            <p class="description" style="color: red;"><strong><?php echo esc_html__('تحذير: هذه العملية لا يمكن التراجع عنها. تأكد من عمل نسخة احتياطية لقاعدة البيانات قبل المتابعة.', 'infi-gold-manager'); ?></strong></p>
            
            <form method="post" action="">
                <?php wp_nonce_field('convert_currency_nonce'); ?>
                <p>
                    <input type="submit" name="convert_usd_to_usd" class="button button-primary" value="<?php echo esc_attr__('تحويل البيانات', 'infi-gold-manager'); ?>" onclick="return confirm('هل أنت متأكد من تحويل جميع أسعار الذهب من اليورو إلى الدولار؟ تأكد من عمل نسخة احتياطية لقاعدة البيانات أولاً.');">
                </p>
            </form>
        </div>
        
        <style>
            .status-success { color: green; font-weight: bold; }
            .status-error { color: red; font-weight: bold; }
        </style>
    </div>
    <?php
}