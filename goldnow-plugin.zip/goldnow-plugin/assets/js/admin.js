
/**
 * Gold Manager Admin Scripts
 */
jQuery(document).ready(function($) {
    // تحديد العملة عند اختيار صف في جدول نسب البيع والشراء
    $('.infi-gold-markup-table tr').on('click', function() {
        var currency = $(this).data('currency');
        var buy = $(this).data('buy');
        var sell = $(this).data('sell');
        
        if (currency) {
            $('#currency_code').val(currency);
            $('#buy_percentage').val(buy);
            $('#sell_percentage').val(sell);
        }
    });
    
    // تأكيد حذف نسب البيع والشراء
    $('.delete-markup').on('click', function() {
        return confirm('Are you sure you want to delete this markup?');
    });
    
    // تأكيد مسح ملف السجل
    $('#clear-log').on('click', function() {
        return confirm('Are you sure you want to clear the log file?');
    });
});
