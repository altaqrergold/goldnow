<?php
/**
 * إدارة قاعدة البيانات للإضافة
 * Path: /database.php
 */

// منع الوصول المباشر
if (!defined('ABSPATH')) {
    exit;
}

function infi_get_main_site_prefix() {
    global $wpdb;
    
    return $wpdb->base_prefix;
}

define('INFI_MAIN_PREFIX', infi_get_main_site_prefix());



/**
 * إنشاء جداول قاعدة البيانات اللازمة
 */
function infi_create_database_tables() {
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();
    
    try {
        // جدول أسعار الذهب
        $gold_table = INFI_MAIN_PREFIX  . 'infi_gold_prices';
        $sql_gold = "CREATE TABLE IF NOT EXISTS $gold_table (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            fetch_date DATETIME NOT NULL,
            gold_date DATE NOT NULL,
            metal VARCHAR(20) NOT NULL,
            carat VARCHAR(10) NOT NULL,
            price_usd DECIMAL(15,6) NOT NULL,
            PRIMARY KEY (id),
            KEY idx_gold_date (gold_date),
            KEY idx_metal_carat (metal, carat)
        ) $charset_collate;";
        
        // جدول أسعار العملات
        $currency_table = INFI_MAIN_PREFIX  . 'infi_currency_rates';
        $sql_currency = "CREATE TABLE IF NOT EXISTS $currency_table (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            fetch_date DATETIME NOT NULL,
            currency_date DATE NOT NULL,
            currency_code VARCHAR(10) NOT NULL,
            rate_to_usd DECIMAL(15,6) NOT NULL,
            PRIMARY KEY (id),
            KEY idx_currency_date (currency_date),
            KEY idx_currency_code (currency_code)
        ) $charset_collate;";
        
        // جدول آخر تحديث للبيانات
        $last_update_table = INFI_MAIN_PREFIX  . 'infi_last_updates';
        $sql_last_update = "CREATE TABLE IF NOT EXISTS $last_update_table (
            id INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
            api_type VARCHAR(50) NOT NULL,
            last_update DATETIME NOT NULL,
            status VARCHAR(20) NOT NULL DEFAULT 'success',
            message TEXT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY api_type (api_type)
        ) $charset_collate;";
        
        // جدول نسب البيع والشراء
        $markup_table = INFI_MAIN_PREFIX  . 'infi_gold_markup';
        $sql_markup = "CREATE TABLE IF NOT EXISTS $markup_table (
            id INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
            currency_code VARCHAR(10) NOT NULL,
            buy_percentage DECIMAL(8,4) NOT NULL DEFAULT 0,
            sell_percentage DECIMAL(8,4) NOT NULL DEFAULT 0,
            PRIMARY KEY (id),
            UNIQUE KEY currency_code (currency_code)
        ) $charset_collate;";
        
        // تشغيل استعلامات إنشاء الجداول
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql_gold);
        dbDelta($sql_currency);
        dbDelta($sql_last_update);
        dbDelta($sql_markup);
        
        infi_gold_log('Database tables created successfully');
    } catch (Exception $e) {
        infi_gold_log('Error creating database tables: ' . $e->getMessage(), 'error');
        throw $e;
    }
}

/**
 * حفظ أسعار الذهب في قاعدة البيانات
 */
/**
 * حفظ أسعار الذهب في قاعدة البيانات
 */
/**
 * حفظ أسعار الذهب في قاعدة البيانات
 */
function infi_save_gold_prices($prices) {
    global $wpdb;
    $table_name = INFI_MAIN_PREFIX  . 'infi_gold_prices';
    $current_time = current_time('mysql', true);
    $insert_count = 0;
    $errors = [];
    
    try {
        if (empty($prices) || !is_array($prices)) {
            throw new Exception('Invalid gold prices data');
        }
        
        // بداية المعاملة لتجنب حفظ بيانات جزئية
        $wpdb->query('START TRANSACTION');
        
        foreach ($prices as $price) {
            // التحقق من البيانات - هنا التغيير الهام! نتحقق من وجود price_usd أو price_usd
            $price_value = 0;
            if (isset($price['price_usd'])) {
                $price_value = floatval($price['price_usd']);
            } elseif (isset($price['price_usd'])) {
                $price_value = floatval($price['price_usd']);
            } else {
                $errors[] = 'Invalid price data: ' . print_r($price, true);
                continue;
            }
            
            if (empty($price['metal']) || empty($price['carat'])) {
                $errors[] = 'Invalid price data: ' . print_r($price, true);
                continue;
            }
            
            $result = $wpdb->insert(
                $table_name,
                [
                    'fetch_date' => $current_time,
                    'gold_date' => date('Y-m-d'),
                    'metal' => sanitize_text_field($price['metal']),
                    'carat' => sanitize_text_field($price['carat']),
                    'price_usd' => $price_value
                ],
                ['%s', '%s', '%s', '%s', '%f']
            );
            
            if ($result === false) {
                $errors[] = 'Database error: ' . $wpdb->last_error;
            } else {
                $insert_count++;
            }
        }
        
        // في حالة وجود أخطاء، تراجع عن المعاملة
        if (!empty($errors)) {
            $wpdb->query('ROLLBACK');
            infi_gold_log('Errors during gold prices save: ' . implode(', ', $errors), 'error');
            return false;
        }
        
        // تأكيد المعاملة
        $wpdb->query('COMMIT');
        
        // تحديث جدول آخر تحديث
        infi_update_last_update_status('metals_api', 'success');
        
        infi_gold_log("Successfully saved $insert_count gold prices to database");
        return true;
        
    } catch (Exception $e) {
        $wpdb->query('ROLLBACK');
        infi_gold_log('Failed to save gold prices: ' . $e->getMessage(), 'error');
        infi_update_last_update_status('metals_api', 'error', $e->getMessage());
        return false;
    }
}
/**
 * حفظ أسعار العملات في قاعدة البيانات
 */
function infi_save_currency_rates($rates) {
    global $wpdb;
    $table_name = INFI_MAIN_PREFIX  . 'infi_currency_rates';
    $current_time = current_time('mysql', true);
    $insert_count = 0;
    $errors = [];
    
    try {
        if (empty($rates) || !is_array($rates)) {
            throw new Exception('Invalid currency rates data');
        }
        
        // بداية المعاملة
        $wpdb->query('START TRANSACTION');
        
        foreach ($rates as $currency_code => $rate) {
            // التحقق من البيانات
            if (empty($currency_code) || !is_numeric($rate)) {
                $errors[] = "Invalid rate data for $currency_code: $rate";
                continue;
            }
            
            $result = $wpdb->insert(
                $table_name,
                [
                    'fetch_date' => $current_time,
                    'currency_date' => date('Y-m-d'),
                    'currency_code' => sanitize_text_field($currency_code),
                    'rate_to_usd' => floatval($rate)
                ],
                ['%s', '%s', '%s', '%f']
            );
            
            if ($result === false) {
                $errors[] = 'Database error: ' . $wpdb->last_error;
            } else {
                $insert_count++;
            }
        }
        
        // في حالة وجود أخطاء، تراجع عن المعاملة
        if (!empty($errors)) {
            $wpdb->query('ROLLBACK');
            infi_gold_log('Errors during currency rates save: ' . implode(', ', $errors), 'error');
            return false;
        }
        
        // تأكيد المعاملة
        $wpdb->query('COMMIT');
        
        // تحديث جدول آخر تحديث
        infi_update_last_update_status('exchange_rates_api', 'success');
        
        infi_gold_log("Successfully saved $insert_count currency rates to database");
        return true;
        
    } catch (Exception $e) {
        $wpdb->query('ROLLBACK');
        infi_gold_log('Failed to save currency rates: ' . $e->getMessage(), 'error');
        infi_update_last_update_status('exchange_rates_api', 'error', $e->getMessage());
        return false;
    }
}

/**
 * تحديث حالة آخر تحديث للبيانات
 */
function infi_update_last_update_status($api_type, $status, $message = '') {
    global $wpdb;
    $table_name = INFI_MAIN_PREFIX  . 'infi_last_updates';
    
    try {
        $current_time = current_time('mysql', true);
        
        // التحقق من وجود سجل سابق
        $existing = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM $table_name WHERE api_type = %s",
            $api_type
        ));
        
        if ($existing) {
            // تحديث السجل الموجود
            $result = $wpdb->update(
                $table_name,
                [
                    'last_update' => $current_time,
                    'status' => $status,
                    'message' => $message
                ],
                ['api_type' => $api_type],
                ['%s', '%s', '%s'],
                ['%s']
            );
        } else {
            // إنشاء سجل جديد
            $result = $wpdb->insert(
                $table_name,
                [
                    'api_type' => $api_type,
                    'last_update' => $current_time,
                    'status' => $status,
                    'message' => $message
                ],
                ['%s', '%s', '%s', '%s']
            );
        }
        
        if ($result === false) {
            infi_gold_log("Failed to update last update status for $api_type: " . $wpdb->last_error, 'error');
            return false;
        }
        
        return true;
    } catch (Exception $e) {
        infi_gold_log("Error updating last update status for $api_type: " . $e->getMessage(), 'error');
        return false;
    }
}

/**
 * الحصول على آخر أسعار الذهب
 */
/**
 * الحصول على آخر أسعار الذهب
 */
function infi_get_latest_gold_prices($carat = null) {
    global $wpdb;
    $table_name = INFI_MAIN_PREFIX  . 'infi_gold_prices';
    
    try {
        // الحصول على تاريخ آخر سعر تم تخزينه
        $latest_date = $wpdb->get_var("SELECT MAX(gold_date) FROM $table_name");
        
        if (!$latest_date) {
            infi_gold_log('No gold prices found in database', 'warning');
            return [];
        }
        
        // جلب أسعار الذهب بحسب العيار إذا تم تحديده
        if ($carat !== null) {
            $query = $wpdb->prepare(
                "SELECT * FROM $table_name 
                WHERE gold_date = %s AND carat = %s AND price_usd > 0.01
                ORDER BY fetch_date DESC LIMIT 1",
                $latest_date,
                $carat
            );
        } else {
            $query = $wpdb->prepare(
                "SELECT t1.* FROM $table_name t1
                INNER JOIN (
                    SELECT carat, MAX(fetch_date) as max_date
                    FROM $table_name
                    WHERE gold_date = %s AND price_usd > 0.01
                    GROUP BY carat
                ) t2 ON t1.carat = t2.carat AND t1.fetch_date = t2.max_date
                WHERE t1.gold_date = %s",
                $latest_date,
                $latest_date
            );
        }
        
        $results = $wpdb->get_results($query, ARRAY_A);
        
        if (empty($results)) {
            infi_gold_log("No valid gold prices found for date $latest_date and carat $carat", 'warning');
            return [];
        }
        
        return $results;
    } catch (Exception $e) {
        infi_gold_log('Error retrieving latest gold prices: ' . $e->getMessage(), 'error');
        return [];
    }
}
/**
 * الحصول على آخر أسعار العملات
 */
/**
 * الحصول على آخر أسعار العملات
 */
function infi_get_latest_currency_rates($currency_code = null) {
    global $wpdb;
    $table_name = INFI_MAIN_PREFIX  . 'infi_currency_rates';
    
    try {
        // الحصول على تاريخ آخر سعر تم تخزينه
        $latest_date = $wpdb->get_var("SELECT MAX(currency_date) FROM $table_name");
        
        if (!$latest_date) {
            infi_gold_log('No currency rates found in database', 'warning');
            return [];
        }
        
        // جلب أسعار العملات بحسب العملة إذا تم تحديدها
        if ($currency_code !== null) {
            $query = $wpdb->prepare(
                "SELECT * FROM $table_name 
                WHERE currency_date = %s AND currency_code = %s AND rate_to_usd > 0.01
                ORDER BY fetch_date DESC LIMIT 1",
                $latest_date,
                $currency_code
            );
            $result = $wpdb->get_row($query, ARRAY_A);
            
            if (empty($result)) {
                infi_gold_log("No valid currency rate found for date $latest_date and currency $currency_code", 'warning');
                return null;
            }
            
            return $result;
        } else {
            $query = $wpdb->prepare(
                "SELECT t1.* FROM $table_name t1
                INNER JOIN (
                    SELECT currency_code, MAX(fetch_date) as max_date
                    FROM $table_name
                    WHERE currency_date = %s AND rate_to_usd > 0.01
                    GROUP BY currency_code
                ) t2 ON t1.currency_code = t2.currency_code AND t1.fetch_date = t2.max_date
                WHERE t1.currency_date = %s",
                $latest_date,
                $latest_date
            );
            $results = $wpdb->get_results($query, ARRAY_A);
            
            if (empty($results)) {
                infi_gold_log("No valid currency rates found for date $latest_date", 'warning');
                return [];
            }
            
            // تحويل المصفوفة لتكون أكثر سهولة في الاستخدام
            $rates = [];
            foreach ($results as $row) {
                $rates[$row['currency_code']] = floatval($row['rate_to_usd']);
            }
            
            return $rates;
        }
    } catch (Exception $e) {
        infi_gold_log('Error retrieving latest currency rates: ' . $e->getMessage(), 'error');
        return ($currency_code !== null) ? null : [];
    }
}
/**
 * الحصول على نسب البيع والشراء لعملة معينة
 */
function infi_get_markup_percentages($currency_code) {
    global $wpdb;
    $table_name = INFI_MAIN_PREFIX  . 'infi_gold_markup';
    
    try {
        $query = $wpdb->prepare(
            "SELECT buy_percentage, sell_percentage FROM $table_name WHERE currency_code = %s",
            $currency_code
        );
        
        $result = $wpdb->get_row($query, ARRAY_A);
        
        if (empty($result)) {
            // استخدام القيم الافتراضية إذا لم يتم العثور على سجل
            $default_settings = get_option('infi_gold_manager_settings', []);
            $default_buy = isset($default_settings['default_buy_percentage']) ? floatval($default_settings['default_buy_percentage']) : 1.5;
            $default_sell = isset($default_settings['default_sell_percentage']) ? floatval($default_settings['default_sell_percentage']) : 2.5;
            
            return [
                'buy_percentage' => $default_buy,
                'sell_percentage' => $default_sell
            ];
        }
        
        return [
            'buy_percentage' => floatval($result['buy_percentage']),
            'sell_percentage' => floatval($result['sell_percentage'])
        ];
    } catch (Exception $e) {
        infi_gold_log('Error retrieving markup percentages: ' . $e->getMessage(), 'error');
        return [
            'buy_percentage' => 1.5, // قيمة افتراضية
            'sell_percentage' => 2.5  // قيمة افتراضية
        ];
    }
}

/**
 * حفظ نسب البيع والشراء لعملة معينة
 */
function infi_save_markup_percentages($currency_code, $buy_percentage, $sell_percentage) {
    global $wpdb;
    $table_name = INFI_MAIN_PREFIX  . 'infi_gold_markup';
    
    try {
        // التحقق من وجود سجل سابق
        $existing = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM $table_name WHERE currency_code = %s",
            $currency_code
        ));
        
        if ($existing) {
            // تحديث السجل الموجود
            $result = $wpdb->update(
                $table_name,
                [
                    'buy_percentage' => floatval($buy_percentage),
                    'sell_percentage' => floatval($sell_percentage)
                ],
                ['currency_code' => $currency_code],
                ['%f', '%f'],
                ['%s']
            );
        } else {
            // إنشاء سجل جديد
            $result = $wpdb->insert(
                $table_name,
                [
                    'currency_code' => sanitize_text_field($currency_code),
                    'buy_percentage' => floatval($buy_percentage),
                    'sell_percentage' => floatval($sell_percentage)
                ],
                ['%s', '%f', '%f']
            );
        }
        
        if ($result === false) {
            infi_gold_log("Failed to save markup percentages for $currency_code: " . $wpdb->last_error, 'error');
            return false;
        }
        
        infi_gold_log("Successfully saved markup percentages for $currency_code");
        return true;
    } catch (Exception $e) {
        infi_gold_log('Error saving markup percentages: ' . $e->getMessage(), 'error');
        return false;
    }
}

/**
 * إعداد الخيارات الافتراضية
 */
// أولاً، احصل على الإعدادات الحالية
/**
 * تعديل ملف functions.php لتحديث الخيارات الافتراضية
 */
function infi_setup_default_options() {
    $default_options = [
        'metals_api_key' => '',
        'metalprice_api_key' => '',
        'exchange_rates_api_key' => '',
        'gold_update_interval' => 60, // بالدقائق
        'currency_update_interval' => 60, // بالدقائق
        'cron_type' => 'wp_cron', // wp_cron أو external
        'default_buy_percentage' => 1.5,
        'default_sell_percentage' => 2.5,
        'cache_duration' => 30, // بالدقائق
        'default_currency' => 'USD',
        'default_country_code' => 'sa', // الدولة الافتراضية 
        'user_country_detection' => 'cloudflare', // cloudflare أو manual
        'api_provider' => 'swissquote', // يمكن أن تكون 'metalprice', 'metals-api', أو 'swissquote'
        'currency_api_provider' => 'exchangeratesapi' // يمكن أن تكون 'exchangeratesapi' أو 'exchangerate-api'
    ];
   
    // إضافة الخيارات إذا لم تكن موجودة
    if (!get_option('infi_gold_manager_settings')) {
        add_option('infi_gold_manager_settings', $default_options);
        infi_gold_log('Default options added');
    }
}
/**
 * الحصول على البيانات التاريخية لأسعار الذهب
 */
function infi_get_historical_gold_prices($carat, $start_date, $end_date = null) {
    global $wpdb;
    $table_name = INFI_MAIN_PREFIX  . 'infi_gold_prices';
    
    try {
        if ($end_date === null) {
            $end_date = date('Y-m-d');
        }
        
        $query = $wpdb->prepare(
            "SELECT gold_date, price_usd FROM $table_name 
            WHERE carat = %s AND gold_date BETWEEN %s AND %s 
            ORDER BY gold_date ASC",
            $carat,
            $start_date,
            $end_date
        );
        
        $results = $wpdb->get_results($query, ARRAY_A);
        
        if (empty($results)) {
            infi_gold_log("No historical gold prices found for carat $carat between $start_date and $end_date", 'warning');
            return [];
        }
        
        return $results;
    } catch (Exception $e) {
        infi_gold_log('Error retrieving historical gold prices: ' . $e->getMessage(), 'error');
        return [];
    }
}

/**
 * الحصول على أعلى وأقل سعر للذهب خلال فترة معينة
 */
function infi_get_gold_price_extremes($carat, $days = 30) {
    global $wpdb;
    $table_name = INFI_MAIN_PREFIX  . 'infi_gold_prices';
    
    try {
        $start_date = date('Y-m-d', strtotime("-$days days"));
        $end_date = date('Y-m-d');
        
        $query = $wpdb->prepare(
            "SELECT 
                MAX(price_usd) as highest_price,
                MIN(price_usd) as lowest_price,
                (SELECT gold_date FROM $table_name WHERE carat = %s AND gold_date BETWEEN %s AND %s AND price_usd = (
                    SELECT MAX(price_usd) FROM $table_name WHERE carat = %s AND gold_date BETWEEN %s AND %s
                ) LIMIT 1) as highest_date,
                (SELECT gold_date FROM $table_name WHERE carat = %s AND gold_date BETWEEN %s AND %s AND price_usd = (
                    SELECT MIN(price_usd) FROM $table_name WHERE carat = %s AND gold_date BETWEEN %s AND %s
                ) LIMIT 1) as lowest_date
            FROM $table_name 
            WHERE carat = %s AND gold_date BETWEEN %s AND %s",
            $carat, $start_date, $end_date,
            $carat, $start_date, $end_date,
            $carat, $start_date, $end_date,
            $carat, $start_date, $end_date,
            $carat, $start_date, $end_date
        );
        
        $result = $wpdb->get_row($query, ARRAY_A);
        
        if (empty($result) || $result['highest_price'] === null) {
            infi_gold_log("No gold price extremes found for carat $carat in the last $days days", 'warning');
            return null;
        }
        
        return [
            'highest_price' => floatval($result['highest_price']),
            'highest_date' => $result['highest_date'],
            'lowest_price' => floatval($result['lowest_price']),
            'lowest_date' => $result['lowest_date']
        ];
    } catch (Exception $e) {
        infi_gold_log('Error retrieving gold price extremes: ' . $e->getMessage(), 'error');
        return null;
    }
}

/**
 * إنشاء تحليل للتغير في أسعار الذهب (اليومي أو الأسبوعي)
 */
/**
 * إنشاء تحليل للتغير في أسعار الذهب (اليومي أو الأسبوعي)
 */
function infi_get_gold_price_change($carat, $period = 'daily') {
    global $wpdb;
    $table_name = INFI_MAIN_PREFIX  . 'infi_gold_prices';
    
    try {
        $today = date('Y-m-d');
        
        if ($period === 'daily') {
            $previous_date = date('Y-m-d', strtotime('-1 day'));
        } 
        else if ($period === 'weekly') {
            $previous_date = date('Y-m-d', strtotime('-7 days'));
        } 
        else {
            throw new Exception("Invalid period specified: $period");
        }
        
        // الحصول على سعر اليوم
        $current_query = $wpdb->prepare(
            "SELECT price_usd FROM $table_name 
            WHERE carat = %s AND gold_date = %s 
            ORDER BY fetch_date DESC LIMIT 1",
            $carat,
            $today
        );
        
        $current_price = $wpdb->get_var($current_query);
        
        if ($current_price === null) {
            // إذا لم يكن هناك سعر لليوم، نبحث عن آخر سعر متاح
            $latest_query = $wpdb->prepare(
                "SELECT price_usd, gold_date FROM $table_name 
                WHERE carat = %s 
                ORDER BY gold_date DESC, fetch_date DESC LIMIT 1",
                $carat
            );
            
            $latest = $wpdb->get_row($latest_query, ARRAY_A);
            
            if (empty($latest)) {
                infi_gold_log("No gold prices found for carat $carat", 'warning');
                return null;
            }
            
            $current_price = floatval($latest['price_usd']);
            $today = $latest['gold_date'];
            $previous_date = date('Y-m-d', strtotime("$today -" . ($period === 'daily' ? '1' : '7') . " days"));
        } else {
            $current_price = floatval($current_price);
        }
        
        // الحصول على السعر السابق
        $previous_query = $wpdb->prepare(
            "SELECT price_usd FROM $table_name 
            WHERE carat = %s AND gold_date <= %s 
            ORDER BY gold_date DESC, fetch_date DESC LIMIT 1",
            $carat,
            $previous_date
        );
        
        $previous_price = $wpdb->get_var($previous_query);
        
        if ($previous_price === null) {
            infi_gold_log("No previous gold price found for carat $carat on or before $previous_date", 'warning');
            return [
                'current_price' => $current_price,
                'current_date' => $today,
                'previous_price' => null,
                'previous_date' => null,
                'change_value' => null,
                'change_percentage' => null
            ];
        }
        
        $previous_price = floatval($previous_price);
        $change_value = $current_price - $previous_price;
        $change_percentage = ($previous_price > 0) ? (($change_value / $previous_price) * 100) : 0;
        
        return [
            'current_price' => $current_price,
            'current_date' => $today,
            'previous_price' => $previous_price,
            'previous_date' => $previous_date,
            'change_value' => $change_value,
            'change_percentage' => $change_percentage
        ];
        
    } catch (Exception $e) {
        infi_gold_log('Error calculating gold price change: ' . $e->getMessage(), 'error');
        return null;
    }
}

/**
* معالجة التخزين المؤقت للبيانات
*/
function infi_get_cached_data($key, $callback, $args = [], $expiration = null) {
// الحصول على مدة التخزين المؤقت من الإعدادات إذا لم يتم تحديدها
if ($expiration === null) {
    $settings = get_option('infi_gold_manager_settings', []);
    $expiration = isset($settings['cache_duration']) ? (int)$settings['cache_duration'] * 60 : 1800; // 30 دقيقة افتراضياً
}

// تحقق من وجود قيمة مخزنة مؤقتاً
$cached_data = get_transient($key);

if ($cached_data !== false) {
    infi_gold_log("Retrieved cached data for key: $key");
    return $cached_data;
}

// الحصول على البيانات من خلال الدالة المحددة
$data = call_user_func_array($callback, $args);

// تخزين البيانات مؤقتاً
if ($data !== null && $data !== false) {
    set_transient($key, $data, $expiration);
    infi_gold_log("Cached data for key: $key (expires in " . ($expiration / 60) . " minutes)");
}

return $data;
}

/**
* مسح التخزين المؤقت المرتبط بالإضافة
*/
function infi_clear_cache() {
global $wpdb;

try {
    // مسح جميع الـ transients التي تبدأ بـ 'infi_gold_'
    $wpdb->query("DELETE FROM $wpdb->options WHERE option_name LIKE '_transient_infi_gold_%'");
    $wpdb->query("DELETE FROM $wpdb->options WHERE option_name LIKE '_transient_timeout_infi_gold_%'");
    
    infi_gold_log('Cache cleared successfully');
    return true;
} catch (Exception $e) {
    infi_gold_log('Error clearing cache: ' . $e->getMessage(), 'error');
    return false;
}
}

/**
* الحصول على معلومات حالة API من جدول آخر التحديثات
*/
function infi_get_api_status($api_type = null) {
global $wpdb;
$table_name = INFI_MAIN_PREFIX  . 'infi_last_updates';

try {
    if ($api_type !== null) {
        $query = $wpdb->prepare("SELECT * FROM $table_name WHERE api_type = %s", $api_type);
        return $wpdb->get_row($query, ARRAY_A);
    } else {
        return $wpdb->get_results("SELECT * FROM $table_name", ARRAY_A);
    }
} catch (Exception $e) {
    infi_gold_log('Error getting API status: ' . $e->getMessage(), 'error');
    return ($api_type !== null) ? null : [];
}
}













/**
 * تحويل أسعار الذهب من اليورو إلى الدولار في قاعدة البيانات
 * تستخدم مرة واحدة فقط لتحويل البيانات القديمة
 */
function convert_usd_to_usd_in_database() {
    global $wpdb;
    $gold_table = INFI_MAIN_PREFIX . 'infi_gold_prices';
    
    // عمل نسخة احتياطية من الجدول قبل التحويل
    $backup_table = INFI_MAIN_PREFIX . 'infi_gold_prices_backup_' . date('Ymd');
    $wpdb->query("CREATE TABLE IF NOT EXISTS $backup_table LIKE $gold_table");
    $wpdb->query("INSERT INTO $backup_table SELECT * FROM $gold_table");
    
    // الحصول على معدل تحويل اليورو إلى الدولار
    $currency_table = INFI_MAIN_PREFIX . 'infi_currency_rates';
    $latest_date = $wpdb->get_var("SELECT MAX(currency_date) FROM $currency_table");
    
    $usd_to_usd = $wpdb->get_var(
        $wpdb->prepare(
            "SELECT rate_to_usd FROM $currency_table 
             WHERE currency_code = %s AND currency_date = %s 
             LIMIT 1",
            'USD',
            $latest_date
        )
    );
    
    if (!$usd_to_usd || $usd_to_usd <= 0) {
        return ['status' => 'error', 'message' => 'لم يتم العثور على سعر صرف الدولار'];
    }
    
    // تحويل الأسعار من اليورو إلى الدولار
    $result = $wpdb->query(
        $wpdb->prepare(
            "UPDATE $gold_table SET price_usd = price_usd * %f",
            $usd_to_usd
        )
    );
    
    if ($result === false) {
        return [
            'status' => 'error', 
            'message' => 'حدث خطأ أثناء تحديث البيانات: ' . $wpdb->last_error
        ];
    }
    
    return [
        'status' => 'success', 
        'message' => 'تم تحويل ' . $result . ' سجل من اليورو إلى الدولار',
        'backup_table' => $backup_table
    ];
}






